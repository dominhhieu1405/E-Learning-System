<form id="modal-form" action="/panel/api/edit-taxonomy/{{ $taxonomy->id }}" type="POST">
    <div class="form-group ">
        <label>{{("Name")}}</label>
        <input class="form-control" name="name" placeholder="" value="{{ $taxonomy->name }}">
    </div>

    <div class="form-group">
        <label for="description">{{("Describe")}}</label>
        <textarea name="description" class="form-control" style="min-height: 100px" placeholder="">{{ $taxonomy->description }}</textarea>
    </div>
</form>
<script>
    $( "#modal-form" ).submit(function( event ) {
        event.preventDefault();
        $("#submit").click();
    });
</script>