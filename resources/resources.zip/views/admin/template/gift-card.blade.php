<form id="modal-form" action="/panel/api/gift-card/{{ $type }}" type="POST">
    @if($type == 'type')
        <div class="form-group ">
            <label>{{("Name")}}</label>
            <input class="form-control" name="name" placeholder="">
        </div>
        <div class="form-group ">
            <label>{{("Price")}}</label>
            <input class="form-control" name="price" placeholder="">
        </div>
    @else
        <div class="form-group ">
            <label>{{("Type")}}</label>
            <div class="input-group">
                <select name="type" class="form-control">
                    <option value="" selected="">
                        ---SELECT---
                    </option>
                    @foreach($types as $type_)
                        <option value="{{$type_->id}}">
                            {{$type_->name}}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group ">
            <label>{{("Code")}}</label>
            <input class="form-control" name="code" placeholder="">
        </div>
        <div class="form-group ">
            <label>{{("Serial")}}</label>
            <input class="form-control" name="serial" placeholder="">
        </div>
    @endif
</form>
<script>
    $( "#modal-form" ).submit(function( event ) {
        event.preventDefault();
        $("#submit").click();
    });
</script>
