@extends('admin.layout')
@section('content')
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0"><i class="ri-file-code-line me-2 text-primary"></i>Import Đề Thi Từ File JSON</h4>
                    <a href="/admin/exams" class="btn btn-sm btn-outline-secondary">
                        <i class="ri-arrow-left-line"></i> Quay lại danh sách đề
                    </a>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Form -->
            <div class="col-lg-5">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-4">
                            <i class="ri-upload-cloud-2-line me-1"></i> Tải lên file JSON
                        </h5>

                        <form id="formJsonImport">
                            {{-- Loại đề --}}
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Loại đề thi <span class="text-danger">*</span></label>
                                <select name="exam_type" id="examType" class="form-control custom-select">
                                    <option value="thpt">THPT Quốc gia 2025</option>
                                    <option value="hsa">HSA - Đánh giá năng lực (ĐHQG)</option>
                                    <option value="tsa">TSA - Tư duy (ĐHBK)</option>
                                </select>
                            </div>

                            {{-- Gắn vào đề có sẵn --}}
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Gắn vào đề thi</label>
                                <select name="exam_id" class="form-control custom-select">
                                    <option value="">— Tạo đề thi mới tự động —</option>
                                    @foreach($exams as $exam)
                                    <option value="{{ $exam->id }}">
                                        [{{ strtoupper($exam->exam_type) }}] {{ $exam->title }}
                                    </option>
                                    @endforeach
                                </select>
                                <div class="form-text text-muted">Để trống = tự tạo đề mới với tên từ file JSON.</div>
                            </div>

                            {{-- Môn học --}}
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Môn học (tuỳ chọn)</label>
                                <select name="subject_id" class="form-control custom-select">
                                    <option value="">-- Không gắn môn --</option>
                                    @foreach($subjects as $s)
                                    <option value="{{ $s->id }}">{{ $s->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            {{-- Upload JSON --}}
                            <div class="mb-4">
                                <label class="form-label fw-semibold">File JSON đề thi <span class="text-danger">*</span></label>
                                <div id="dropZone" class="border-2 border-dashed rounded-3 p-4 text-center"
                                    style="border: 2px dashed #6c757d; cursor: pointer; transition: all .2s;"
                                    onclick="document.getElementById('jsonFile').click()">
                                    <i class="ri-file-code-line fs-1 text-primary"></i>
                                    <p class="mb-1 mt-2 fw-semibold" id="dropText">Kéo thả hoặc click để chọn file JSON</p>
                                    <p class="text-muted small mb-0">File xuất từ AI (import.json)</p>
                                </div>
                                <input type="file" name="json_file" id="jsonFile" accept=".json" class="d-none">
                            </div>

                            {{-- Preview stats --}}
                            <div id="previewBox" class="alert alert-info d-none mb-3 py-2">
                                <i class="ri-information-line me-1"></i>
                                <strong>Preview:</strong> <span id="previewText">Đang đọc file...</span>
                            </div>

                            {{-- Submit --}}
                            <button type="submit" class="btn btn-primary w-100 btn-lg" id="btnSubmit" disabled>
                                <i class="ri-database-2-line me-1"></i> Import vào hệ thống
                            </button>
                        </form>

                        <div class="mt-3">
                            <div class="alert alert-soft-secondary mb-0 py-2 small">
                                <i class="ri-lightbulb-line me-1 text-warning"></i>
                                <strong>Cấu trúc JSON hỗ trợ:</strong> Định dạng xuất từ AI (AiService) gồm
                                <code>exam_title</code>, <code>passage_groups</code>, <code>questions</code>.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Result -->
            <div class="col-lg-7">

                {{-- Loading state --}}
                <div id="loadingCard" class="card d-none">
                    <div class="card-body text-center py-5">
                        <div class="spinner-border text-primary mb-3" style="width:3rem;height:3rem;" role="status"></div>
                        <h5 class="mb-1">Đang import...</h5>
                        <p class="text-muted mb-0">Hệ thống đang lưu câu hỏi vào cơ sở dữ liệu.</p>
                        <div class="progress mt-3" style="height:6px;">
                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary w-100"></div>
                        </div>
                    </div>
                </div>

                {{-- Success state --}}
                <div id="resultCard" class="card d-none">
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-4">
                            <div class="avatar-sm bg-success-subtle rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                <i class="ri-check-line fs-4 text-success"></i>
                            </div>
                            <div>
                                <h5 class="mb-0" id="resultTitle">Import thành công!</h5>
                                <p class="text-muted mb-0" id="resultSubtitle"></p>
                            </div>
                        </div>

                        <div class="row g-3 mb-4">
                            <div class="col-6">
                                <div class="p-3 rounded-3 text-center" style="background:#f0fdf4;">
                                    <div class="fs-2 fw-bold text-success" id="importedCount">0</div>
                                    <div class="small text-muted">Câu hỏi đã import</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="p-3 rounded-3 text-center" style="background:#fff7ed;">
                                    <div class="fs-2 fw-bold text-warning" id="imageCount">0</div>
                                    <div class="small text-muted">Câu cần thêm ảnh</div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex gap-2 mb-4">
                            <a href="#" id="btnViewExam" class="btn btn-primary flex-grow-1" target="_blank">
                                <i class="ri-file-list-3-line me-1"></i> Xem & kiểm tra câu hỏi
                            </a>
                            <a href="#" id="btnEditExam" class="btn btn-outline-secondary" target="_blank">
                                <i class="ri-edit-line me-1"></i> Chỉnh sửa đề
                            </a>
                        </div>

                        {{-- Image warnings --}}
                        <div id="imageNotesSection" class="d-none">
                            <div class="alert alert-warning mb-0">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="ri-image-line me-2 fs-5"></i>
                                    <strong>Câu hỏi cần thêm ảnh thủ công:</strong>
                                </div>
                                <ul class="mb-0 ps-3" id="imageNotesList"></ul>
                            </div>
                        </div>

                        {{-- Other warnings --}}
                        <div id="warningsSection" class="d-none mt-3">
                            <div class="alert alert-soft-secondary mb-0">
                                <strong><i class="ri-error-warning-line me-1"></i>Cảnh báo:</strong>
                                <ul class="mb-0 ps-3 mt-1" id="warningsList"></ul>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Error state --}}
                <div id="errorCard" class="card d-none border-danger">
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div class="avatar-sm bg-danger-subtle rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                <i class="ri-close-line fs-4 text-danger"></i>
                            </div>
                            <div>
                                <h5 class="mb-0 text-danger">Import thất bại</h5>
                                <p class="text-muted mb-0">Kiểm tra lại định dạng file JSON</p>
                            </div>
                        </div>
                        <div class="alert alert-danger mb-0">
                            <i class="ri-error-warning-line me-1"></i>
                            <span id="errorMessage"></span>
                        </div>
                    </div>
                </div>

                {{-- Default state --}}
                <div id="defaultCard" class="card border-0" style="background: linear-gradient(135deg,#667eea15,#764ba215);">
                    <div class="card-body py-5 text-center">
                        <i class="ri-file-code-line" style="font-size:4rem;color:#667eea;opacity:.5;"></i>
                        <h5 class="mt-3 text-muted">Chọn file JSON để bắt đầu</h5>
                        <p class="text-muted small">
                            Import trực tiếp từ kết quả phân tích AI mà không cần gọi lại API.<br>
                            Hữu ích khi bạn đã có file <code>import.json</code> từ tool test.
                        </p>
                        <div class="row g-2 mt-3 justify-content-center">
                            <div class="col-auto"><span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-2"><i class="ri-check-line me-1"></i>Trắc nghiệm (mc)</span></div>
                            <div class="col-auto"><span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2"><i class="ri-check-line me-1"></i>Đúng/Sai (tf)</span></div>
                            <div class="col-auto"><span class="badge bg-warning-subtle text-warning border border-warning-subtle px-3 py-2"><i class="ri-check-line me-1"></i>Trả lời ngắn (short)</span></div>
                            <div class="col-auto"><span class="badge bg-info-subtle text-info border border-info-subtle px-3 py-2"><i class="ri-check-line me-1"></i>Đoạn văn chung</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('javascript_plugins')
<script>
$(function () {

    var jsonData = null;

    // --- Drag & Drop ---
    var $dropZone = $('#dropZone');
    var $fileInput = $('#jsonFile');

    $dropZone.on('dragover', function (e) {
        e.preventDefault();
        $dropZone.css({ borderColor: '#667eea', background: '#667eea11' });
    }).on('dragleave', function () {
        $dropZone.css({ borderColor: '#6c757d', background: '' });
    }).on('drop', function (e) {
        e.preventDefault();
        $dropZone.css({ borderColor: '#6c757d', background: '' });
        var files = e.originalEvent.dataTransfer.files;
        if (files.length) {
            $fileInput[0].files = files;
            readJsonFile(files[0]);
        }
    });

    $fileInput.on('change', function () {
        if (this.files.length) readJsonFile(this.files[0]);
    });

    function readJsonFile(file) {
        if (!file.name.endsWith('.json') && file.type !== 'application/json') {
            toastr.error('Chỉ chấp nhận file JSON!');
            return;
        }
        var sizeMB = (file.size / 1024 / 1024).toFixed(2);
        $dropZone.css({ borderColor: '#0d6efd', background: '#0d6efd11' });
        $('#dropText').html('<i class="ri-file-code-line text-primary me-1"></i><strong>' + file.name + '</strong> (' + sizeMB + ' MB)');

        var reader = new FileReader();
        reader.onload = function (e) {
            try {
                jsonData = JSON.parse(e.target.result);
                var qCount  = (jsonData.questions || []).length;
                var pgCount = (jsonData.passage_groups || []).length;
                var title   = jsonData.exam_title || '(Không có tên)';
                $('#previewText').html(
                    '<strong>' + $('<span>').text(title).html() + '</strong> — '
                    + qCount + ' câu hỏi, ' + pgCount + ' đoạn văn'
                );
                $('#previewBox').removeClass('d-none alert-danger').addClass('alert-info');
                $('#btnSubmit').prop('disabled', false);
            } catch (err) {
                jsonData = null;
                $('#previewText').text('File JSON không hợp lệ: ' + err.message);
                $('#previewBox').removeClass('d-none alert-info').addClass('alert-danger');
                $('#btnSubmit').prop('disabled', true);
            }
        };
        reader.readAsText(file, 'utf-8');
    }

    // --- Form submit ---
    $('#formJsonImport').on('submit', function (e) {
        e.preventDefault();

        if (!jsonData) {
            toastr.error('Vui lòng chọn file JSON hợp lệ trước!');
            return;
        }

        var payload = {
            json_data:  JSON.stringify(jsonData),
            exam_type:  $('#examType').val(),
            exam_id:    $('select[name=exam_id]').val(),
            subject_id: $('select[name=subject_id]').val(),
        };

        $('#defaultCard, #resultCard, #errorCard').addClass('d-none');
        $('#loadingCard').removeClass('d-none');
        $('#btnSubmit').prop('disabled', true).html('<i class="ri-loader-4-line me-1"></i> Đang import...');

        $.ajax({
            url: '/ajax/admin/exam/json-import',
            method: 'POST',
            data: payload,
            success: function (res) {
                $('#loadingCard').addClass('d-none');
                $('#btnSubmit').prop('disabled', false).html('<i class="ri-database-2-line me-1"></i> Import vào hệ thống');

                if (res.status) {
                    $('#resultTitle').text('Import thành công!');
                    $('#resultSubtitle').text(res.message);
                    $('#importedCount').text(res.imported_count);
                    $('#imageCount').text(res.image_notes ? res.image_notes.length : 0);
                    $('#btnViewExam').attr('href', '/admin/' + res.exam_id + '/questions');
                    $('#btnEditExam').attr('href', '/admin/exam/edit/' + res.exam_id);

                    if (res.image_notes && res.image_notes.length > 0) {
                        var $list = $('#imageNotesList').empty();
                        $.each(res.image_notes, function (i, note) {
                            $list.append('<li class="mb-1">' + $('<span>').text(note).html() + '</li>');
                        });
                        $('#imageNotesSection').removeClass('d-none');
                    } else {
                        $('#imageNotesSection').addClass('d-none');
                    }

                    var otherWarnings = [];
                    if (res.warnings) {
                        $.each(res.warnings, function (i, w) {
                            var isImageNote = res.image_notes && res.image_notes.indexOf(w) !== -1;
                            if (!isImageNote) otherWarnings.push(w);
                        });
                    }
                    if (otherWarnings.length > 0) {
                        var $wList = $('#warningsList').empty();
                        $.each(otherWarnings, function (i, w) {
                            $wList.append('<li class="small mb-1">' + $('<span>').text(w).html() + '</li>');
                        });
                        $('#warningsSection').removeClass('d-none');
                    } else {
                        $('#warningsSection').addClass('d-none');
                    }

                    $('#resultCard').removeClass('d-none');
                } else {
                    $('#errorMessage').text(res.message || 'Có lỗi xảy ra.');
                    $('#errorCard').removeClass('d-none');
                }
            },
            error: function (xhr) {
                $('#loadingCard').addClass('d-none');
                $('#btnSubmit').prop('disabled', false).html('<i class="ri-database-2-line me-1"></i> Import vào hệ thống');
                var msg = 'Lỗi kết nối máy chủ. Vui lòng thử lại.';
                try { var r = JSON.parse(xhr.responseText); msg = r.message || msg; } catch(e){}
                $('#errorMessage').text(msg);
                $('#errorCard').removeClass('d-none');
            }
        });
    });
});
</script>
@endsection
