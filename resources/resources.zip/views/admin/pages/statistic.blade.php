@extends('admin.layout')

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Thống kê</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Thống kê</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Main content -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Thống kê</h4>
                            <div id="line_chart_dashed" class="apex-charts" dir="ltr"></div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>

@stop
@section('javascript_plugins')
    <script src="/assets/admin/libs/apexcharts/apexcharts.min.js"></script>
    <script>
        options = {
            chart: {
                height: window.innerHeight * 0.72,
                type: "line",
                zoom: {
                    enabled: !1
                },
                toolbar: {
                    show: !1
                }
            },
            colors: ["#5664d2", "#fcb92c", "#1cbb8c", "#f1556c"],
            dataLabels: {
                enabled: !1
            },
            stroke: {
                width: [3, 4, 3],
                curve: "straight",
                dashArray: [0, 8, 5]
            },
            series: [{
                name: "Lượt truy cập",
                data: {{json_encode($data['access'])}}
            }, {
                name: "Xem khóa học",
                data: {{json_encode($data['view_course'])}}
            }, {
                name: "Xem bài học",
                data: {{json_encode($data['view_lesson'])}}
            }, {
                name: "Xem tài liệu",
                data: {{json_encode($data['view_document'])}}
            }],
            title: {
                text: "Lượt xem",
                align: "left"
            },
            markers: {
                size: 0,
                hover: {
                    sizeOffset: 6
                }
            },
            xaxis: {
                categories: {!! json_encode($data['date']) !!}
            },
            yaxis: {
                min: 0 // Đảm bảo Y bắt đầu từ 0
            },
            grid: {
                borderColor: "#f1f1f1",
                padding: {
                    bottom: 5
                }
            },
            legend: {
                offsetY: 5
            }
        };
        (chart = new ApexCharts(document.querySelector("#line_chart_dashed"), options)).render();
        $(function (){

        })
    </script>
@stop