@extends('admin.layout')

@section('content')
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="mb-0">Bình luận mới nhất</h4>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-centered mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Thời gian</th>
                                        <th>Thành viên</th>
                                        <th>Nội dung</th>
                                        <th>Chuyên mục</th>
                                        <th>Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($comments as $c)
                                    <tr>
                                        <td>{{ timeago($c->created_at) }}</td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="{{ $c->avatar ?: '/assets/images/users/avatar-1.jpg' }}" class="avatar-xs rounded-circle me-2" alt="">
                                                <span>{{ $c->display_name }}</span>
                                            </div>
                                        </td>
                                        <td style="max-width: 400px; white-space: normal;">
                                            @if($c->parent_id) <small class="text-muted d-block">Trả lời #{{$c->parent_id}}:</small> @endif
                                            {{ $c->content }}
                                        </td>
                                        <td>
                                            <span class="badge bg-soft-info text-info text-uppercase">{{ $c->type }}</span>
                                            <div class="small text-muted">ID: {{ $c->target_id }}</div>
                                        </td>
                                        <td>
                                            <a href="{{ url($c->type, ['id' => $c->target_id]) }}" target="_blank" class="btn btn-sm btn-soft-primary">Xem</a>
                                            <button class="btn btn-sm btn-soft-danger btnDelete" data-id="{{ $c->id }}">Xóa</button>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('javascript_plugins')
<script>
$(function(){
    $('.btnDelete').on('click', function(){
        if(!confirm('Xóa bình luận này?')) return;
        // Implement delete API if needed, for now just UI
        toastr.info('Tính năng đang được cập nhật');
    });
});
</script>
@endsection
