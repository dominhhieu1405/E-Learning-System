@php use Models\Web; @endphp
@extends('admin.layout')

@section('css_plugins')
    <link rel="stylesheet" type="text/css" href="/assets/admin/libs/select2/css/select2.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/css/fontawesome.min.css">

@stop

@section('content')

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Thêm tài liệu học tập</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Thêm tài liệu</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <form id="my-form" action="{{url()}}" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title mb-4">Thông tin tài liệu</h4>
                                <div class="form-group">
                                    <label for="inputName">Tên tài liệu</label>
                                    <input type="text" name="name" id="inputName" class="form-control" autocomplete="off" placeholder="Nhập tên tài liệu vào đây">
                                </div>
                                <div class="form-group">
                                    <label for="customFile">Ảnh tài liệu (4:3)</label>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="customFile" accept="image/*" onchange="loadFile(event)">
                                        <label class="custom-file-label" for="customFile">Chọn ảnh</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputType">Loại tài liệu</label>
                                    <select name="type" id="inputType" class="form-control custom-select">
                                        <option value="" class="doc-type" selected>--Chọn loại tài liệu--</option>
                                        @foreach(Web::allType() as $type)
                                            <option value="{{$type->id}}">{{$type->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="inputClass">Dành cho khối mấy?</label>
                                    <select name="class" id="inputClass" class="form-control custom-select">
                                        @foreach(Web::allClass() as $class)
                                            <option value="{{$class->id}}">{{$class->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="inputSubject">Dành cho môn học nào?</label>
                                    <select name="subject" id="inputSubject" class="form-control custom-select">
                                        <option value="0" selected>--Chọn môn học--</option>
                                        @foreach(Web::allSubject() as $subject)
                                            <option value="{{$subject->id}}">{{$subject->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group mb-4">
                                    <label for="inputContent">Nội dung tải liệu</label>
                                    <div id="dataContainer"></div>
                                    <button class="btn btn-primary " type="button" data-toggle="modal" data-target="#addElementModal">Thêm phần tử</button>
                                </div>

                                <input type="button" data-hidden="0" class="btnSubmit btn btn-success btn-block" value="Thêm tài liệu"/>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <div class="col-lg-4">
                        <div class="card card-secondary">
                            <div class="card-body">
                                <h4 class="card-title mb-4">Xem trước</h4>
                                <div class="col-12 col-lg-12" style="text-align: -webkit-center; display: none">
                                    <div class="form-group cover-preview">
                                        <img id="cover-preview" src="/assets/img/no-image.png" onerror="$(this).attr('src', '/assets/img/no-image.png')" style="width: 100%;object-fit: cover;" alt=""/>
                                    </div>
                                </div>
                                <div class="mb-2" id="nameDoc">
                                    <h4>Tên tài liệu</h4>
                                </div>
                                <hr>
                                <div id="preview-container" class="mt-2 mb-2">
                                    <div class="text-center">
                                        <b>Chưa có dữ liệu</b>
                                    </div>
                                </div>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </form>

        </div>
    </div>



    <div class="modal fade" id="addElementModal" tabindex="-1" aria-labelledby="addElementModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addElementModalLabel">Thêm/Chỉnh Sửa Phần Tử</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="elementForm">
                        <input type="hidden" id="editIndex">
                        <div class="mb-3">
                            <label for="elementType" class="form-label">Loại phần tử</label>
                            <select id="elementType" class="form-control">
                                <option value="image">Hình ảnh</option>
                                <option value="content">Nội dung</option>
                                <option value="preview">Xem trước</option>
                                <option value="button">Nút</option>
                                <option value="button-group">Nhóm nút</option>
                            </select>
                        </div>
                        <div class="mb-3" id="inputFields">
                            <label for="elementData">Link ảnh:</label><input type="text" id="elementData" class="form-control">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="saveElement">Lưu</button>
                </div>
            </div>
        </div>
    </div>

@stop

@section('javascript_plugins')
    <!-- Select2 -->
    <script src="/assets/admin/libs/bs-custom-file-input/bs-custom-file-input.min.js"></script>
    <script src="/assets/admin/libs/select2/js/select2.full.min.js"></script>
    <script>
        let data = [];

        function getGoogleDriveFileId(url) {
            const regex = /\/d\/([a-zA-Z0-9_-]+)(?:\/|$)/;
            const matches = url.match(regex);
            return matches ? matches[1] : "";
        }

        function getYoutubeVideoID(url) {
            const pattern = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/;
            const matches = url.match(pattern);
            return matches ? matches[1] : false; // Trả về video ID nếu hợp lệ, hoặc false nếu không hợp lệ
        }


        function renderData() {
            $('#dataContainer').empty();
            $("#preview-container").empty();
            data.forEach((item, index) => {
                let element = '';
                let str = '';

                if (item.type === 'image') {
                    str = ('Hình ảnh');
                    element = `<div class="text-center"><img src="${item.data}" class="img-fluid" alt="" onerror="errorImage(this)"/></div>`;
                } else if (item.type === 'content') {
                    str = ('Nội dung');
                    element = `<p>${item.data}</p>`;
                } else if (item.type === 'preview') {
                    str = ('Xem trước');
                    let src = "";
                    if (item.storage === 'googledrive') {
                        let fileId = getGoogleDriveFileId(item.data);
                         src = "https://drive.google.com/file/d/" + fileId + "/preview";
                    } else if (item.storage === 'youtube') {
                        let videoId = getYoutubeVideoID(item.data);
                         src = "https://www.youtube.com/embed/" + videoId;
                    }
                    element = `<center><div class="pdf-container"><iframe class="pdf-viewer" src="${src}" frameborder="0" allow="autoplay"></iframe></div></center>`;
                } else if (item.type === 'button') {
                    str = ('Nút');
                    element = `<div class="p-3 mb-2" style="text-align: center">
                        <a href="${item.data.url}" class="btn" style="background-color: ${item.data.color}; color: #fff;">
                            <i class="fa fa-${item.data.icon}"></i> ${item.data.text}
                        </a>
                    </div>`;
                } else if (item.type === 'button-group') {
                    str = ('Nhóm nút');
                    element = `<div class="p-3 mb-2" style="text-align: center">
                        ${item.data.map(btn => `<a href="${btn.url}" class="btn" style="background-color: ${btn.color}; color: #fff;"><i class="fa fa-${btn.icon}"></i> ${btn.text}</a>`).join(' ')}
                    </div>`;
                }
                $("#preview-container").append('<div class="mt-2 mb-2" id="preview-elm-' + index + '">' + element + '</div>');

                $('#dataContainer').append(`<div class="input-group mb-2"><input type="text" class="form-control" value="${str}" placeholder="" aria-label="" disabled><div class="input-group-append"><button class="btn btn-warning view-item" type="button" data-index="${index}">Xem phần tử</button><button class="btn btn-danger remove-item" type="button" data-index="${index}">Xóa</button></div>`);
            });

            if(window.MathJax && window.MathJax.typesetPromise) {
                window.MathJax.typesetPromise();
            }
        }

        $(document).on('click', '.remove-item', function () {
            let index = $(this).data('index');
            data.splice(index, 1);
            renderData();
        });

        $(document).on('click', '.edit-item', function () {
            let index = $(this).data('index');
            let item = data[index];
            $('#editIndex').val(index);
            $('#elementType').val(item.type).trigger('change');
        });

        $('#elementType').change(function () {
            let type = $(this).val();
            let fields = '';
            if (type === 'image') {
                fields = '<label>Link ảnh:</label><input type="text" id="elementData" placeholder="Nhập link ảnh vào đây" class="form-control">';
            } else if (type === 'preview') {
                fields = '<div class="form-group mb-2"><label>Loại tài liệu:</label><select id="elementDataType" class="form-control custom-select"><option value="googledrive">Google Drive</option><option value="youtube">Youtube</option></select></div>';
                fields += '<div class="form-group mb-2"><label>Link:</label><input type="text" id="elementData" class="form-control"></div>';
            } else if (type === 'content') {
                fields = '<label>Nội dung:</label><textarea id="elementData" class="form-control"></textarea>';
            } else if (type === 'button') {
                fields = `<div class="form-group mb-2"><label>Icon: </label>
                            <select id="buttonIcon" class="form-control custom-select">
                                <option value="" disabled selected> --Chọn icon-- </option>
                                <option value="download"> Tải xuống 1 </option>
                                <option value="down-to-line"> Tải xuống 2 </option>
                                <option value="cloud-arrow-down"> Tải xuống 3 </option>
                                <option value="up-right-from-square"> Mở liên kết </option>
                                <option value="folder-open">Thư mục</option>
                                <option value="share-nodes">Chia sẻ</option>
                            </select>
                          </div>
                          <div class="form-group mb-2"> <label>Văn bản:</label><input type="text" id="buttonText" placeholder="Nội dung muốn hiện trên nút" class="form-control"></div>
                          <div class="form-group mb-2"> <label>Màu sắc:</label>
                              <select id="buttonColor" class="form-control custom-select">
                                <option value="" disabled selected> --Chọn màu-- </option>
                                <option value="#343A40" style="background: #343A40; color: #fff"> Xám than </option>
                                <option value="#74788D" style="background: #74788D; color: #fff"> Xám xanh </option>
                                <option value="#BD2323" style="background: #BD2323; color: #fff"> Đỏ tươi </option>
                                <option value="#1BC517" style="background: #1BC517; color: #fff"> Xanh lá nhạt</option>
                                <option value="#169C87" style="background: #169C87; color: #fff"> Xanh lá đậm</option>
                                <option value="#00BED8" style="background: #00BED8; color: #fff"> Xanh lục lam </option>
                                <option value="#5186D5" style="background: #5186D5; color: #fff"> Xanh da trời </option>
                                <option value="#2339BD" style="background: #2339BD; color: #fff"> Xanh nước biển </option>
                                <option value="#804B4B" style="background: #804B4B; color: #fff">Nâu đỏ</option>
                                <option value="#DE7500" style="background: #DE7500; color: #fff">Cam sáng</option>
                                <option value="#FF66B2" style="background: #FF66B2; color: #fff">Hồng sáng</option>
                                <option value="#F48FB1" style="background: #F48FB1; color: #fff">Hồng pastel</option>
                            </select>
                          </div>
                          <div class="form-group mb-2"> <label>URL:</label><input type="text" placeholder="Link mở ra khi nhấn vào nút" id="buttonUrl" class="form-control"></div>`;
            } else if (type === 'button-group') {
                fields = '<label>Nhóm nút: </label> <button class="btn btn-sm btn-success float-end" type="button" id="addButtonList">Thêm Nút</button><div id="buttonList"></div>';
            }
            $('#inputFields').html(fields);
        });

        $(document).on('click', '#addButtonList', function () {
            $('#buttonList').append(`<div class="mb-4 btnInList">
                             <select class="form-control custom-select btn-list-icon mb-2">
                                <option value="" disabled selected> --Chọn icon-- </option>
                                <option value="download"> Tải xuống 1 </option>
                                <option value="down-to-line"> Tải xuống 2 </option>
                                <option value="cloud-arrow-down"> Tải xuống 3 </option>
                                <option value="up-right-from-square"> Mở liên kết </option>
                                <option value="folder-open">Thư mục</option>
                                <option value="share-nodes">Chia sẻ</option>
                            </select>
                            <input type="text" class="form-control btn-list-text mb-2" placeholder="Văn bản">
                            <select id="buttonColor" class="form-control custom-select btn-list-color mb-2">
                                <option value="" disabled selected> --Chọn màu-- </option>
                                <option value="#343A40" style="background: #343A40; color: #fff"> Xám than </option>
                                <option value="#74788D" style="background: #74788D; color: #fff"> Xám xanh </option>
                                <option value="#BD2323" style="background: #BD2323; color: #fff"> Đỏ tươi </option>
                                <option value="#1BC517" style="background: #1BC517; color: #fff"> Xanh lá nhạt</option>
                                <option value="#169C87" style="background: #169C87; color: #fff"> Xanh lá đậm</option>
                                <option value="#00BED8" style="background: #00BED8; color: #fff"> Xanh lục lam </option>
                                <option value="#5186D5" style="background: #5186D5; color: #fff"> Xanh da trời </option>
                                <option value="#2339BD" style="background: #2339BD; color: #fff"> Xanh nước biển </option>
                                <option value="#804B4B" style="background: #804B4B; color: #fff">Nâu đỏ</option>
                                <option value="#DE7500" style="background: #DE7500; color: #fff">Cam sáng</option>
                                <option value="#FF66B2" style="background: #FF66B2; color: #fff">Hồng sáng</option>
                                <option value="#F48FB1" style="background: #F48FB1; color: #fff">Hồng pastel</option>
                            </select>
                            <input type="text" class="form-control btn-list-link mb-2" placeholder="Link khi mở tệp">
                <button class="btn btn-danger btn-sm remove-btn">Xóa</button>
            </div>`);
        });

        $(document).on('click', '.remove-btn', function () {
            $(this).parent().remove();
        });

        $('#saveElement').click(function () {
            let index = $('#editIndex').val();
            let type = $('#elementType').val();
            let newItem = {};
            if (type === 'image' || type === 'content') {
                newItem = {type: type, data: $('#elementData').val()};
            } else if (type === 'preview') {
                newItem = {
                    type: 'preview',
                    storage: $('#elementDataType').val(),
                    data: $('#elementData').val()
                };
            } else if (type === 'button') {
                newItem = {
                    type: 'button',
                    data: {
                        icon: $('#buttonIcon').val(),
                        text: $('#buttonText').val(),
                        color: $('#buttonColor').val(),
                        url: $('#buttonUrl').val()
                    }
                };
            } else if (type === 'button-group') {
                newItem = {
                    type: 'button-group',
                    data: Array.from(document.querySelectorAll('.btnInList')).map(btn => ({
                        icon: btn.querySelector('.btn-list-icon').value,
                        text: btn.querySelector('.btn-list-text').value,
                        color: btn.querySelector('.btn-list-color').value,
                        url: btn.querySelector('.btn-list-link').value
                    }))
                };
            }
            if (index) {
                data[index] = newItem;
            } else {
                data.push(newItem);
            }
            renderData();
            $('#inputFields').html('<label>Link ảnh:</label><input type="text" id="elementData" class="form-control" placeholder="Nhập link ảnh">');
            $('#addElementModal').modal('hide');
        });
    </script>
    <script type="text/javascript">
        bsCustomFileInput.init();
        $(document).ready(function () {
            $('input').keypress(function (event) {
                if (event.which === 13) { // 13 là mã phím Enter
                    event.preventDefault(); // Ngăn chặn hành động mặc định (submit form)
                }
            });

            $("#inputName").on("keyup", function () {
                $("#nameDoc").html("<h4>" + $(this).val() + "</h4>");
            });
            $("#inputType").on("change", function () {
                if ($(".doc-type").length > 0) {
                    $(".doc-type").remove();
                }
                // No more filtering by type
            })

            $(".btnSubmit").click(function (event) {
                //stop submit the form, we will post it manually.
                event.preventDefault();

                // Get form
                const form = $('#my-form');

                // FormData object
                const ajaxData = new FormData(form[0]);
                // If you want to add an extra field for the FormData
                ajaxData.append("data", (JSON.stringify(data, null, 2)));
                ajaxData.append("image", $("#customFile")[0].files[0]);
                // disabled the submit button
                $("#btnSubmit").val("Đang thêm...").prop("disabled", true);

                $.ajax({
                    type: "POST",
                    enctype: 'multipart/form-data',
                    url: "{{url("ajax.admin.document.add")}}",
                    data: ajaxData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    success: function (data) {
                        if (data.status) {
                            toastr["success"](data.message, "Thông báo");
                        } else {
                            toastr["error"](data.message, "Thông báo");
                        }
                        $("#btnSubmit").val("Thêm tài liệu").prop("disabled", false);
                    },
                    error: function (e) {
                        toastr["error"]("Có lỗi xảy ra", "Thông báo");
                        $("#btnSubmit").val("Thêm tài liệu").prop("disabled", false);
                    }
                });
            });
        });

        const loadFile = function (event) {
            console.log("ahi");
            let output = document.getElementById('cover-preview');
            output.src = URL.createObjectURL(event.target.files[0]);
            output.onload = function () {
                URL.revokeObjectURL(output.src) // free memory
            }
        };


    </script>
@stop
