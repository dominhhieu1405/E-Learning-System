@extends('admin.layout')
@section('content')
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box"><h4 class="mb-0">Phiên thi</h4></div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="50">#</th>
                                        <th>Thí sinh</th>
                                        <th>Đề thi</th>
                                        <th width="80">Điểm</th>
                                        <th width="100">Trạng thái</th>
                                        <th width="100">Thời gian</th>
                                        <th width="150">Bắt đầu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if($sessions && count($sessions) > 0)
                                        @foreach($sessions as $s)
                                        <tr>
                                            <td>{{ $s->id }}</td>
                                            <td>{{ $s->user_display_name ?? $s->username ?? 'N/A' }}</td>
                                            <td>{{ $s->exam_title ?? 'N/A' }}</td>
                                            <td><strong>{{ $s->total_score }}</strong></td>
                                            <td>
                                                @if($s->status === 'completed')
                                                    <span class="badge bg-success">Hoàn thành</span>
                                                @elseif($s->status === 'in_progress')
                                                    <span class="badge bg-warning">Đang thi</span>
                                                @else
                                                    <span class="badge bg-info">{{ $s->status }}</span>
                                                @endif
                                            </td>
                                            <td>{{ $s->time_spent ? gmdate('H:i:s', $s->time_spent) : '—' }}</td>
                                            <td>{{ $s->started_at }}</td>
                                        </tr>
                                        @endforeach
                                    @else
                                        <tr><td colspan="7" class="text-center text-muted">Chưa có phiên thi nào</td></tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
