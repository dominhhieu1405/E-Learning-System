@extends('admin.layout')
@section('content')
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12"><div class="page-title-box"><h4 class="mb-0">Sửa câu hỏi #{{ $question->id }}</h4></div></div>
        </div>
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <form id="formQuestionEdit">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Loại</label>
                                    <input type="text" class="form-control" disabled value="{{ 
                                         $question->question_type === 'mc' ? 'Trắc nghiệm (MC)' : 
                                         ($question->question_type === 'ms' ? 'Nhiều lựa chọn (MS)' : 
                                         ($question->question_type === 'tf' ? 'Đúng/Sai (TF)' : 
                                         ($question->question_type === 'mblanks' ? 'Nhiều ô trống' :
                                         ($question->question_type === 'matching' ? 'Ghép cột' : 'Trả lời ngắn'))))
                                     }}">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Danh mục</label>
                                    <select name="bank_category" class="form-control custom-select">
                                        <option value="dinh_luong" {{ $question->bank_category === 'dinh_luong' ? 'selected' : '' }}>Định lượng</option>
                                        <option value="dinh_tinh" {{ $question->bank_category === 'dinh_tinh' ? 'selected' : '' }}>Định tính</option>
                                        <option value="tu_chon" {{ $question->bank_category === 'tu_chon' ? 'selected' : '' }}>Tự chọn</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Môn</label>
                                    <select name="subject_id" class="form-control custom-select">
                                        <option value="">--</option>
                                        @foreach($subjects as $s)
                                            <option value="{{ $s->id }}" {{ $question->subject_id == $s->id ? 'selected' : '' }}>{{ $s->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    Nội dung
                                    <div class="math-toolbar" data-target="#edContent">
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="\frac{a}{b}" title="Phân số">$\frac{a}{b}$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="\sqrt{x}" title="Căn bậc 2">$\sqrt{x}$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="x^{n}" title="Lũy thừa">$x^{n}$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="\alpha" title="Alpha">$\alpha$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="\pi" title="Pi">$\pi$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-type="image" title="Chèn ảnh"><i class="ri-image-line"></i></button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-type="audio" title="Chèn âm thanh"><i class="ri-volume-up-line"></i></button>
                                    </div>
                                </label>
                                <textarea name="content" id="edContent" class="form-control" rows="4">{{ $question->content }}</textarea>
                                <div class="mt-2 p-2 border rounded bg-light" id="preContent" style="min-height: 40px;"></div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Bài đọc</label>
                                <textarea name="passage" id="edPassage" class="form-control" rows="3">{{ $question->passage }}</textarea>
                                <div class="mt-2 p-2 border rounded bg-light" id="prePassage" style="min-height: 40px; display:none;"></div>
                            </div>

                            @if($question->question_type === 'mc')
                            @php $opts = json_decode($question->options, true) ?? [] @endphp
                            <label class="form-label">Đáp án</label>
                            @foreach(['A','B','C','D'] as $i => $letter)
                            <div class="mb-2"><div class="input-group"><span class="input-group-text">{{ $letter }}</span>
                            <input type="text" name="option_{{ strtolower($letter) }}" class="form-control" value="{{ $opts[$i] ?? '' }}"></div></div>
                            @endforeach
                            <div class="mb-3">
                                <label class="form-label">Đáp án đúng</label>
                                <select name="correct_answer" class="form-control custom-select">
                                    @foreach(['A','B','C','D'] as $l)
                                    <option value="{{ $l }}" {{ $question->correct_answer === $l ? 'selected' : '' }}>{{ $l }}</option>
                                    @endforeach
                                </select>
                            </div>
                            @elseif($question->question_type === 'ms')
                             @php 
                                 $opts = json_decode($question->options, true) ?? [];
                                 $correctArr = explode(',', $question->correct_answer);
                             @endphp
                             <label class="form-label">Đáp án</label>
                             @foreach(['A','B','C','D'] as $i => $letter)
                             <div class="mb-2"><div class="input-group"><span class="input-group-text">{{ $letter }}</span>
                             <input type="text" name="option_{{ strtolower($letter) }}" class="form-control" value="{{ $opts[$i] ?? '' }}"></div></div>
                             @endforeach
                             <div class="mb-3">
                                 <label class="form-label d-block">Đáp án đúng</label>
                                 @foreach(['A','B','C','D'] as $l)
                                 <div class="form-check form-check-inline">
                                     <input class="form-check-input" type="checkbox" name="correct_answer_ms[]" value="{{ $l }}" id="ms_{{ $l }}" {{ in_array($l, $correctArr) ? 'checked' : '' }}>
                                     <label class="form-check-label" for="ms_{{ $l }}">{{ $l }}</label>
                                 </div>
                                 @endforeach
                             </div>
                             @elseif($question->question_type === 'mblanks')
                             <div class="mb-3">
                                 <label class="form-label d-flex justify-content-between align-items-center">
                                     Đáp án các ô trống (Theo thứ tự [blank] trong câu hỏi)
                                     <button type="button" class="btn btn-xs btn-soft-success" id="btnAddBlank"><i class="ri-add-line"></i> Thêm ô</button>
                                 </label>
                                 <div id="mblanksContainer">
                                     @php $blanks = explode('|', $question->correct_answer); @endphp
                                     @foreach($blanks as $idx => $val)
                                     <div class="input-group mb-2">
                                         <span class="input-group-text">#{{ $idx + 1 }}</span>
                                         <input type="text" name="mblank_val[]" class="form-control" value="{{ $val }}" placeholder="Đáp án ô trống {{ $idx + 1 }}">
                                         <button class="btn btn-outline-danger btnRemoveBlank" type="button"><i class="ri-delete-bin-line"></i></button>
                                     </div>
                                     @endforeach
                                 </div>
                                 <small class="text-muted d-block mt-1">Lưu ý: Trong nội dung câu hỏi, hãy đánh dấu vị trí ô trống bằng chuỗi <code>[blank]</code></small>
                             </div>
                             @elseif($question->question_type === 'matching')
                             @php $pairs = json_decode($question->options, true) ?? [] @endphp
                             <label class="form-label">Các cặp ghép</label>
                             @for($i = 0; $i < 4; $i++)
                             <div class="row g-2 mb-2">
                                 <div class="col-6"><input type="text" name="matching_left_{{ $i+1 }}" class="form-control form-control-sm" value="{{ $pairs[$i]['left'] ?? '' }}" placeholder="Vế trái {{ $i+1 }}"></div>
                                 <div class="col-6"><input type="text" name="matching_right_{{ $i+1 }}" class="form-control form-control-sm" value="{{ $pairs[$i]['right'] ?? '' }}" placeholder="Vế phải {{ $i+1 }}"></div>
                             </div>
                             @endfor
                             @elseif($question->question_type === 'tf')
                            <label class="form-label">Ý con Đúng/Sai</label>
                            @foreach($tfItems as $item)
                            <div class="card card-body bg-light mb-2">
                                <div class="row align-items-center">
                                    <div class="col-1"><strong>{{ chr(96+$item->order) }})</strong></div>
                                    <div class="col-8"><input type="text" name="tf_content_{{ $item->order }}" class="form-control" value="{{ $item->content }}"></div>
                                    <div class="col-3"><select name="tf_correct_{{ $item->order }}" class="form-control custom-select">
                                        <option value="1" {{ $item->is_correct ? 'selected' : '' }}>Đúng</option>
                                        <option value="0" {{ !$item->is_correct ? 'selected' : '' }}>Sai</option>
                                    </select></div>
                                </div>
                            </div>
                            @endforeach
                            @else
                            <div class="mb-3">
                                <label class="form-label">Đáp án đúng</label>
                                <input type="text" name="correct_answer" class="form-control" value="{{ $question->correct_answer }}">
                            </div>
                            @endif

                            <div class="mb-3">
                                <label class="form-label">Giải thích</label>
                                <textarea name="explanation" class="form-control" rows="3">{{ $question->explanation }}</textarea>
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="ri-save-line"></i> Cập nhật</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('javascript_plugins')
<script>
$(function(){
    $('#formQuestionEdit').on('submit', function(e){
        e.preventDefault();
        var fd = new FormData(this);
        @if($question->question_type === 'mc')
            fd.append('options', JSON.stringify([fd.get('option_a'), fd.get('option_b'), fd.get('option_c'), fd.get('option_d')]));
        @elseif($question->question_type === 'ms')
            fd.append('options', JSON.stringify([fd.get('option_a'), fd.get('option_b'), fd.get('option_c'), fd.get('option_d')]));
            var msChecked = [];
            $('#formQuestionEdit [name="correct_answer_ms[]"]:checked').each(function() { msChecked.push($(this).val()); });
            fd.append('correct_answer', msChecked.join(','));
        @elseif($question->question_type === 'matching')
            var pairs = [];
            for(var i=1; i<=4; i++) {
                var left = fd.get('matching_left_'+i), right = fd.get('matching_right_'+i);
                if(left && right) pairs.push({left: left, right: right});
            }
            fd.append('options', JSON.stringify(pairs));
            fd.append('correct_answer', 'matching');
        @elseif($question->question_type === 'mblanks')
            var blanks = [];
            $('#mblanksContainer input[name="mblank_val[]"]').each(function() { blanks.push($(this).val()); });
            fd.append('correct_answer', blanks.join('|'));
        @elseif($question->question_type === 'tf')
            var tf = [];
            for(var i=1;i<=4;i++) tf.push({content: fd.get('tf_content_'+i), is_correct: parseInt(fd.get('tf_correct_'+i))});
            fd.append('tf_items', JSON.stringify(tf));
        @endif

        $.ajax({
            url: '/ajax/admin/question/edit/{{ $question->id }}',
            method: 'POST', data: fd, processData: false, contentType: false,
            success: function(res){ res.status ? toastr.success(res.message) : toastr.error(res.message); }
        });
    });

    function renderBlankInput(val) {
        const count = $('#mblanksContainer .input-group').length + 1;
        const html = `
        <div class="input-group mb-2">
            <span class="input-group-text">#${count}</span>
            <input type="text" name="mblank_val[]" class="form-control" value="${val}" placeholder="Đáp án ô trống ${count}">
            <button class="btn btn-outline-danger btnRemoveBlank" type="button"><i class="ri-delete-bin-line"></i></button>
        </div>`;
        $('#mblanksContainer').append(html);
    }

    $('#btnAddBlank').on('click', function() { renderBlankInput(''); });
    $(document).on('click', '.btnRemoveBlank', function() { $(this).closest('.input-group').remove(); });

    // Live Preview
    let preTimer;
    $('#edContent, #edPassage').on('input', function(){
        const val = $(this).val();
        const target = $(this).attr('id') === 'edContent' ? '#preContent' : '#prePassage';
        if($(this).attr('id') === 'edPassage') $(target).toggle(val.length > 0);
        $(target).html(val || '<small class="text-muted">Chưa có nội dung...</small>');
        clearTimeout(preTimer);
        preTimer = setTimeout(() => {
            if(window.MathJax && window.MathJax.typesetPromise) {
                window.MathJax.typesetPromise([document.querySelector(target)]);
            }
        }, 500);
    });
    // Trigger initial preview
    $('#edContent, #edPassage').trigger('input');

    // Math Toolbar
    $('.math-toolbar button').on('click', function(e){
        e.preventDefault();
        const latex = $(this).data('latex');
        const type = $(this).data('type');
        const targetId = $(this).closest('.math-toolbar').data('target');
        const $el = $(targetId);
        const start = $el[0].selectionStart, end = $el[0].selectionEnd;
        const text = $el.val();
        
        let insert = '';
        if (type === 'image') {
            const url = prompt('Nhập URL ảnh:');
            if (url) insert = `<img src="${url}" style="max-width:100%; border-radius:8px; margin:10px 0;" />`;
        } else if (type === 'audio') {
            const url = prompt('Nhập URL âm thanh (mp3, wav...):');
            if (url) insert = `<div class="mt-2 text-center"><audio controls style="max-width:100%"><source src="${url}" type="audio/mpeg">Trình duyệt không hỗ trợ nghe.</audio></div>`;
        } else {
            insert = `$${latex}$`;
        }

        if (!insert) return;

        $el.val(text.substring(0, start) + insert + text.substring(end));
        $el[0].selectionStart = $el[0].selectionEnd = start + insert.length;
        $el.focus().trigger('input');
    });
});
</script>

@endsection
