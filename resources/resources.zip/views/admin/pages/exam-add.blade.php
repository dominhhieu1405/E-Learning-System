@extends('admin.layout')
@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="mb-0">Tạo Đề thi mới</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                            <form id="formExamAdd">
                                <div class="mb-3">
                                    <label class="form-label">Tên đề thi <span class="text-danger">*</span></label>
                                    <input type="text" name="title" class="form-control" required
                                        placeholder="VD: Đề THPT Toán 2025 - Đề 01">
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3 form-group">
                                        <label class="form-label">Loại đề <span class="text-danger">*</span></label>
                                        <select name="exam_type" class="form-control custom-select" id="examType">
                                            <option value="thpt">THPT 2025</option>
                                            <option value="hsa">HSA (Đánh giá năng lực)</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3 form-group" id="subjectGroup">
                                        <label class="form-label">Môn học</label>
                                        <select name="subject_id" class="form-control custom-select">
                                            <option value="">-- Chọn môn --</option>
                                            @foreach($subjects as $s)
                                                <option value="{{ $s->id }}">{{ $s->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                {{-- THPT Duration --}}
                                <div id="thptConfig">
                                    <div class="mb-3">
                                        <label class="form-label">Thời gian làm bài (phút)</label>
                                        <input type="number" name="duration" class="form-control" value="90">
                                    </div>
                                </div>

                                {{-- HSA Config --}}
                                <div id="hsaConfig" style="display:none;">
                                    <div class="mb-3 form-group">
                                        <label class="form-label">Hình thức</label>
                                        <select name="is_random" class="form-control custom-select" id="isRandom">
                                            <option value="0">Cố định (Admin nhập câu)</option>
                                            <option value="1">Ngẫu nhiên (Bốc từ ngân hàng)</option>
                                        </select>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Thời gian P1 - Định lượng (phút)</label>
                                            <input type="number" name="duration_p1" class="form-control" value="60">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Thời gian P2 - Định tính (phút)</label>
                                            <input type="number" name="duration_p2" class="form-control" value="60">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Thời gian P3 - Tự chọn (phút)</label>
                                            <input type="number" name="duration_p3" class="form-control" value="60">
                                        </div>
                                    </div>
                                    <div id="randomConfig" style="display:none;">
                                        <div class="row">
                                            <div class="col-md-4 mb-3">
                                                <label class="form-label">Số câu P1 - Định lượng</label>
                                                <input type="number" name="random_p1" class="form-control" value="50">
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label class="form-label">Số câu P2 - Định tính</label>
                                                <input type="number" name="random_p2" class="form-control" value="50">
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label class="form-label">Số câu P3 - Tự chọn</label>
                                                <input type="number" name="random_p3" class="form-control" value="50">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mô tả đề thi</label>
                                    <textarea name="description" id="examDescription" class="form-control"></textarea>
                                </div>

                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label class="form-label">Số lần làm bài tối đa</label>
                                        <input type="number" name="attempt_limit" class="form-control" value="0" placeholder="0 = Không giới hạn">
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label class="form-label">Đảo câu hỏi</label>
                                        <select name="shuffle_questions" class="form-control custom-select">
                                            <option value="1">Bật (Mặc định)</option>
                                            <option value="0">Tắt</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label class="form-label">Hiển thị đáp án</label>
                                        <select name="show_answers" class="form-control custom-select">
                                            <option value="1">Hiện sau khi nộp bài</option>
                                            <option value="0">Ẩn (Chỉ hiện điểm)</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3 mb-3 form-group">
                                        <label class="form-label">Trạng thái</label>
                                        <select name="status" class="form-control custom-select">
                                            <option value="1">Hiển thị</option>
                                            <option value="0">Ẩn</option>
                                        </select>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary btn-lg w-100 mt-3"><i class="ri-save-line"></i> Tạo đề thi</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('css_plugins')
    <link href="/assets/admin/libs/summernote/summernote-bs4.min.css" rel="stylesheet" type="text/css" />
@endsection
@section('javascript_plugins')
    <script src="/assets/admin/libs/summernote/summernote-bs4.min.js"></script>
    <script>
        $(function () {
            $('#examDescription').summernote({
                height: 200,
                placeholder: 'Nhập mô tả đề thi, hướng dẫn làm bài...'
            });
            $('#examType').on('change', function () {
                var type = $(this).val();
                if (type === 'hsa') {
                    $('#hsaConfig').show();
                    $('#thptConfig').hide();
                    $('#subjectGroup').hide();
                } else {
                    $('#hsaConfig').hide();
                    $('#thptConfig').show();
                    $('#subjectGroup').show();
                }
            });

            $('#isRandom').on('change', function () {
                $('#randomConfig').toggle($(this).val() === '1');
            });

            $('#formExamAdd').on('submit', function (e) {
                e.preventDefault();
                var formData = new FormData(this);

                // Build random_config JSON
                if ($('#examType').val() === 'hsa' && $('#isRandom').val() === '1') {
                    formData.append('random_config', JSON.stringify({
                        p1: parseInt($('[name=random_p1]').val()) || 50,
                        p2: parseInt($('[name=random_p2]').val()) || 50,
                        p3: parseInt($('[name=random_p3]').val()) || 50,
                    }));
                }

                $.ajax({
                    url: '/ajax/admin/exam/add',
                    method: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (res) {
                        if (res.status) {
                            toastr.success(res.message);
                            setTimeout(() => location.href = '/admin/exams', 800);
                        } else {
                            toastr.error(res.message);
                        }
                    }
                });
            });
        });
    </script>
@endsection