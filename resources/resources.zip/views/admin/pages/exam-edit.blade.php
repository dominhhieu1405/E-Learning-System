@extends('admin.layout')
@section('content')
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0">Sửa đề thi: {{ $exam->title }}</h4>
                    <a href="{{ path_url('admin.exam.questions', ['id' => $exam->id]) }}" class="btn btn-info">
                        <i class="ri-list-check"></i> Quản lý câu hỏi ({{ $questionCount }})
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <form id="formExamEdit">
                            <div class="mb-3">
                                <label class="form-label font-size-14 fw-bold">Tên đề thi</label>
                                <input type="text" name="title" class="form-control" value="{{ $exam->title }}">
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label font-size-14 fw-bold">Loại đề</label>
                                    <select id="exam_type" class="form-control custom-select" disabled>
                                        <option value="thpt" {{ $exam->exam_type === 'thpt' ? 'selected' : '' }}>THPT 2025</option>
                                        <option value="hsa" {{ $exam->exam_type === 'hsa' ? 'selected' : '' }}>HSA (ĐGNL Hà Nội)</option>
                                        <option value="tsa" {{ $exam->exam_type === 'tsa' ? 'selected' : '' }}>TSA (ĐGNL Bách Khoa)</option>
                                    </select>
                                    <input type="hidden" name="exam_type" value="{{ $exam->exam_type }}">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label font-size-14 fw-bold">Đáp án & Giải thích</label>
                                    <select name="show_answers" class="form-control custom-select">
                                        <option value="1" {{ $exam->show_answers ? 'selected' : '' }}>Hiện sau khi thi</option>
                                        <option value="0" {{ !$exam->show_answers ? 'selected' : '' }}>Ẩn (Chỉ hiện điểm)</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label font-size-14 fw-bold">Số lần làm bài</label>
                                    <input type="number" name="attempt_limit" class="form-control" value="{{ $exam->attempt_limit }}" placeholder="0 = Không giới hạn">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label font-size-14 fw-bold">Đảo câu hỏi</label>
                                    <select name="shuffle_questions" class="form-control custom-select">
                                        <option value="1" {{ $exam->shuffle_questions ? 'selected' : '' }}>Bật (Mặc định)</option>
                                        <option value="0" {{ !$exam->shuffle_questions ? 'selected' : '' }}>Tắt</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label font-size-14 fw-bold">Trạng thái</label>
                                    <select name="status" class="form-control custom-select">
                                        <option value="1" {{ $exam->status ? 'selected' : '' }}>Hiển thị</option>
                                        <option value="0" {{ !$exam->status ? 'selected' : '' }}>Ẩn</option>
                                    </select>
                                </div>
                            </div>

                            <div class="card bg-light border-0 mb-3 shadow-none">
                                <div class="card-body">
                                    <h5 class="card-title mb-3 text-primary"><i class="ri-settings-4-line align-middle me-1"></i> Cấu hình Đề thi</h5>
                                    
                                    @php $config = json_decode($exam->random_config, true) ?? [] @endphp
                                    
                                    <div id="config-sections">
                                        @if($exam->exam_type === 'hsa')
                                            <!-- HSA Configuration -->
                                            <div class="row g-3">
                                                <div class="col-md-4">
                                                    <div class="form-group mb-3">
                                                        <label class="form-label text-danger fw-bold small">PHẦN 1: ĐỊNH LƯỢNG</label>
                                                        <div class="input-group mb-2">
                                                            <span class="input-group-text"><i class="ri-time-line"></i></span>
                                                            <input type="number" name="duration_p1" class="form-control" value="{{ $exam->duration_p1 }}" placeholder="Phút">
                                                        </div>
                                                        <select name="subject_p1" class="form-control custom-select">
                                                            @foreach($subjects as $s)
                                                                <option value="{{ $s->id }}" {{ ($config['p1']['subject_id'] ?? '') == $s->id ? 'selected' : '' }}>{{ $s->name }}</option>
                                                            @endforeach
                                                        </select>
                                                        @if($exam->is_random)
                                                            <div class="mt-2 small text-muted">Bốc <input type="number" name="count_p1" class="form-control form-control-sm d-inline-block" style="width:60px" value="{{ $config['p1']['count'] ?? 50 }}"> câu</div>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group mb-3">
                                                        <label class="form-label text-success fw-bold small">PHẦN 2: ĐỊNH TÍNH</label>
                                                        <div class="input-group mb-2">
                                                            <span class="input-group-text"><i class="ri-time-line"></i></span>
                                                            <input type="number" name="duration_p2" class="form-control" value="{{ $exam->duration_p2 }}" placeholder="Phút">
                                                        </div>
                                                        <select name="subject_p2" class="form-control custom-select">
                                                            @foreach($subjects as $s)
                                                                <option value="{{ $s->id }}" {{ ($config['p2']['subject_id'] ?? '') == $s->id ? 'selected' : '' }}>{{ $s->name }}</option>
                                                            @endforeach
                                                        </select>
                                                        @if($exam->is_random)
                                                            <div class="mt-2 small text-muted">Bốc <input type="number" name="count_p2" class="form-control form-control-sm d-inline-block" style="width:60px" value="{{ $config['p2']['count'] ?? 50 }}"> câu</div>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group mb-3">
                                                        <label class="form-label text-primary fw-bold small">PHẦN 3: THỜI GIAN</label>
                                                        <div class="input-group mb-2">
                                                            <span class="input-group-text"><i class="ri-time-line"></i></span>
                                                            <input type="number" name="duration_p3" class="form-control" value="{{ $exam->duration_p3 }}" placeholder="Phút">
                                                        </div>
                                                        <div class="alert alert-soft-warning p-2 small mb-0 font-size-11">Thí sinh chọn 1 nhánh</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mt-2">
                                                <div class="col-md-4">
                                                    <div class="card border border-primary shadow-none bg-transparent">
                                                        <div class="card-header bg-soft-primary py-2"><h6 class="m-0 small">NHÁNH 1: TIẾNG ANH</h6></div>
                                                        <div class="card-body p-2">
                                                            <select name="hsa_eng_subject" class="form-control custom-select mb-2 font-size-12">
                                                                @foreach($subjects as $s)
                                                                    <option value="{{ $s->id }}" {{ ($config['p3']['english']['subject_id'] ?? '') == $s->id ? 'selected' : '' }}>{{ $s->name }}</option>
                                                                @endforeach
                                                            </select>
                                                            @if($exam->is_random)
                                                            <div class="small">Bốc <input type="number" name="hsa_eng_count" class="form-control form-control-sm d-inline-block" style="width:50px" value="{{ $config['p3']['english']['count'] ?? 50 }}"></div>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-8">
                                                    <div class="card border border-success shadow-none bg-transparent">
                                                        <div class="card-header bg-soft-success py-2 d-flex justify-content-between align-items-center">
                                                            <h6 class="m-0 small">NHÁNH 2: KHOA HỌC / TỰ CHỌN</h6>
                                                            <div>
                                                                <span class="small me-1">Chọn:</span>
                                                                <input type="number" name="hsa_sci_min" class="form-control form-control-sm d-inline-block" style="width:40px" value="{{ $config['p3']['science']['min_select'] ?? 3 }}">
                                                            </div>
                                                        </div>
                                                        <div class="card-body p-2" id="hsa-science-list">
                                                            @php $sciList = $config['p3']['science']['subjects'] ?? [] @endphp
                                                            @foreach($sciList as $sci)
                                                            <div class="input-group mb-2 sci-item">
                                                                <input type="text" name="sci_label[]" class="form-control form-control-sm" placeholder="Nhãn" value="{{ $sci['label'] }}">
                                                                <select name="sci_subject[]" class="form-control custom-select form-control-sm" style="width:120px">
                                                                    @foreach($subjects as $s)
                                                                        <option value="{{ $s->id }}" {{ ($sci['subject_id'] ?? '') == $s->id ? 'selected' : '' }}>{{ $s->name }}</option>
                                                                    @endforeach
                                                                </select>
                                                                @if($exam->is_random)
                                                                <input type="number" name="sci_count[]" class="form-control form-control-sm" style="max-width:50px" value="{{ $sci['count'] ?? 10 }}">
                                                                @endif
                                                                <button type="button" class="btn btn-outline-danger btn-sm remove-sci"><i class="ri-delete-bin-line"></i></button>
                                                            </div>
                                                            @endforeach
                                                            <button type="button" class="btn btn-soft-success btn-sm w-100 mt-1" id="btn-add-sci"><i class="ri-add-line"></i> Thêm môn</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @else
                                            <!-- TSA / THPT Configuration -->
                                            <div class="row g-3">
                                                @php $maxPart = ($exam->exam_type === 'tsa') ? 3 : 1 @endphp
                                                @for($i = 1; $i <= $maxPart; $i++)
                                                <div class="col-md-4">
                                                    <label class="form-label fw-bold small">PHẦN {{ $i }}</label>
                                                    <div class="input-group mb-2">
                                                        <span class="input-group-text"><i class="ri-time-line"></i></span>
                                                        <input type="number" name="duration_p{{$i}}" class="form-control" value="{{ $exam->{'duration_p'.$i} ?? ( ($i==1) ? $exam->duration : 0) }}" placeholder="Phút">
                                                    </div>
                                                    <select name="subject_p{{$i}}" class="form-control custom-select">
                                                        @foreach($subjects as $s)
                                                            <option value="{{ $s->id }}" {{ ($config['p'.$i]['subject_id'] ?? (($i==1) ? $exam->subject_id : '')) == $s->id ? 'selected' : '' }}>{{ $s->name }}</option>
                                                        @endforeach
                                                    </select>
                                                    @if($exam->is_random)
                                                        <div class="mt-2 small text-muted">Bốc <input type="number" name="count_p{{$i}}" class="form-control form-control-sm d-inline-block" style="width:60px" value="{{ $config['p'.$i]['count'] ?? 50 }}"> câu</div>
                                                    @endif
                                                </div>
                                                @endfor
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label font-size-14 fw-bold">Mô tả đề thi</label>
                                <textarea name="description" id="examDescription" class="form-control">{!! $exam->description !!}</textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-lg w-100 shadow-sm"><i class="ri-save-line me-1"></i> Lưu & Đồng bộ Môn học</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('css_plugins')
<link href="/assets/admin/libs/summernote/summernote-bs4.min.css" rel="stylesheet" type="text/css" />
@endsection
@section('javascript_plugins')
<script src="/assets/admin/libs/summernote/summernote-bs4.min.js"></script>
<script>
$(function(){
    $('#examDescription').summernote({
        height: 200,
        placeholder: 'Nhập mô tả đề thi, hướng dẫn làm bài...'
    });

    // Handle Science Subjects (Part 3 HSA)
    $('#btn-add-sci').on('click', function(){
        const html = `
            <div class="input-group mb-2 sci-item">
                <input type="text" name="sci_label[]" class="form-control form-control-sm" placeholder="Nhãn">
                <select name="sci_subject[]" class="form-control custom-select form-control-sm" style="width:120px">
                    @foreach($subjects as $s)
                        <option value="{{ $s->id }}">{{ $s->name }}</option>
                    @endforeach
                </select>
                @if($exam->is_random)
                <input type="number" name="sci_count[]" class="form-control form-control-sm" style="max-width:50px" value="10">
                @endif
                <button type="button" class="btn btn-outline-danger btn-sm remove-sci"><i class="ri-delete-bin-line"></i></button>
            </div>
        `;
        $('#hsa-science-list').prepend(html);
    });

    $(document).on('click', '.remove-sci', function(){
        $(this).closest('.sci-item').remove();
    });

    $('#formExamEdit').on('submit', function(e){
        e.preventDefault();
        const type = '{{ $exam->exam_type }}';
        let config = {};

        if(type === 'hsa'){
            config = {
                p1: { subject_id: $('[name=subject_p1]').val(), count: parseInt($('[name=count_p1]').val()) || 0 },
                p2: { subject_id: $('[name=subject_p2]').val(), count: parseInt($('[name=count_p2]').val()) || 0 },
                p3: {
                    english: { subject_id: $('[name=hsa_eng_subject]').val(), count: parseInt($('[name=hsa_eng_count]').val()) || 0 },
                    science: {
                        min_select: parseInt($('[name=hsa_sci_min]').val()) || 0,
                        subjects: []
                    }
                }
            };
            $('.sci-item').each(function(){
                config.p3.science.subjects.push({
                    label: $(this).find('[name="sci_label[]"]').val(),
                    subject_id: $(this).find('[name="sci_subject[]"]').val(),
                    count: parseInt($(this).find('[name="sci_count[]"]').val()) || 0
                });
            });
        } else {
            // TSA / THPT
            config = {
                p1: { subject_id: $('[name=subject_p1]').val(), count: parseInt($('[name=count_p1]').val()) || 0 }
            };
            if(type === 'tsa'){
                config.p2 = { subject_id: $('[name=subject_p2]').val(), count: parseInt($('[name=count_p2]').val()) || 0 };
                config.p3 = { subject_id: $('[name=subject_p3]').val(), count: parseInt($('[name=count_p3]').val()) || 0 };
            }
        }

        var formData = new FormData(this);
        formData.append('random_config', JSON.stringify(config));

        $.ajax({
            url: '/ajax/admin/exam/edit/{{ $exam->id }}',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(res){
                if(res.status) {
                    toastr.success(res.message);
                    setTimeout(() => location.reload(), 800);
                } else {
                    toastr.error(res.message);
                }
            }
        });
    });
});
</script>
@endsection
