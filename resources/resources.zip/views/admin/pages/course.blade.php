@extends('admin.layout')

@section('css_plugins')

@stop

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">{{$course->name}}</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Khóa học</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Main content -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">
                                Danh sách bài học
                                <div class="float-right btn-group">
                                    <a class="btn btn-sm btn-success float-right" href="#" data-toggle="modal" data-target="#addUnitModal">
                                        <i class="fas fa-plus"></i>
                                        Chương
                                    </a>
                                    <a href="{{url("admin.course.lesson.add", ["id" => $course->id])}}" class="btn btn-sm btn-primary">
                                        <i class="fas fa-plus"></i>
                                        Bài học
                                    </a>
                                    @if(\Models\User::isAdmin())
                                        <a href="{{url("admin.course.lesson.bulk-add", ["id" => $course->id])}}" class="btn btn-sm btn-dark">
                                            <i class="fas fa-plus"></i>
                                            Thêm nhiều bài học
                                        </a>
                                    @endif
                                </div>
                            </h4>

                            <form class="mb-2" type="POST" action="">
                                <div class="input-group">
                                    <!-- /btn-group -->
                                    <input type="text" class="form-control" name="search" id="search-course" value="" placeholder="Tìm kiếm bài học..." aria-label="">
                                    <span class="input-group-append">
                                        <button type="submit" class="btn btn-info btn-flat">Reset</button>
                                    </span>
                                </div>
                            </form>

                            <div id="table_wrapper">
                                <div class="row">
                                    <div class="col-sm-12 table-responsive">
                                        <table id="table" style=" min-width: 700px; " class="table table-bordered table-hover dataTable dtr-inline" role="grid" aria-describedby="table">
                                            <thead>
                                            <tr>
                                                <th style="width: 60px;">#</th>
                                                <th>Tên</th>
                                                <th style="width: 80px;">Lượt xem</th>
                                                <th style="width: 150px;">Cập nhật</th>
                                                <th style="width: 123px"></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @if($units && count($units) > 0)
                                                @foreach($units as $i => $unit)
                                                    <tr data-id="unit-{{ $unit->id }}" class="course-unit">
                                                        <th colspan="4">
                                                            <h5><b>{{intToRoman(++$i)}}. <span id="unit-{{ $unit->id }}-name">{{ $unit->name }}</span></b></h5>
                                                        </th>
                                                        <td class="text-center">
                                                            <div class="pt-1"></div>
                                                            <button type="button" class="btn btn-info btn-sm edit-unit" data-id="{{$unit->id}}">
                                                                Sửa
                                                            </button>
                                                            <button type="button" class="btn btn-danger btn-sm delete-unit" data-id="{{$unit->id}}">
                                                                Xóa
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    @foreach(\Models\Web::courseUnitLesson($unit->id) as $j => $lesson)
                                                        <tr data-id="lesson-{{$lesson->id}}" class="course-lesson course-unit-{{$unit->id}}">
                                                            <td>{{$j+1}}</td>
                                                            <td class="lesson-name">{{$lesson->name}}</td>
                                                            <td>{{number_format($lesson->views)}}</td>
                                                            <td>{{date("d/m/y H:i", strtotime($lesson->time_update))}}</td>
                                                            <td>
                                                                <a href="{{url("admin.course.lesson.edit", ["id" => $lesson->id])}}" type="button" class="btn btn-success btn-sm" data-id="{{$lesson->id}}">
                                                                    Sửa
                                                                </a>
                                                                <button type="button" class="btn btn-dark btn-sm delete-lesson" data-id="{{$lesson->id}}">
                                                                    Xóa
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                @endforeach
                                            @else
                                                <td colspan="5">
                                                    <div class="d-flex justify-content-center ">
                                                        Chưa có phần nào...
                                                    </div>
                                                </td>
                                            @endif
                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>


    <div class="modal fade" id="addUnitModal" tabindex="-1" aria-labelledby="addUnitModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUnitModalLabel">Thêm chương</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="mb-3" id="inputFields">
                        <label for="addName">Tên chương:</label>
                        <input type="text" id="addName" class="form-control" placeholder="Không cần nhập số thứ tự ở đầu, hệ thống tự thêm">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="addUnit">Lưu</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editUnitModal" tabindex="-1" aria-labelledby="editUnitModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUnitModalLabel">Sửa chương</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="editIndex">
                    <div class="mb-3" id="inputFields">
                        <label for="editName">Tên chương:</label>
                        <input type="text" id="editName" class="form-control" placeholder="Không cần nhập số thứ tự ở đầu, hệ thống tự thêm">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="editUnit">Lưu</button>
                </div>
            </div>
        </div>
    </div>
@stop


@section('javascript_plugins')
    <script>
        $(function (){
            $("#addUnit").on("click", function (){
                let $name = $("#addName").val();
                $.post("{{url("ajax.admin.course.unit.add")}}", {course: "{{$course->id}}", name: $name}, function (data){
                    if(data.status){
                        $("#addUnitModal").modal("hide");
                        $("#table tbody").append(`
                            <tr data-id="unit-${data.id}" class="course-unit">
                                <th colspan="4">
                                    <h5><b><span id="unit-${data.id}-name">${data.name}</span></b></h5>
                                </th>
                                <td class="text-center">
                                    <div class="pt-1"></div>
                                    <button type="button" class="btn btn-info btn-sm edit-unit" data-id="${data.id}">
                                        Sửa
                                    </button>
                                    <button type="button" class="btn btn-danger btn-sm delete-unit" data-id="${data.id}">
                                        Xóa
                                    </button>
                                </td>
                            </tr>
                        `)
                        toastr["success"]("Đã thêm chương", "Thông báo");
                    }else{
                        toastr["error"]("Có lỗi xảy ra", "Thông báo");
                    }
                })
            });
            $("#editUnit").on("click", function (){
                let $id = $("#editIndex").val();
                let $name = $("#editName").val();
                $.post("{{url("ajax.admin.course.unit.edit")}}", {id: $id, name: $name}, function (data){
                    if(data.status){
                        $("#editUnitModal").modal("hide");
                        $("#unit-"+$id+"-name").text($name);
                        toastr["success"]("Đã sửa chương", "Thông báo");
                    }else{
                        toastr["error"]("Có lỗi xảy ra", "Thông báo");
                    }
                })
            });

            $(document).on("click", ".edit-unit", function (){
                let $id = $(this).data("id");
                let $name = $("#unit-"+$id+"-name").text();
                $("#editIndex").val($id);
                $("#editName").val($name);
                $("#editUnitModal").modal("show");
            })

            $(document).on("click", ".delete-unit", function (){
                var id = $(this).data("id");
                if(confirm("Bạn có chắc chắn muốn xóa chương này không?")){
                    $.post("{{url("ajax.admin.course.unit.delete")}}", {id: id}, function (data){
                        if(data.status){
                            $("tr[data-id=unit-"+id+"]").remove();
                            $(".course-unit-"+id).remove();
                            toastr["success"]("Đã xóa chương", "Thông báo");
                        }else{
                            toastr["error"]("Có lỗi xảy ra", "Thông báo");
                        }
                    })
                }
            })
            $(document).on("click", ".delete-lesson", function (){
                var id = $(this).data("id");
                if(confirm("Bạn có chắc chắn muốn xóa bài này không?")){
                    $.post("{{url("ajax.admin.course.lesson.delete")}}", {id: id}, function (data){
                        if(data.status){
                            $("tr[data-id=lesson-"+id+"]").remove();
                            toastr["success"]("Đã xóa bài", "Thông báo");
                        }else{
                            toastr["error"]("Có lỗi xảy ra", "Thông báo");
                        }
                    })
                }
            })
            $("#search-course").on("keyup", function (){
                var value = $(this).val().toLowerCase();
                $("#table tr.course-lesson").filter(function (){
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                })
            })
        })
    </script>
@stop