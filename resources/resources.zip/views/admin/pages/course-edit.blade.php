@php use Models\Web; @endphp
@extends('admin.layout')



@section('content')

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Sửa khóa học</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Sửa khóa học</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <form id="my-form" action="{{url()}}" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title mb-4">Thông tin khóa học</h4>
                                <div class="form-group">
                                    <label for="inputName">Tên khóa học</label>
                                    <input type="text" name="name" id="inputName" class="form-control" autocomplete="off" placeholder="Nhập tên khóa học vào đây" value="{{$course->name}}">
                                </div>
                                <div class="form-group">
                                    <label for="customFile">Ảnh khóa học (4:3)</label>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="customFile" accept="image/*">
                                        <label class="custom-file-label" for="customFile">{{$course->image}}</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputDescription">Mô tả khóa học</label>
                                    <textarea name="description" id="inputDescription" class="form-control" rows="4" placeholder="Nhập mô tả khóa học vào đây">{{$course->description}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label for="inputType">Loại khóa học</label>
                                    <select name="type" id="inputType" class="form-control custom-select">
                                        @foreach($types as $type)
                                            <option value="{{$type->id}}" @if($course->type == $type->id) selected @endif>{{$type->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="inputClass">Dành cho khối mấy?</label>
                                    <select name="class" id="inputClass" class="form-control custom-select">
                                        @foreach($classes as $class)
                                            <option value="{{$class->id}}" @if($course->class == $class->id) selected @endif>{{$class->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="inputSubject">Dành cho môn học nào?</label>
                                    <select name="subject" id="inputSubject" class="form-control custom-select" >
                                        @foreach($subjects as $subject)
                                            <option value="{{$subject->id}}" @if($course->subject == $subject->id) selected @endif>{{$subject->name}}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <input type="button" data-hidden="0" class="btnSubmit btn btn-success btn-block" value="Lưu thay đổi"/>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </form>

        </div>
    </div>
@stop

@section('javascript_plugins')
    <!-- Select2 -->
    <script src="/assets/admin/libs/bs-custom-file-input/bs-custom-file-input.min.js"></script>
    <script src="/assets/admin/libs/select2/js/select2.full.min.js"></script>
    <script type="text/javascript">
        bsCustomFileInput.init();
        $(document).ready(function () {
            $('input').keypress(function (event) {
                if (event.which === 13) { // 13 là mã phím Enter
                    event.preventDefault(); // Ngăn chặn hành động mặc định (submit form)
                }
            });

            $("#inputName").on("keyup", function () {
                $("#nameDoc").html("<h4>" + $(this).val() + "</h4>");
            });
            $("#inputType").on("change", function () {
                // No more filtering by type
            })

            $(".btnSubmit").click(function (event) {
                //stop submit the form, we will post it manually.
                event.preventDefault();

                // Get form
                const form = $('#my-form');

                // FormData object
                const ajaxData = new FormData(form[0]);
                // If you want to add an extra field for the FormData
                ajaxData.append("image", $("#customFile")[0].files[0]);
                // disabled the submit button
                $("#btnSubmit").val("Đang thêm...").prop("disabled", true);

                $.ajax({
                    type: "POST",
                    enctype: 'multipart/form-data',
                    url: "{{url("ajax.admin.course.edit", ["id" => $course->id])}}",
                    data: ajaxData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    success: function (data) {
                        if (data.status) {
                            toastr["success"](data.message, "Thông báo");
                        } else {
                            toastr["error"](data.message, "Thông báo");
                        }
                        $("#btnSubmit").val("Thêm khóa học").prop("disabled", false);
                    },
                    error: function (e) {
                        toastr["error"]("Có lỗi xảy ra", "Thông báo");
                        $("#btnSubmit").val("Thêm khóa học").prop("disabled", false);
                    }
                });
            });
        });


    </script>
@stop
