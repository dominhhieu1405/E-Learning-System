@extends('admin.layout')


@section('css_plugins')
    <!-- DataTables -->
    <link href="/assets/admin/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/admin/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/fontawesome.min.css" rel="stylesheet" type="text/css">
@stop

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Quản lý Tài liệu</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Quản lý Tài liệu</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Main content -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">
                                Danh sách Tài liệu
                                <a class="btn btn-sm btn-success float-right" href="{{url("admin.document.add")}}">
                                    <i class="fas fa-plus"></i>
                                    Thêm
                                </a>
                            </h4>

                            <div class="table-responsive">
                                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead>
                                    <tr class="text-center">
                                        <th>#</th>
                                        <th style="width: 100px">Ảnh</th>
                                        <th>Tên</th>
                                        <th style="width: 80px">Lượt xem</th>
                                        <th>Cập nhật</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody class="text-center">
                                    @foreach($documents as $document)
                                        <tr>
                                            <td>{{$document->id}}</td>
                                            <td><img src="{{$document->image}}" onerror="errorImage(this)" style="width: 90px" alt="{{$document->name}}"></td>
                                            <td>{{$document->name}}</td>
                                            <td class="text-center">{{number_format($document->views)}}</td>
                                            <td class="text-center">{{date("d/m/Y H:i", strtotime($document->time_update))}}</td>
                                            <td>
                                                <a href="{{url("admin.document.edit", ['id' => $document->id])}}" class="btn btn-success btn-sm">Sửa</a>
                                                <a href="javascript:void(0)" class="btn btn-danger btn-sm delete-document" data-id="{{$document->id}}">Xóa</a>
                                            </td>
                                        </tr>
                                    @endforeach

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>

    <!-- /.modal -->
@stop

@section('javascript_plugins')
    <!-- Required datatable js -->
    <script src="/assets/admin/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="/assets/admin/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(function (){
            $(".delete-document").on("click", function (){
                var id = $(this).data("id");
                if(confirm("Bạn có chắc chắn muốn xóa tài liệu này không?")){
                    $.post(
                        "{{url("ajax.admin.document.delete")}}",
                        {
                            id: id
                        },
                        function (e){
                            if(e.status){
                                alert("Xóa tài liệu thành công");
                                location.reload();
                            }else{
                                alert("Xóa tài liệu thất bại");
                            }
                        }, 'json'
                    )
                }
            })

            var table = $("#datatable").DataTable({
                "autoWidth": true,
                'columnDefs': [ {
                    'targets': [0,1,5], /* column index */
                    'orderable': false, /* true or false */
                },
                    {
                        "targets": 0,
                        "width": "29px"
                    },
                    {
                        "targets": 1,
                        "width": "100px"
                    },
                    {
                        "targets": 3,
                        "width": "80px"
                    },
                    {
                        "targets": 4,
                        "width": "160px"
                    },
                    {
                        "targets": 5,
                        "width": "100px"
                    }
                ],
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function () {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                }
            });

        })
    </script>
@stop
