@extends('admin.layout')
@section('content')
    @php
        $mathToolbar = function ($target) {
            return '
                        <div class="math-toolbar" data-target="' . $target . '">
                            <button type="button" class="btn btn-xs btn-outline-info" data-latex="\frac{a}{b}" title="Phân số">$\frac{a}{b}$</button>
                            <button type="button" class="btn btn-xs btn-outline-info" data-latex="\sqrt{x}" title="Căn bậc 2">$\sqrt{x}$</button>
                            <button type="button" class="btn btn-xs btn-outline-info" data-latex="x^{n}" title="Lũy thừa">$x^{n}$</button>
                            <button type="button" class="btn btn-xs btn-outline-info" data-latex="\pi" title="Pi">$\pi$</button>
                            <button type="button" class="btn btn-xs btn-outline-info" data-type="image" title="Chèn ảnh"><i class="ri-image-line"></i></button>
                            <button type="button" class="btn btn-xs btn-outline-info" data-type="audio" title="Chèn âm thanh"><i class="ri-volume-up-line"></i></button>
                            <button type="button" class="btn btn-xs btn-outline-info" data-type="link" title="Chèn link"><i class="ri-link"></i></button>
                        </div>';
        };
    @endphp
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Quản lý câu hỏi: {{ $exam->title }}</h4>
                        <div class="page-title-right">
                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalAdd"><i
                                    class="ri-add-line"></i> Thêm câu hỏi mới</button>
                            <a href="{{ path_url('admin.exam.edit', ['id' => $exam->id]) }}"
                                class="btn btn-outline-secondary btn-sm"><i class="ri-settings-4-line"></i> Cài đặt đề</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    @php 
                        $config = json_decode($exam->random_config, true) ?? [];
                        $sections = [];
                        
                        // Part 1
                        $sections[] = [
                            'part' => 1,
                            'label' => $config['p1']['label'] ?? ($exam->exam_type === 'hsa' ? 'Phần 1: Định lượng' : 'Phần 1'),
                            'subject_id' => $config['p1']['subject_id'] ?? $exam->subject_id,
                            'branch' => ''
                        ];
                        
                        // Part 2
                        if($exam->exam_type === 'thpt') {
                            $sections[] = [
                                'part' => 2,
                                'label' => $config['p2']['label'] ?? 'Phần 2: Đúng/Sai',
                                'subject_id' => $config['p2']['subject_id'] ?? $exam->subject_id,
                                'branch' => ''
                            ];
                        } elseif($exam->exam_type !== 'thpt') {
                            $sections[] = [
                                'part' => 2,
                                'label' => $config['p2']['label'] ?? ($exam->exam_type === 'hsa' ? 'Phần 2: Định tính' : 'Phần 2'),
                                'subject_id' => $config['p2']['subject_id'] ?? '',
                                'branch' => ''
                            ];
                        }
                        
                        // Part 3
                        if($exam->exam_type === 'thpt') {
                            $sections[] = [
                                'part' => 3,
                                'label' => $config['p3']['label'] ?? 'Phần 3: Trả lời ngắn',
                                'subject_id' => $config['p3']['subject_id'] ?? $exam->subject_id,
                                'branch' => ''
                            ];
                        } elseif($exam->exam_type === 'hsa') {
                            // English Branch
                            $sections[] = [
                                'part' => 3,
                                'label' => 'Phần 3: Tiếng Anh',
                                'subject_id' => $config['p3']['english']['subject_id'] ?? '',
                                'branch' => 'Anh'
                            ];
                            // Science Branches
                            $sciSubjects = $config['p3']['science']['subjects'] ?? [];
                            foreach($sciSubjects as $sci) {
                                $sections[] = [
                                    'part' => 3,
                                    'label' => 'Phần 3: ' . ($sci['label'] ?? 'Chọn môn'),
                                    'subject_id' => $sci['subject_id'] ?? '',
                                    'branch' => $sci['label'] ?? ''
                                ];
                            }
                        } else if($exam->exam_type === 'tsa') {
                            $sections[] = [
                                'part' => 3,
                                'label' => 'Phần 3',
                                'subject_id' => $config['p3']['subject_id'] ?? '',
                                'branch' => ''
                            ];
                        }
                    @endphp

                    @foreach($sections as $sec)
                        @php
                            $qs = collect($questions)->where('part', $sec['part']);
                            if(!empty($sec['branch'])) {
                                $qs = $qs->where('branch', $sec['branch']);
                            }
//                                                if ($sec["part"] == 3 && $exam->exam_type == 'hsa') {
//                                                    $qs = $qs->where('subject_id', $sec['subject_id']);
//                                                }
                            $qs = $qs->sortBy('order');
                        @endphp
                        <div class="card mb-4 border shadow-none">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                                <h6 class="mb-0 fw-bold">
                                    <span class="text-primary me-2">{{ $sec['label'] }}</span>
                                    @php $sName = collect($subjects)->firstWhere('id', $sec['subject_id'])->name ?? 'Chưa gán môn' @endphp
                                    - ({{count($qs)}} câu)
                                    <span class="badge bg-soft-secondary text-secondary font-size-11 fw-normal">ID Môn: {{ $sec['subject_id'] }} ({{ $sName }})</span>
                                </h6>
                                <button class="btn btn-primary btn-sm btnAddSection" 
                                    data-part="{{ $sec['part'] }}" 
                                    data-subject="{{ $sec['subject_id'] }}"
                                    data-branch="{{ $sec['branch'] }}">
                                    <i class="ri-add-line"></i> Thêm câu hỏi
                                </button>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th style="width: 60px;">STT</th>
                                                <th style="width: 80px;">Loại</th>
                                                <th>Nội dung</th>
                                                <th style="width: 150px;">Đáp án</th>
                                                <th style="width: 100px;">Thao tác</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse($qs as $q)
                                                <tr>
                                                    <td><strong>{{ $q->order }}</strong></td>
                                                    <td>
                                                        @if($q->question_type === 'mc') <span class="badge bg-soft-info text-info">MC</span>
                                                        @elseif($q->question_type === 'ms') <span class="badge bg-soft-primary text-primary">MS</span>
                                                        @elseif($q->question_type === 'tf') <span class="badge bg-soft-warning text-warning">TF</span>
                                                        @elseif($q->question_type === 'mblanks') <span class="badge bg-soft-danger text-danger">Blanks</span>
                                                        @elseif($q->question_type === 'matching') <span class="badge bg-soft-secondary text-secondary">Match</span>
                                                        @else <span class="badge bg-soft-success text-success">Short</span> @endif
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate" style="max-width: 400px;">
                                                            {!! strip_tags($q->content) !!}
                                                        </div>
                                                        @if($q->passage) <small class="text-primary font-size-11"><i class="ri-book-read-line"></i> Có bài đọc</small> @endif
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate font-size-12" style="max-width: 150px;">
                                                            {!! strip_tags($q->correct_answer) !!}
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-icon btn-soft-primary btnEdit"
                                                            data-id="{{ $q->id }}" data-data="{{ json_encode($q) }}"><i
                                                                class="ri-edit-2-line"></i></button>
                                                        <button class="btn btn-sm btn-icon btn-soft-danger btnDelete"
                                                            data-id="{{ $q->id }}"><i class="ri-delete-bin-line"></i></button>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="5" class="text-center py-3 text-muted small">Trống...</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    {{-- Modal Add/Edit --}}
    <div class="modal fade" id="modalAdd" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="formQuestion">
                    <input type="hidden" name="id" id="qId">
                    <input type="hidden" name="subject_id" id="qSubject">
                    <input type="hidden" name="branch" id="qBranch">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTitle">Thêm câu hỏi mới</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body" style="max-height: 80vh; overflow-y: auto;">
                        <div class="alert alert-soft-info py-2 mb-3">
                            <i class="ri-information-line me-1"></i> Môn học: <span id="lblSubjectName" class="fw-bold">...</span>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Phần</label>
                                <select name="part" class="form-control custom-select" id="qPart" readonly style="pointer-events: none;">
                                    <option value="1">Phần 1</option>
                                    <option value="2">Phần 2</option>
                                    <option value="3">Phần 3</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Thứ tự hiển thị</label>
                                <input type="number" name="order" class="form-control" value="0">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Loại câu hỏi</label>
                                <select name="question_type" class="form-control custom-select" id="qType">
                                    <option value="mc">Trắc nghiệm (MC)</option>
                                    <option value="ms">Nhiều lựa chọn (MS)</option>
                                    <option value="tf">Đúng/Sai (TF)</option>
                                    <option value="short">Trả lời ngắn</option>
                                    <option value="mblanks">Nhiều ô trống</option>
                                    <option value="matching">Ghép cột</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label d-flex justify-content-between align-items-center">
                                Nội dung câu hỏi
                                {!! $mathToolbar('#editorContent') !!}
                            </label>
                            <textarea name="content" class="form-control rich-editor" rows="3" required
                                id="editorContent"></textarea>
                            <div class="preview-box mt-1" id="preview_editorContent"></div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label d-flex justify-content-between align-items-center">
                                Bài đọc đi kèm (nếu có)
                                {!! $mathToolbar('#editorPassage') !!}
                            </label>
                            <textarea name="passage" class="form-control rich-editor" rows="2"
                                id="editorPassage"></textarea>
                            <div class="preview-box mt-1" id="preview_editorPassage"></div>
                        </div>

                        {{-- MC / MS --}}
                        <div id="mcOptions">
                            <label class="form-label">Các lựa chọn & Đáp án</label>
                            <div class="row g-2 mb-3">
                                @foreach(['A', 'B', 'C', 'D'] as $label)
                                    <div class="col-md-6 mb-2">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span class="badge bg-light text-dark">Lựa chọn {{ $label }}</span>
                                            {!! $mathToolbar('[name=option_' . strtolower($label) . ']') !!}
                                        </div>
                                        <textarea name="option_{{ strtolower($label) }}" class="form-control rich-editor"
                                            rows="1"></textarea>
                                        <div class="preview-box mt-1" id="preview_option_{{strtolower($label)}}"></div>
                                    </div>
                                @endforeach
                            </div>
                            <div class="mb-3" id="mcSingleCorrect">
                                <label class="form-label">Đáp án đúng</label>
                                <select name="correct_answer_mc" class="form-control custom-select">
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                    <option value="D">D</option>
                                </select>
                            </div>
                            <div class="mb-3" id="mcMultiCorrect" style="display:none;">
                                <label class="form-label d-block">Đáp án đúng (chọn nhiều)</label>
                                @foreach(['A', 'B', 'C', 'D'] as $label)
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" name="correct_answer_ms[]" value="{{ $label }}" id="ms_{{ $label }}">
                                    <label class="form-check-label" for="ms_{{ $label }}">{{ $label }}</label>
                                </div>
                                @endforeach
                            </div>
                        </div>

                        {{-- Multiple Blanks --}}
                        <div id="mblanksOptions" style="display:none;">
                            <label class="form-label d-flex justify-content-between align-items-center">
                                Đáp án các ô trống (Theo thứ tự [blank] trong câu hỏi)
                                <button type="button" class="btn btn-xs btn-soft-success" id="btnAddBlank"><i class="ri-add-line"></i> Thêm ô</button>
                            </label>
                            <div id="mblanksContainer">
                                {{-- Inputs added here --}}
                            </div>
                            <small class="text-muted d-block mt-1">Lưu ý: Trong nội dung câu hỏi, hãy đánh dấu vị trí ô trống bằng chuỗi <code>[blank]</code></small>
                        </div>

                        {{-- Matching --}}
                        <div id="matchingOptions" style="display:none;">
                            <label class="form-label">Cấu trúc ghép cột (Nhập các cặp tương ứng)</label>
                            <div id="matchingPairs">
                                @for($i = 1; $i <= 4; $i++)
                                <div class="row g-2 mb-2 align-items-center">
                                    <div class="col-1 text-center"><strong>{{ $i }}.</strong></div>
                                    <div class="col-5">
                                        <input type="text" name="matching_left_{{ $i }}" class="form-control form-control-sm" placeholder="Vế trái {{ $i }}">
                                    </div>
                                    <div class="col-1 text-center"><i class="ri-arrow-left-right-line"></i></div>
                                    <div class="col-5">
                                        <input type="text" name="matching_right_{{ $i }}" class="form-control form-control-sm" placeholder="Vế phải {{ $i }}">
                                    </div>
                                </div>
                                @endfor
                            </div>
                        </div>

                        {{-- TF --}}
                        <div id="tfOptions" style="display:none;">
                            <label class="form-label">4 ý Đúng/Sai</label>
                            @for($i = 1; $i <= 4; $i++)
                                <div class="card card-body bg-light mb-2">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <strong>{{ chr(96 + $i) }}) Nội dung ý</strong>
                                        {!! $mathToolbar('[name=tf_content_' . $i . ']') !!}
                                    </div>
                                    <textarea name="tf_content_{{ $i }}" class="form-control rich-editor" rows="1"></textarea>
                                    <div class="preview-box mt-1" id="preview_tf_content_{{$i}}"></div>
                                    <div class="mt-2">
                                        <select name="tf_correct_{{ $i }}" class="form-control custom-select">
                                            <option value="1">Đúng</option>
                                            <option value="0">Sai</option>
                                        </select>
                                    </div>
                                </div>
                            @endfor
                        </div>

                        {{-- Short --}}
                        <div id="shortOptions" style="display:none;">
                            <div class="mb-3">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    Đáp án chính xác
                                    {!! $mathToolbar('[name=correct_answer_short]') !!}
                                </label>
                                <textarea name="correct_answer_short" class="form-control rich-editor" rows="1"></textarea>
                                <div class="preview-box mt-1" id="preview_correct_answer_short"></div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label d-flex justify-content-between align-items-center">
                                Giải thích (nếu có)
                                {!! $mathToolbar('#editorExplanation') !!}
                            </label>
                            <textarea name="explanation" id="editorExplanation" class="form-control rich-editor"
                                rows="2"></textarea>
                            <div class="preview-box mt-1" id="preview_editorExplanation"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Đóng</button>
                        <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection

@section('javascript_plugins')
    <script>
        $(function () {
            const modal = new bootstrap.Modal(document.getElementById('modalAdd'));
            const $form = $('#formQuestion');

            // Toggle options based on type
            $('#qType').on('change', function () {
                const t = $(this).val();
                $('#mcOptions').toggle(t === 'mc' || t === 'ms');
                $('#mcSingleCorrect').toggle(t === 'mc');
                $('#mcMultiCorrect').toggle(t === 'ms');
                
                $('#tfOptions').toggle(t === 'tf');
                $('#shortOptions').toggle(t === 'short');
                $('#mblanksOptions').toggle(t === 'mblanks');
                $('#matchingOptions').toggle(t === 'matching');
            });

            const subjects = @json($subjects);

            // Reset modal for NEW Section
            $(document).on('click', '.btnAddSection', function () {
                const part = $(this).data('part');
                const subjectId = $(this).data('subject');
                const branch = $(this).data('branch');
                const sName = subjects.find(s => s.id == subjectId)?.name || 'Chưa gán';

                $form[0].reset();
                $('#qId').val('');
                $('#qPart').val(part);
                $('#qSubject').val(subjectId);
                $('#qBranch').val(branch);
                $('#lblSubjectName').text(sName);
                
                $('#modalTitle').text('Thêm câu hỏi mới');
                $('#qType').trigger('change');
                $('.preview-box').empty();
                $('#mblanksContainer').empty();
                renderBlankInput('');
                modal.show();
            });

            function renderBlankInput(val) {
                const count = $('#mblanksContainer .input-group').length + 1;
                const html = `
                <div class="input-group mb-2">
                    <span class="input-group-text">#${count}</span>
                    <input type="text" name="mblank_val[]" class="form-control" value="${val}" placeholder="Đáp án ô trống ${count}">
                    <button class="btn btn-outline-danger btnRemoveBlank" type="button"><i class="ri-delete-bin-line"></i></button>
                </div>`;
                $('#mblanksContainer').append(html);
            }

            $('#btnAddBlank').on('click', function() { renderBlankInput(''); });
            $(document).on('click', '.btnRemoveBlank', function() { $(this).closest('.input-group').remove(); });

            // Populate for EDIT
            $('.btnEdit').on('click', function () {
                const data = $(this).data('data');
                const sName = subjects.find(s => s.id == data.subject_id)?.name || 'Chưa gán';

                $form[0].reset();
                $('#qId').val(data.id);
                $('#qPart').val(data.part);
                $('#qSubject').val(data.subject_id);
                $('#qBranch').val(data.branch || '');
                $('#lblSubjectName').text(sName);

                $('#qType').val(data.question_type).trigger('change');
                $('#formQuestion [name=order]').val(data.order);
                $('#formQuestion [name=content]').val(data.content);
                $('#formQuestion [name=passage]').val(data.passage);
                $('#formQuestion [name=explanation]').val(data.explanation);

                if (data.question_type === 'mc' || data.question_type === 'ms') {
                    let opts = JSON.parse(data.options || '[]');
                    // Support cả array ['a','b','c','d'] và object {'A':'...','B':'...','C':'...','D':'...'}
                    if (!Array.isArray(opts)) {
                        opts = [opts['A'] || opts['a'] || '', opts['B'] || opts['b'] || '', opts['C'] || opts['c'] || '', opts['D'] || opts['d'] || ''];
                    }
                    $('#formQuestion [name=option_a]').val(opts[0] || '');
                    $('#formQuestion [name=option_b]').val(opts[1] || '');
                    $('#formQuestion [name=option_c]').val(opts[2] || '');
                    $('#formQuestion [name=option_d]').val(opts[3] || '');
                    
                    if (data.question_type === 'ms') {
                        const correctArr = (data.correct_answer || '').split(',');
                        $('#formQuestion [name="correct_answer_ms[]"]').each(function() {
                            $(this).prop('checked', correctArr.includes($(this).val()));
                        });
                    } else {
                        $('#formQuestion [name=correct_answer_mc]').val(data.correct_answer);
                    }
                } else if (data.question_type === 'short') {
                    $('#formQuestion [name=correct_answer_short]').val(data.correct_answer);
                } else if (data.question_type === 'mblanks') {
                    $('#mblanksContainer').empty();
                    const blanks = (data.correct_answer || '').split('|');
                    blanks.forEach(b => renderBlankInput(b));
                } else if (data.question_type === 'matching') {
                    const pairs = JSON.parse(data.options || '[]');
                    pairs.forEach((p, i) => {
                        if(i < 4) {
                            $(`#formQuestion [name=matching_left_${i + 1}]`).val(p.left);
                            $(`#formQuestion [name=matching_right_${i + 1}]`).val(p.right);
                        }
                    });
                } else if (data.question_type === 'tf') {
                    $.get('/ajax/admin/exam/question/tf/' + data.id, function (res) {
                        if (res.status) {
                            res.data.forEach((item, i) => {
                                $(`#formQuestion [name=tf_content_${i + 1}]`).val(item.content).trigger('input');
                                $(`#formQuestion [name=tf_correct_${i + 1}]`).val(item.is_correct ? '1' : '0');
                            });
                        }
                    });
                }
                $('#modalTitle').text('Sửa câu hỏi');
                modal.show();

                setTimeout(() => {
                    $('.rich-editor').trigger('input');
                }, 300);
            });

            // Unified Live Preview Logic
            let previewTimer;
            $(document).on('input', '.rich-editor', function () {
                const val = $(this).val();
                let targetId = $(this).attr('id');
                if (!targetId) targetId = $(this).attr('name');
                const $preview = $('#preview_' + targetId);

                $preview.html(val || '<small class="text-muted">Chưa có nội dung...</small>');

                clearTimeout(previewTimer);
                previewTimer = setTimeout(() => {
                    if (window.MathJax && window.MathJax.typesetPromise) {
                        window.MathJax.typesetPromise([$preview[0]]);
                    }
                }, 500);
            });

            // Unified Toolbar Action
            $(document).on('click', '.math-toolbar button', function (e) {
                e.preventDefault();
                const latex = $(this).data('latex');
                const type = $(this).data('type');
                const targetSelector = $(this).closest('.math-toolbar').data('target');
                const $el = $(targetSelector);

                let insert = '';
                if (type === 'image') {
                    const url = prompt('Nhập URL ảnh:');
                    if (url) insert = `<img src="${url}" style="max-width:100%; border-radius:8px; margin:10px 0;" />`;
                } else if (type === 'audio') {
                    const url = prompt('Nhập URL âm thanh (mp3, wav...):');
                    if (url) insert = `<div class="mt-2"><audio controls style="width:100%"><source src="${url}" type="audio/mpeg">Trình duyệt không hỗ trợ nghe.</audio></div>`;
                } else if (type === 'link') {
                    const url = prompt('Nhập URL liên kết:');
                    const text = prompt('Nhập văn bản hiển thị:', 'Bấm vào đây');
                    if (url) insert = `<a href="${url}" target="_blank">${text}</a>`;
                } else {
                    insert = `$${latex}$`;
                }

                if (!insert) return;

                const start = $el[0].selectionStart;
                const end = $el[0].selectionEnd;
                const text = $el.val();
                $el.val(text.substring(0, start) + insert + text.substring(end));
                $el[0].selectionStart = $el[0].selectionEnd = start + insert.length;
                $el.focus().trigger('input');
            });

            // Handle Delete
            $('.btnDelete').on('click', function () {
                if (!confirm('Bạn chắc chắn muốn xóa câu hỏi này?')) return;
                const id = $(this).data('id');
                $.post('/ajax/admin/exam/question/delete', { id: id }, function (res) {
                    if (res.status) { toastr.success(res.message); location.reload(); }
                    else toastr.error(res.message);
                });
            });

            // Handle Submit
            $form.on('submit', function (e) {
                e.preventDefault();
                const qId = $('#qId').val();
                const qType = $('#qType').val();
                const fd = new FormData(this);

                if (qType === 'mc' || qType === 'ms') {
                    fd.append('options', JSON.stringify([
                        fd.get('option_a'), fd.get('option_b'), fd.get('option_c'), fd.get('option_d')
                    ]));
                    if (qType === 'ms') {
                        const msChecked = [];
                        $('#formQuestion [name="correct_answer_ms[]"]:checked').each(function() {
                            msChecked.push($(this).val());
                        });
                        fd.append('correct_answer', msChecked.join(','));
                    } else {
                        fd.append('correct_answer', fd.get('correct_answer_mc'));
                    }
                } else if (qType === 'mblanks') {
                    const blankVals = [];
                    $('#mblanksContainer input[name="mblank_val[]"]').each(function() {
                        blankVals.push($(this).val());
                    });
                    fd.append('correct_answer', blankVals.join('|'));
                } else if (qType === 'matching') {
                    const pairs = [];
                    for(let i=1; i<=4; i++) {
                        const left = fd.get('matching_left_'+i);
                        const right = fd.get('matching_right_'+i);
                        if(left && right) pairs.push({left, right});
                    }
                    fd.append('options', JSON.stringify(pairs));
                    fd.append('correct_answer', 'matching');
                } else if (qType === 'tf') {
                    const tfItems = [];
                    for (let i = 1; i <= 4; i++) {
                        tfItems.push({
                            order: i,
                            content: fd.get('tf_content_' + i),
                            is_correct: parseInt(fd.get('tf_correct_' + i))
                        });
                    }
                    fd.append('tf_items', JSON.stringify(tfItems));
                } else {
                    fd.append('correct_answer', fd.get('correct_answer_short'));
                }

                const url = qId ? '/ajax/admin/exam/question/edit/' + qId : '/ajax/admin/exam/{!! $exam->id !!}/question/add';
                $.ajax({
                    url: url, method: 'POST', data: fd, processData: false, contentType: false,
                    success: function (res) {
                        if (res.status) { toastr.success(res.message); modal.hide(); location.reload(); }
                        else { toastr.error(res.message); }
                    }
                });
            });
        });
    </script>
@endsection