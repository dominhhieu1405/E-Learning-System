@php use Models\Web; @endphp
@extends('admin.layout')

@section('css_plugins')
    <link rel="stylesheet" type="text/css" href="/assets/admin/libs/select2/css/select2.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/css/fontawesome.min.css">

@stop

@section('content')

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">{{$lesson->name}}</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Sửa bài học</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <form id="my-form" action="{{url()}}" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title mb-4">Thông tin bài học</h4>
                                <div class="form-group">
                                    <label for="inputName">Tên bài học</label>
                                    <input type="text" name="name" id="inputName" class="form-control" autocomplete="off" placeholder="Nhập tên bài học vào đây" value="{{$lesson->name}}">
                                </div>
                                <div class="form-group">
                                    <label for="inputUnit">Chương nào?</label>
                                    <select name="unit" id="inputUnit" class="form-control custom-select">
                                        @foreach($units as $unit)
                                            <option value="{{$unit->id}}" @if($unit->id === $lesson->unit) selected @endif >{{$unit->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="inputDescription">Mô tả bài học</label>
                                    <textarea name="description" id="inputDescription" class="form-control" rows="4" placeholder="Nhập mô tả bài học vào đây">{{$lesson->description}}</textarea>
                                </div>
                                <div class="form-group mb-4">
                                    <label>Nội dung bài học</label>
                                    <div id="videoList">
                                        @foreach(json_decode($lesson->videos) as $video)
                                            <div class="mb-4 btnInList">
                                                <div class="input-group mb-2">
                                                    <select class="form-control custom-select btn-list-icon" aria-label="">
                                                        <option value="googledrive" @if($video->type === "googledrive") selected @endif> Google Drive </option>
                                                        <option value="youtube" @if($video->type === "youtube") selected @endif> Youtube </option>
                                                    </select>
                                                    <input type="text" class="form-control btn-list-text" placeholder="Tên video" value="{{$video->text}}" aria-label="">
                                                </div>
                                                <input aria-label="" type="text" class="form-control btn-list-link mb-2" placeholder="Link video" value="{{$video->url}}">
                                                <button class="btn btn-danger btn-sm remove-btn">Xóa</button>
                                            </div>
                                        @endforeach
                                    </div>
                                    <button class="btn btn-primary " type="button" id="addVideoBtn">Thêm video(s)</button>
                                </div>
                                <div class="form-group mb-4">
                                    <label>Tài liệu bài học</label>
                                    <div id="fileList">
                                        @foreach(json_decode($lesson->files) as $file)
                                            <div class="mb-4 btnInList">
                                                <div class="input-group mb-2">
                                                    <select class="form-control custom-select btn-list-icon" aria-label="">
                                                        <option value="download" @if($file->icon === "download") selected @endif> Tải xuống 1 </option>
                                                        <option value="down-to-line" @if($file->icon === "down-to-line") selected @endif> Tải xuống 2 </option>
                                                        <option value="cloud-arrow-down" @if($file->icon === "cloud-arrow-down") selected @endif> Tải xuống 3 </option>
                                                        <option value="up-right-from-square" @if($file->icon === "up-right-from-square") selected @endif> Mở liên kết </option>
                                                        <option value="folder-open" @if($file->icon === "folder-open") selected @endif> Thư mục </option>
                                                        <option value="share-nodes" @if($file->icon === "share-nodes") selected @endif> Chia sẻ </option>
                                                    </select>
                                                    <select id="buttonColor" class="form-control custom-select btn-list-color" aria-label="">
                                                        <option value="#343A40" style="background: #343A40; color: #fff" @if($file->color === "#343A40") selected @endif> Xám than </option>
                                                        <option value="#74788D" style="background: #74788D; color: #fff" @if($file->color === "#74788D") selected @endif> Xám xanh </option>
                                                        <option value="#BD2323" style="background: #BD2323; color: #fff" @if($file->color === "#BD2323") selected @endif> Đỏ tươi </option>
                                                        <option value="#1BC517" style="background: #1BC517; color: #fff" @if($file->color === "#1BC517") selected @endif> Xanh lá nhạt </option>
                                                        <option value="#169C87" style="background: #169C87; color: #fff" @if($file->color === "#169C87") selected @endif> Xanh lá đậm </option>
                                                        <option value="#00BED8" style="background: #00BED8; color: #fff" @if($file->color === "#00BED8") selected @endif> Xanh lục lam </option>
                                                        <option value="#2339BD" style="background: #2339BD; color: #fff" @if($file->color === "#2339BD") selected @endif> Xanh nước biển </option>
                                                        <option value="#804B4B" style="background: #804B4B; color: #fff" @if($file->color === "#804B4B") selected @endif> Nâu đỏ </option>
                                                        <option value="#DE7500" style="background: #DE7500; color: #fff" @if($file->color === "#DE7500") selected @endif> Cam sáng </option>
                                                        <option value="#FF66B2" style="background: #FF66B2; color: #fff" @if($file->color === "#FF66B2") selected @endif> Hồng sáng </option>
                                                        <option value="#F48FB1" style="background: #F48FB1; color: #fff" @if($file->color === "#F48FB1") selected @endif> Hồng pastel </option>
                                                    </select>
                                                </div>
                                                <input aria-label="" type="text" class="form-control btn-list-text mb-2" placeholder="Văn bản" value="{{$file->text}}">
                                                <input aria-label="" type="text" class="form-control btn-list-link mb-2" placeholder="Link khi mở tệp" value="{{$file->url}}">
                                                <button class="btn btn-danger btn-sm remove-btn">Xóa</button>
                                            </div>
                                        @endforeach
                                    </div>
                                    <button class="btn btn-primary " type="button" id="addFileBtn">Thêm file(s)</button>
                                </div>

                                <input type="button" data-hidden="0" class="btnSubmit btn btn-success btn-block" value="Thêm bài học"/>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <div class="col-lg-4">
                        <div class="card card-secondary">
                            <div class="card-body">
                                <h4 class="card-title mb-4">Xem trước</h4>
                                <div class="col-12 col-lg-12" style="text-align: -webkit-center; display: none">
                                    <div class="form-group cover-preview">
                                        <img id="cover-preview" src="/assets/img/no-image.png" onerror="$(this).attr('src', '/assets/img/no-image.png')" style="width: 100%;object-fit: cover;" alt=""/>
                                    </div>
                                </div>
                                <div class="mb-2" id="nameDoc">
                                    <h4>Tên bài học</h4>
                                </div>
                                <hr>
                                <div id="preview-container" class="mt-2 mb-2">
                                    <div class="text-center">
                                        <b>Chưa có dữ liệu</b>
                                    </div>
                                </div>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </form>

        </div>
    </div>


@stop

@section('javascript_plugins')
    <!-- Select2 -->
    <script src="/assets/admin/libs/bs-custom-file-input/bs-custom-file-input.min.js"></script>
    <script src="/assets/admin/libs/select2/js/select2.full.min.js"></script>
    <script>

        // Render every 1s


        function getGoogleDriveFileId(url) {
            const regex = /\/d\/([a-zA-Z0-9_-]+)(?:\/|$)/;
            const matches = url.match(regex);
            return matches ? matches[1] : "";
        }

        function getYoutubeVideoID(url) {
            const pattern = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/;
            const matches = url.match(pattern);
            return matches ? matches[1] : false; // Trả về video ID nếu hợp lệ, hoặc false nếu không hợp lệ
        }

        function renderData() {
            let previewContainer = $("#preview-container");
            previewContainer.empty();

            let videos = videosArrays();
            let files = filesArrays();
            if (videos.length > 1) {
                previewContainer.append(`<p style="text-align: center" id="videoBtnSelect"></p>`);
                videos.forEach((video, index) => {
                    let videoId = "";
                    let $src = "";
                    if (video.type === "googledrive") {
                        videoId = getGoogleDriveFileId(video.url);
                        if (videoId) {
                            $src = `https://drive.google.com/file/d/${videoId}/preview`;
                        }
                    } else if (video.type === "youtube") {
                        videoId = getYoutubeVideoID(video.url);
                        if (videoId) {
                            $src = `https://www.youtube.com/embed/${videoId}`;
                        }
                    }
                    $("#videoBtnSelect").append(`<a href="#vid-${index + 1}" class="btn btn-primary change-video-btn" type="button" data-video="${$src}" style="margin: 5px;">
                        ${video.text}
                    </a>`);
                });

                previewContainer.prepend(`<div class="video-player" data-id="">
                    <iframe src="" frameborder="0" allowfullscreen="1" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"></iframe>
                </div>`);
                $(".change-video-btn").first().click();
            } else if (videos.length === 1) {
                let video = videos[0];
                let videoId = "";
                let $src = "";
                if (video.type === "googledrive") {
                    videoId = getGoogleDriveFileId(video.url);
                    if (videoId) {
                        $src = `https://drive.google.com/file/d/${videoId}/preview`;
                    }
                } else if (video.type === "youtube") {
                    videoId = getYoutubeVideoID(video.url);
                    if (videoId) {
                        $src = `https://www.youtube.com/embed/${videoId}`;
                    }
                }
                previewContainer.append(`<div class="video-player" data-id="">
                    <iframe src="${$src}" frameborder="0" allowfullscreen="1" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"></iframe>
                </div>`);
            }

            previewContainer.append(`<hr/>`).append("<div style='text-align: center;' id='previewFileBtnList'> </div>");

            files.forEach((file) => {
                $("#previewFileBtnList").append(`<a href="${file.url}" class="btn btn-primary text-white" style="background:${file.color};border:none;margin: 2px">
                        <i class="fa fa-${file.icon}"></i>
                        ${file.text}
                    </a>`);
            });
        }

        $(document).on("change", ".btnInList input, .btnInList select", function () {
            renderData();
        });

        $(document).on('click', '#addVideoBtn', function () {
            $('#videoList').append(`<div class="mb-4 btnInList">
                        <div class="input-group mb-2">

                            <select class="form-control custom-select btn-list-icon">
                                <option value="" disabled selected> --Loại video-- </option>
                                <option value="googledrive"> Google Drive </option>
                                <option value="youtube"> Youtube </option>
                            </select>
                            <input type="text" class="form-control btn-list-text" placeholder="Tên video">
                        </div>
                            <input type="text" class="form-control btn-list-link mb-2" placeholder="Link video">
                <button class="btn btn-danger btn-sm remove-btn">Xóa</button>
            </div>`);
        });
        $(document).on('click', '#addFileBtn', function () {
            $('#fileList').append(`<div class="mb-4 btnInList">
                            <div class="input-group mb-2">

                            <select class="form-control custom-select btn-list-icon">
                                <option value="" disabled selected> --Chọn icon-- </option>
                                <option value="download"> Tải xuống 1 </option>
                                <option value="down-to-line"> Tải xuống 2 </option>
                                <option value="cloud-arrow-down"> Tải xuống 3 </option>
                                <option value="up-right-from-square"> Mở liên kết </option>
                                <option value="folder-open">Thư mục</option>
                                <option value="share-nodes">Chia sẻ</option>
                            </select>
                            <select id="buttonColor" class="form-control custom-select btn-list-color">
                                <option value="" disabled selected> --Chọn màu-- </option>
                                <option value="#343A40" style="background: #343A40; color: #fff"> Xám than </option>
                                <option value="#74788D" style="background: #74788D; color: #fff"> Xám xanh </option>
                                <option value="#BD2323" style="background: #BD2323; color: #fff"> Đỏ tươi </option>
                                <option value="#1BC517" style="background: #1BC517; color: #fff"> Xanh lá nhạt</option>
                                <option value="#169C87" style="background: #169C87; color: #fff"> Xanh lá đậm</option>
                                <option value="#00BED8" style="background: #00BED8; color: #fff"> Xanh lục lam </option>
                                <option value="#5186D5" style="background: #5186D5; color: #fff"> Xanh da trời </option>
                                <option value="#2339BD" style="background: #2339BD; color: #fff"> Xanh nước biển </option>
                                <option value="#804B4B" style="background: #804B4B; color: #fff">Nâu đỏ</option>
                                <option value="#DE7500" style="background: #DE7500; color: #fff">Cam sáng</option>
                                <option value="#FF66B2" style="background: #FF66B2; color: #fff">Hồng sáng</option>
                                <option value="#F48FB1" style="background: #F48FB1; color: #fff">Hồng pastel</option>
                            </select>
                            </div>
                            <input type="text" class="form-control btn-list-text mb-2" placeholder="Văn bản">
                            <input type="text" class="form-control btn-list-link mb-2" placeholder="Link khi mở tệp">
                <button class="btn btn-danger btn-sm remove-btn">Xóa</button>
            </div>`);
        });

        $(document).on('click', '.remove-btn', function () {
            $(this).parent().remove();
        });

        function filesArrays() {
            let files = [];
            $('#fileList .btnInList').each(function () {
                let icon = $(this).find('.btn-list-icon').val();
                let text = $(this).find('.btn-list-text').val();
                let color = $(this).find('.btn-list-color').val();
                let link = $(this).find('.btn-list-link').val();
                files.push({
                    icon: icon,
                    text: text,
                    color: color,
                    url: link
                });
            });
            return files;
        }
        function videosArrays() {
            let videos = [];
            $('#videoList .btnInList').each(function () {
                let icon = $(this).find('.btn-list-icon').val();
                let text = $(this).find('.btn-list-text').val();
                let link = $(this).find('.btn-list-link').val();
                videos.push({
                    type: icon,
                    url: link,
                    text: text
                });
            });
            return videos;
        }

        renderData();
    </script>

    <script>
        $(document).ready(function () {
            $(document).on("click", ".change-video-btn", function () {
                $(".change-video-btn").removeClass("btn-danger").addClass("btn-primary");
                $(this).removeClass("btn-primary").addClass("btn-danger");
                var url = $(this).data("video");
                $(".video-player iframe").attr("src", url);
            });

        });
    </script>
    <script type="text/javascript">
        bsCustomFileInput.init();
        $(document).ready(function () {
            $('input').keypress(function (event) {
                if (event.which === 13) { // 13 là mã phím Enter
                    event.preventDefault(); // Ngăn chặn hành động mặc định (submit form)
                }
            });

            $("#inputName").on("keyup", function () {
                $("#nameDoc").html("<h4>" + $(this).val() + "</h4>");
            });

            $(".btnSubmit").click(function (event) {
                //stop submit the form, we will post it manually.
                event.preventDefault();

                // Get form
                const form = $('#my-form');

                // FormData object
                const ajaxData = new FormData(form[0]);
                // If you want to add an extra field for the FormData
                ajaxData.append("files", JSON.stringify(filesArrays()));
                ajaxData.append("videos", JSON.stringify(videosArrays()));
                // disabled the submit button
                $("#btnSubmit").val("Đang thêm...").prop("disabled", true);

                $.ajax({
                    type: "POST",
                    enctype: 'multipart/form-data',
                    url: "{{url("ajax.admin.course.lesson.edit", ["id" => $lesson->id])}}",
                    data: ajaxData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    success: function (data) {
                        if (data.status) {
                            toastr["success"](data.message, "Thông báo");
                        } else {
                            toastr["error"](data.message, "Thông báo");
                        }
                        $("#btnSubmit").val("Thêm bài học").prop("disabled", false);
                    },
                    error: function (e) {
                        toastr["error"]("Có lỗi xảy ra", "Thông báo");
                        $("#btnSubmit").val("Thêm bài học").prop("disabled", false);
                    }
                });
            });
        });

        const loadFile = function (event) {
            console.log("ahi");
            let output = document.getElementById('cover-preview');
            output.src = URL.createObjectURL(event.target.files[0]);
            output.onload = function () {
                URL.revokeObjectURL(output.src) // free memory
            }
        };


    </script>
@stop
