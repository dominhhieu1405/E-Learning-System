@extends('admin.layout')

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">TITLE</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">TITLE</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Main content -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">TITLE</h4>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>

@stop
@section('javascript_plugins')
    <script>
        $(function (){

        })
    </script>
@stop