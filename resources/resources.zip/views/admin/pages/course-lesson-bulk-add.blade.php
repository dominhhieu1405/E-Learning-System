@php use Models\Web; @endphp
@extends('admin.layout')

@section('css_plugins')
    <link rel="stylesheet" type="text/css" href="/assets/admin/libs/select2/css/select2.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/css/fontawesome.min.css">

@stop

@section('content')

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Thêm nhiều bài học</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Thêm nhiều bài học</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <form id="my-form" action="{{url()}}" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title mb-4">Thông tin bài học</h4>
                                <div class="form-group">
                                    <label for="inputUnit">Chương nào?</label>
                                    <select name="unit" id="inputUnit" class="form-control custom-select">
                                        @foreach($units as $unit)
                                            <option value="{{$unit->id}}">{{$unit->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="inputBulk">Nội dung bài học</label>
                                    <textarea name="bulk" id="inputBulk" class="form-control" rows="15" placeholder="Tên | video 1, video 2,... | File 1, file 2..."></textarea>
                                </div>

                                <input type="button" data-hidden="0" class="btnSubmit btn btn-success btn-block" value="Thêm bài học"/>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </form>

        </div>
    </div>


@stop

@section('javascript_plugins')
    <!-- Select2 -->
    <script src="/assets/admin/libs/bs-custom-file-input/bs-custom-file-input.min.js"></script>
    <script src="/assets/admin/libs/select2/js/select2.full.min.js"></script>
    <script>

        // Render every 1s


        function getGoogleDriveFileId(url) {
            const regex = /\/d\/([a-zA-Z0-9_-]+)(?:\/|$)/;
            const matches = url.match(regex);
            return matches ? matches[1] : "";
        }

        function getYoutubeVideoID(url) {
            const pattern = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/;
            const matches = url.match(pattern);
            return matches ? matches[1] : false; // Trả về video ID nếu hợp lệ, hoặc false nếu không hợp lệ
        }

        function renderData() {
            let previewContainer = $("#preview-container");
            previewContainer.empty();

            let videos = videosArrays();
            let files = filesArrays();
            if (videos.length > 1) {
                previewContainer.append(`<p style="text-align: center" id="videoBtnSelect"></p>`);
                videos.forEach((video, index) => {
                    let videoId = "";
                    let $src = "";
                    if (video.type === "googledrive") {
                        videoId = getGoogleDriveFileId(video.url);
                        if (videoId) {
                            $src = `https://drive.google.com/file/d/${videoId}/preview`;
                        }
                    } else if (video.type === "youtube") {
                        videoId = getYoutubeVideoID(video.url);
                        if (videoId) {
                            $src = `https://www.youtube.com/embed/${videoId}`;
                        }
                    }
                    $("#videoBtnSelect").append(`<a href="#vid-${index + 1}" class="btn btn-primary change-video-btn" type="button" data-video="${$src}" style="margin: 5px;">
                        ${video.text}
                    </a>`);
                });

                previewContainer.prepend(`<div class="video-player" data-id="">
                    <iframe src="" frameborder="0" allowfullscreen="1" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"></iframe>
                </div>`);
                $(".change-video-btn").first().click();
            } else if (videos.length === 1) {
                let video = videos[0];
                let videoId = "";
                let $src = "";
                if (video.type === "googledrive") {
                    videoId = getGoogleDriveFileId(video.url);
                    if (videoId) {
                        $src = `https://drive.google.com/file/d/${videoId}/preview`;
                    }
                } else if (video.type === "youtube") {
                    videoId = getYoutubeVideoID(video.url);
                    if (videoId) {
                        $src = `https://www.youtube.com/embed/${videoId}`;
                    }
                }
                previewContainer.append(`<div class="video-player" data-id="">
                    <iframe src="${$src}" frameborder="0" allowfullscreen="1" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"></iframe>
                </div>`);
            }

            previewContainer.append(`<hr/>`).append("<div style='text-align: center;' id='previewFileBtnList'> </div>");

            files.forEach((file) => {
                $("#previewFileBtnList").append(`<a href="${file.url}" class="btn btn-primary text-white" style="background:${file.color};border:none;margin: 2px">
                        <i class="fa fa-${file.icon}"></i>
                        ${file.text}
                    </a>`);
            });
        }

        $(document).on("change", ".btnInList input, .btnInList select", function () {
            renderData();
        });

        $(document).on('click', '#addVideoBtn', function () {
            $('#videoList').append(`<div class="mb-4 btnInList">
                        <div class="input-group mb-2">

                            <select class="form-control custom-select btn-list-icon">
                                <option value="" disabled selected> --Loại video-- </option>
                                <option value="googledrive"> Google Drive </option>
                                <option value="youtube"> Youtube </option>
                            </select>
                            <input type="text" class="form-control btn-list-text" placeholder="Tên video">
                        </div>
                            <input type="text" class="form-control btn-list-link mb-2" placeholder="Link video">
                <button class="btn btn-danger btn-sm remove-btn">Xóa</button>
            </div>`);
        });
        $(document).on('click', '#addFileBtn', function () {
            $('#fileList').append(`<div class="mb-4 btnInList">
                            <div class="input-group mb-2">

                            <select class="form-control custom-select btn-list-icon">
                                <option value="" disabled selected> --Chọn icon-- </option>
                                <option value="download"> Tải xuống 1 </option>
                                <option value="down-to-line"> Tải xuống 2 </option>
                                <option value="cloud-arrow-down"> Tải xuống 3 </option>
                                <option value="up-right-from-square"> Mở liên kết </option>
                                <option value="folder-open">Thư mục</option>
                                <option value="share-nodes">Chia sẻ</option>
                            </select>
                            <select id="buttonColor" class="form-control custom-select btn-list-color">
                                <option value="" disabled selected> --Chọn màu-- </option>
                                <option value="#343A40" style="background: #343A40; color: #fff"> Xám than </option>
                                <option value="#74788D" style="background: #74788D; color: #fff"> Xám xanh </option>
                                <option value="#BD2323" style="background: #BD2323; color: #fff"> Đỏ tươi </option>
                                <option value="#1BC517" style="background: #1BC517; color: #fff"> Xanh lá nhạt</option>
                                <option value="#169C87" style="background: #169C87; color: #fff"> Xanh lá đậm</option>
                                <option value="#00BED8" style="background: #00BED8; color: #fff"> Xanh lục lam </option>
                                <option value="#5186D5" style="background: #5186D5; color: #fff"> Xanh da trời </option>
                                <option value="#2339BD" style="background: #2339BD; color: #fff"> Xanh nước biển </option>
                                <option value="#804B4B" style="background: #804B4B; color: #fff">Nâu đỏ</option>
                                <option value="#DE7500" style="background: #DE7500; color: #fff">Cam sáng</option>
                                <option value="#FF66B2" style="background: #FF66B2; color: #fff">Hồng sáng</option>
                                <option value="#F48FB1" style="background: #F48FB1; color: #fff">Hồng pastel</option>
                            </select>
                            </div>
                            <input type="text" class="form-control btn-list-text mb-2" placeholder="Văn bản">
                            <input type="text" class="form-control btn-list-link mb-2" placeholder="Link khi mở tệp">
                <button class="btn btn-danger btn-sm remove-btn">Xóa</button>
            </div>`);
        });

        $(document).on('click', '.remove-btn', function () {
            $(this).parent().remove();
        });

        function filesArrays() {
            let files = [];
            $('#fileList .btnInList').each(function () {
                let icon = $(this).find('.btn-list-icon').val();
                let text = $(this).find('.btn-list-text').val();
                let color = $(this).find('.btn-list-color').val();
                let link = $(this).find('.btn-list-link').val();
                files.push({
                    icon: icon,
                    text: text,
                    color: color,
                    url: link
                });
            });
            return files;
        }
        function videosArrays() {
            let videos = [];
            $('#videoList .btnInList').each(function () {
                let icon = $(this).find('.btn-list-icon').val();
                let text = $(this).find('.btn-list-text').val();
                let link = $(this).find('.btn-list-link').val();
                videos.push({
                    type: icon,
                    url: link,
                    text: text
                });
            });
            return videos;
        }

    </script>

    <script>
        $(document).ready(function () {
            $(document).on("click", ".change-video-btn", function () {
                $(".change-video-btn").removeClass("btn-danger").addClass("btn-primary");
                $(this).removeClass("btn-primary").addClass("btn-danger");
                var url = $(this).data("video");
                $(".video-player iframe").attr("src", url);
            });

        });
    </script>
    <script type="text/javascript">
        bsCustomFileInput.init();
        $(document).ready(function () {

            $('input').keypress(function (event) {
                if (event.which === 13) { // 13 là mã phím Enter
                    event.preventDefault(); // Ngăn chặn hành động mặc định (submit form)
                }
            });

            $("#inputName").on("keyup", function () {
                $("#nameDoc").html("<h4>" + $(this).val() + "</h4>");
            });

            $(".btnSubmit").click(function (event) {
                //stop submit the form, we will post it manually.
                event.preventDefault();

                // FormData object
                const ajaxData = new FormData();
                // If you want to add an extra field for the FormData
                ajaxData.append("unit", $("#inputUnit").val());
                ajaxData.append("bulk", $("#inputBulk").val());

                // disabled the submit button
                $("#btnSubmit").val("Đang thêm...").prop("disabled", true);

                $.ajax({
                    type: "POST",
                    enctype: 'multipart/form-data',
                    url: "{{url("ajax.admin.course.lesson.bulk-add", ["id" => $course->id])}}",
                    data: ajaxData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    success: function (data) {
                        if (data.status) {
                            toastr["success"](data.message, "Thông báo");
                        } else {
                            toastr["error"](data.message, "Thông báo");
                        }
                        $("#btnSubmit").val("Thêm bài học").prop("disabled", false);
                    },
                    error: function (e) {
                        toastr["error"]("Có lỗi xảy ra", "Thông báo");
                        $("#btnSubmit").val("Thêm bài học").prop("disabled", false);
                    }
                });
            });
        });

        const loadFile = function (event) {
            console.log("ahi");
            let output = document.getElementById('cover-preview');
            output.src = URL.createObjectURL(event.target.files[0]);
            output.onload = function () {
                URL.revokeObjectURL(output.src) // free memory
            }
        };


    </script>
@stop
