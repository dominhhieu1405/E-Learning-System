@extends('admin.layout')

@section('content')
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0">Quản lý Đề thi</h4>
                    <a href="{{ path_url('admin.exam.add') }}" class="btn btn-primary">
                        <i class="ri-add-line"></i> Tạo đề mới
                    </a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="50">#</th>
                                        <th>Tên đề thi</th>
                                        <th width="100">Loại</th>
                                        <th width="100">Hình thức</th>
                                        <th width="80">Trạng thái</th>
                                        <th width="150">Ngày tạo</th>
                                        <th width="180">Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if($exams && count($exams) > 0)
                                        @foreach($exams as $exam)
                                        <tr>
                                            <td>{{ $exam->id }}</td>
                                            <td>
                                                <a href="{{ path_url('admin.exam.edit', ['id' => $exam->id]) }}">
                                                    {{ $exam->title }}
                                                </a>
                                            </td>
                                            <td>
                                                <span class="badge bg-{{ $exam->exam_type === 'thpt' ? 'primary' : 'success' }}">
                                                    {{ strtoupper($exam->exam_type) }}
                                                </span>
                                            </td>
                                            <td>
                                                @if($exam->is_random)
                                                    <span class="badge bg-warning">Ngẫu nhiên</span>
                                                @else
                                                    <span class="badge bg-info">Cố định</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if($exam->status)
                                                    <span class="badge bg-success">Hiển thị</span>
                                                @else
                                                    <span class="badge bg-secondary">Ẩn</span>
                                                @endif
                                            </td>
                                            <td>{{ $exam->created_at }}</td>
                                            <td>
                                                <a href="{{ path_url('admin.exam.questions', ['id' => $exam->id]) }}" class="btn btn-sm btn-info">
                                                    <i class="ri-list-check"></i> Câu hỏi
                                                </a>
                                                <a href="{{ path_url('admin.exam.edit', ['id' => $exam->id]) }}" class="btn btn-sm btn-warning">
                                                    <i class="ri-edit-line"></i>
                                                </a>
                                                <button class="btn btn-sm btn-danger btn-delete" data-id="{{ $exam->id }}">
                                                    <i class="ri-delete-bin-line"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        @endforeach
                                    @else
                                        <tr><td colspan="7" class="text-center text-muted">Chưa có đề thi nào</td></tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('javascript_plugins')
<script>
$(function(){
    $('.btn-delete').on('click', function(){
        if(!confirm('Xóa đề thi này? Tất cả câu hỏi sẽ bị xóa theo!')) return;
        var id = $(this).data('id');
        $.post('/ajax/admin/exam/delete', {id: id}, function(res){
            if(res.status){
                toastr.success(res.message);
                setTimeout(()=> location.reload(), 800);
            } else {
                toastr.error(res.message);
            }
        });
    });
});
</script>
@endsection
