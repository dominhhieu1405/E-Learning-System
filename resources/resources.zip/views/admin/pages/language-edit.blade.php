@extends('admin.layout')

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Dịch ngôn ngữ: {{ $language['name'] }} (<code>{{ $language['code'] }}</code>)</h4>
                        <a href="/admin/languages" class="btn btn-secondary">Quay lại</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="translationTable" class="table table-bordered table-striped align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th style="min-width: 150px;">Từ khóa (Key)</th>
                                            <th style="min-width: 300px;">Bản gốc (Tiếng Việt)</th>
                                            <th style="min-width: 300px;">Bản dịch ({{ $language['name'] }})</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($translations as $filename => $data)
                                            @php $fileKey = basename($filename, '.php'); @endphp
                                            @foreach($data['vi'] as $key => $viValue)
                                                @if(is_array($viValue))
                                                    <tr>
                                                        <td colspan="3" class="text-danger">Mảng đa chiều chưa được hỗ trợ trên
                                                            UI: {{ $fileKey }}.{{ $key }}</td>
                                                    </tr>
                                                @else
                                                    <tr>
                                                        <td><code>{{ $fileKey }}.{{ $key }}</code></td>
                                                        <td>{{ $viValue }}</td>
                                                        <td>
                                                            <textarea class="form-control translation-input" rows="2"
                                                                data-file="{{ $filename }}" data-key="{{ $key }}"
                                                                data-code="{{ $language['code'] }}">{{ $data['target'][$key] ?? '' }}</textarea>
                                                            <div class="text-success small mt-1 save-status d-none"><i
                                                                    class="fas fa-check"></i> Đã lưu</div>
                                                        </td>
                                                    </tr>
                                                @endif
                                            @endforeach
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('javascript_plugins')
    <script>
        $(function () {
            if ($.fn.DataTable) {
                $('#translationTable').DataTable({
                    language: {
                        url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/vi.json',
                    },
                    pageLength: 20,
                    lengthMenu: [[10, 20, 50, 100, -1], [10, 20, 50, 100, "Tất cả"]],
                    ordering: false
                });
            }

            let timeoutId;

            $('.translation-input').on('input', function () {
                const $input = $(this);
                const $status = $input.next('.save-status');
                $status.addClass('d-none');

                clearTimeout(timeoutId);

                // Auto save after typing stops for 1 second
                timeoutId = setTimeout(() => {
                    saveTranslation($input);
                }, 1000);
            });

            $('.translation-input').on('blur', function () {
                clearTimeout(timeoutId);
                saveTranslation($(this));
            });

            function saveTranslation($input) {
                const value = $input.val();
                const file = $input.data('file');
                const key = $input.data('key');
                const code = $input.data('code');
                const $status = $input.next('.save-status');

                $.ajax({
                    url: '/ajax/admin/language/update-key',
                    method: 'POST',
                    data: { file: file, key: key, value: value, code: code },
                    success: function (res) {
                        if (res.status) {
                            $status.removeClass('d-none').hide().fadeIn(200);
                            setTimeout(() => $status.fadeOut(500), 2000);
                        } else {
                            toastr.error(res.message);
                        }
                    },
                    error: function () {
                        toastr.error('Lỗi kết nối. Vui lòng thử lại.');
                    }
                });
            }
        });
    </script>
@endsection