@extends('admin.layout')


@section('css_plugins')
    <!-- DataTables -->
    <link href="/assets/admin/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/admin/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />

@stop

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Quản lý khóa học</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Quản lý khóa học</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Main content -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">
                                Danh sách khóa học
                                <a class="btn btn-sm btn-success float-right" href="{{url("admin.course.add")}}">
                                    <i class="fas fa-plus"></i>
                                    Thêm
                                </a>
                            </h4>

                            <div class="table-responsive">
                                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead>
                                    <tr class="text-center">
                                        <th>#</th>
                                        <th style="width: 100px">Ảnh</th>
                                        <th>Tên</th>
                                        <th style="width: 80px">Lượt xem</th>
                                        <th>Cập nhật</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody class="text-center">
                                    @foreach($courses as $course)
                                        <tr>
                                            <td>{{$course->id}}</td>
                                            <td><img src="{{$course->image}}" onerror="errorImage(this)" style="width: 90px" alt="{{$course->name}}"></td>
                                            <td>{{$course->name}}</td>
                                            <td class="text-center">{{number_format($course->views)}}</td>
                                            <td class="text-center">{{date("d/m/Y H:i", strtotime($course->time_update))}}</td>
                                            <td>
                                                <a href="{{url("admin.course", ["id" => $course->id])}}" class="btn btn-primary btn-sm">Danh sách</a>
                                                <div class="pt-1"></div>
                                                <a href="{{url("admin.course.edit", ["id" => $course->id])}}" class="btn btn-success btn-sm">Sửa</a>
                                                <a href="javascript:void(0)" class="btn btn-danger btn-sm delete-course" data-id="{{$course->id}}">Xóa</a>
                                            </td>
                                        </tr>
                                    @endforeach

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>

    <!-- /.modal -->
@stop

@section('javascript_plugins')
    <!-- Required datatable js -->
    <script src="/assets/admin/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="/assets/admin/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(function (){
            $(".delete-course").on("click", function (){
                var id = $(this).data("id");
                if(confirm("Bạn có chắc chắn muốn xóa khóa học này không? Tất cả bài học cũng sẽ bị xóa!")){
                    $.post(
                        "{{url("ajax.admin.course.delete")}}",
                        {
                            id: id
                        },
                        function (e){
                            if(e.status){
                                alert("Xóa khóa học thành công");
                                location.reload();
                            }else{
                                alert("Xóa khóa học thất bại");
                            }
                        }, 'json'
                    )
                }
            })

            var table = $("#datatable").DataTable({
                "autoWidth": true,
                'columnDefs': [ {
                    'targets': [0,1,5], /* column index */
                    'orderable': false, /* true or false */
                },
                    {
                        "targets": 0,
                        "width": "29px"
                    },
                    {
                        "targets": 1,
                        "width": "100px"
                    },
                    {
                        "targets": 3,
                        "width": "80px"
                    },
                    {
                        "targets": 4,
                        "width": "160px"
                    },
                    {
                        "targets": 5,
                        "width": "100px"
                    }
                ],
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function () {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                }
            });

        })
    </script>
@stop
