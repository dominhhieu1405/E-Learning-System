<div class="list-search">
    @foreach($mangas as $manga)
    <div class="search-item" data-id="{{ $manga->id }}">
        <div class="search-title">{{ $manga->name }}</div>
    </div>
    @endforeach
</div>
