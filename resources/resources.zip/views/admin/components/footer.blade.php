<footer class="footer">
    <div class="container-fluid">
        <div class="row text-center">
            <div class="col-12">
                &copy; {{date("Y")}} Luce
                -
                Made with <i class="mdi mdi-heart text-danger"></i>
            </div>
        </div>
    </div>
</footer>