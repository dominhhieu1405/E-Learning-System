<?php

return [
    'title'               => 'Terms of Service - OnThi.io.vn',
    'heading'             => 'Terms of Service',
    'welcome'             => 'Welcome to OnThi.io.vn. Your use of our services constitutes your agreement to the terms below.',
    'sections.s1_title'   => '1. Acceptance of terms',
    'sections.s1_content' => 'By accessing and using OnThi.io.vn, you confirm that you have read, understood, and agree to be bound by these Terms and Conditions. If you do not agree, please stop using the service.',
    'sections.s2_title'   => '2. Intellectual property rights',
    'sections.s2_content' => 'All content on the system including text, graphics, logos, icons, images, and software are the property of OnThi.io.vn or its licensors. You may not copy, distribute, or use for commercial purposes without written consent.',
    'sections.s3_title'   => '3. User accounts',
    'sections.s3_list.l1' => 'You are responsible for the security of your account information and password.',
    'sections.s3_list.l2' => 'You commit to providing accurate information upon registration.',
    'sections.s3_list.l3' => 'We reserve the right to lock or delete accounts if we detect illegal behavior or fraud in exams.',
    'sections.s4_title'   => '4. VIP Services & Payment',
    'sections.s4_content' => 'VIP service packages (Plus, Pro) provide additional features such as AI assistance, detailed solutions, and long-term history storage. Service fees will not be refunded after the transaction has been successfully confirmed on the system.',
    'sections.s5_title'   => '5. Limitation of liability',
    'sections.s5_content' => 'OnThi.io.vn provides learning materials in the spirit of support. We do not guarantee absolute exam results for users and are not responsible for objective errors in the exams.',
    'sections.s6_title'   => '6. Changes to terms',
    'sections.s6_content' => 'We reserve the right to update these terms at any time. Changes will take effect immediately upon being posted on the website.',

    'last_updated' => 'Last updated: ',
];
