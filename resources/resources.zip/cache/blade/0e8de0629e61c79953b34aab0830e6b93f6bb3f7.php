<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <div class="section-header mb-4">
        <h2 class="mb-0"><?php echo e($title); ?></h2>
    </div>
    
    <ul class="nav nav-pills mb-4" id="listTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active rounded-pill px-4" id="courses-tab" data-bs-toggle="pill" data-bs-target="#courses" type="button" role="tab" aria-controls="courses" aria-selected="true">
                <?php echo e(__('common.courses')); ?>

            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link rounded-pill px-4 ms-2" id="documents-tab" data-bs-toggle="pill" data-bs-target="#documents" type="button" role="tab" aria-controls="documents" aria-selected="false">
                <?php echo e(__('common.documents')); ?>

            </button>
        </li>
    </ul>
    
    <div class="tab-content" id="listTabContent">
        
        <div class="tab-pane fade show active" id="courses" role="tabpanel" aria-labelledby="courses-tab">
            <?php if($courses && count($courses) > 0): ?>
            <div class="row g-4">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="ot-card h-100">
                        <?php if($course->image): ?>
                            <img src="<?php echo e($course->image); ?>" alt="<?php echo e($course->name); ?>" class="card-img-top" style="height: 180px; object-fit: cover;">
                        <?php else: ?>
                            <div class="card-img-top d-flex align-items-center justify-content-center" style="height: 180px; background:linear-gradient(135deg,var(--ot-primary),var(--ot-secondary));color:#fff;">
                                <i class="fas fa-book fa-3x" style="opacity:0.5;"></i>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h6 class="card-title fw-bold"><?php echo e($course->name); ?></h6>
                            <p class="card-text small text-muted text-truncate"><?php echo e($course->description ?? ''); ?></p>
                            <div class="d-grid">
                                <a href="/course/<?php echo e($course->id); ?>" class="btn btn-ot-primary py-2 rounded-3 fw-bold d-flex align-items-center justify-content-center gap-2">
                                    <span><?php echo e(__('courses.view_details')); ?></span>
                                    <i class="fas fa-arrow-right fs-12"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <?php if(isset($courses_paginate) && $courses_paginate->total_page > 1): ?>
            <div class="d-flex justify-content-center mt-5">
                <nav aria-label="Page navigation">
                    <ul class="pagination pagination-sm">
                        <?php for($i = 1; $i <= $courses_paginate->total_page; $i++): ?>
                        <li class="page-item <?php echo e($page == $i ? 'active' : ''); ?>">
                            <a class="page-link" href="/<?php echo e($type); ?>/<?php echo e($data->id); ?>/<?php echo e($i); ?>"><?php echo e($i); ?></a>
                        </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="fas fa-box-open fa-3x mb-3 opacity-50"></i>
                <p><?php echo e(__('common.no_courses')); ?></p>
            </div>
            <?php endif; ?>
        </div>
        
        
        <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="documents-tab">
            <?php if($documents && count($documents) > 0): ?>
            <div class="row g-4">
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="ot-card h-100">
                        <?php if($doc->image): ?>
                            <img src="<?php echo e($doc->image); ?>" alt="<?php echo e($doc->name); ?>" class="card-img-top" style="height: 180px; object-fit: cover;">
                        <?php else: ?>
                            <div class="card-img-top d-flex align-items-center justify-content-center" style="height: 180px; background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;">
                                <i class="fas fa-file-alt fa-3x" style="opacity:0.5;"></i>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h6 class="card-title fw-bold"><?php echo e($doc->name); ?></h6>
                            <p class="card-text small text-muted text-truncate"><?php echo e($doc->description ?? ''); ?></p>
                            <a href="/document/<?php echo e($doc->id); ?>" class="stretched-link"></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <?php if(isset($documents_paginate) && $documents_paginate->total_page > 1): ?>
            <div class="d-flex justify-content-center mt-5">
                <nav aria-label="Page navigation">
                    <ul class="pagination pagination-sm">
                        <?php for($i = 1; $i <= $documents_paginate->total_page; $i++): ?>
                        <li class="page-item <?php echo e($page == $i ? 'active' : ''); ?>">
                            <a class="page-link" href="/<?php echo e($type); ?>/<?php echo e($data->id); ?>/<?php echo e($i); ?>"><?php echo e($i); ?></a>
                        </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="fas fa-box-open fa-3x mb-3 opacity-50"></i>
                <p><?php echo e(__('common.no_documents')); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/list.blade.php ENDPATH**/ ?>