
<?php $__env->startSection('title', 'Đơn hàng đã đặt'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('user.widget.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.widget.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div id="orderList" data-page=""></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
    <script type="text/javascript">
        var lastLogTime = 0; // Lưu thời gian log gần nhất
        const $orderList = $('#orderList');

        $(function (){
            function loadOrders(page = 1) {
                if(page > $orderList.data('total') - 1) {
                    console.log('No more orders');
                    return;
                }
                if ($orderList.data("loading") !== "1") {
                    $orderList.data("loading", "1")
                    try {
                        $.post(
                            '<?php echo e(url('api.orders')); ?>',
                            {
                                page: page
                            },
                            function (response) {
                                $orderList.data("loading", "0");
                                $orderList.append(response.html);
                                $orderList.data('page', page).data("total", response.total);
                            }, 'json'
                        );
                    } catch (e) {
                        $orderList.data("loading", "0");
                    }
                }
            }
            $(window).on('scroll', function () {
                const $lastItem = $('#orderList .orderCard').last(); // Phần tử cuối cùng
                const rect = $lastItem[0].getBoundingClientRect(); // Lấy vị trí của phần tử cuối
                const windowHeight = $(window).height(); // Chiều cao của viewport
                const threshold = 50; // Ngưỡng để coi là kéo đến phần tử cuối

                // Hàm kiểm tra và log
                const checkAndLog = function () {
                    const now = Date.now(); // Lấy thời gian hiện tại
                    if (rect.top >= 0 && rect.bottom <= windowHeight + threshold && now - lastLogTime >= 1000) {
                        loadOrders(($orderList.data('page') - 1) + 1);
                        lastLogTime = now; // Cập nhật thời gian log
                    }
                };

                checkAndLog();
            });
            loadOrders(1);
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/orders.blade.php ENDPATH**/ ?>