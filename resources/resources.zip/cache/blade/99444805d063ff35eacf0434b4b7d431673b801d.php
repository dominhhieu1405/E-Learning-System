
<?php $__env->startSection('title', 'Mua sắm hoàn tiền'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('user.widget.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.widget.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="card rounded border-shopee mt-3">
        <div class="card-body p-2">
            <div class="d-flex align-items-center mb-3">
                <h6 class="fw-bold mb-0 c-shopee">Check hoàn tiền</h6>
            </div>
            <div class="search-form justify-content-between">
                <form id="form-main-search-deal" action="#">
                    <input type="text" id="in_main_keyword" name="keyword" class="form-control bg-light" placeholder="Nhập link sản phảm" autocomplete="off" aria-label="" value="<?php echo e($keyword); ?>" data-hash="">
                    <button type="button"><i class="ti ti-link"></i></button>
                </form>
                <button name="button" class="btn btn-danger m-0" id="main_search_deal" style="height: 40px;background: #EE4D2D;"><i class="ti ti-chevron-right"></i></button>
            </div>
            <div class="d-flex align-items-center justify-content-between mt-2 p-1 lh-1" style="background: #ffb4a3;border-radius: 3px;font-size: 12px;">
                <div class="d-flex me-1">
                    <div class="icon pe-1"><i class="ti ti-time-duration-15"></i></div><span>Ghi nhận 36 giờ</span>
                </div>
                <div class="d-flex me-1">
                    <div class="icon pe-1"><i class="ti ti-calendar"></i></div><span>Hoàn tiền trong 14 ngày</span>
                </div>
            </div>
        </div>
    </div>


    <div class="card rounded border-shopee-dashed mt-3 product-preview" style="display: none">
        <div class="product-image-preview">
            <img src="/assets/img/product-sample.png" onerror="this.src='/assets/img/product-sample.png'" class="card-img-top" alt="">
        </div>
        <div class="card-body p-2">
            <div class="product-details">
                <p class="p-name">Product Name</p>
                <p>
                    <span class="badge bg-shopee">Đã bán: <span id="sell_amount">0</span> </span>
                    <span class="p-price">0 VNĐ</span>
                </p>
                <div>
                    <div class="p-cashback mt-1">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <b>
                                    Tổng hoàn tiền
                                </b>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="p-cashback-total">đến 0 VNĐ</span>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between p-dc-child">
                            <div class="d-flex align-items-center">
                                Hoàn tiền cơ bản
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="p-cashback-mxh">đến 0 VNĐ</span>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between p-dc-child" id="extra_cashback">
                            <div class="d-flex align-items-center">
                                Hoàn tiền Xtra
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="p-cashback-xtra">đến 0 VNĐ</span>
                            </div>
                        </div>
                        <hr>
                        <div class="d-flex align-items-center" style="font-size: 14px;color:#70a822;" id="xtra_msg">
                            <span class="mx-auto small bg-warning d-inline text-dark px-2">Sản phẩm bạn đang xem có Hoàn tiền Xtra</span>
                        </div>
                    </div>
                    <a class="btn btn-shopee mt-0 w-100" id="buy_link"><i class="ti ti-shopping-bag"></i> Mua ngay</a>
                    <a class="btn btn-light mt-2 w-100" id="share_link" data-hash="" data-link=""><i class="ti ti-share"></i> Chia sẻ</a>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <div class="text-center text-danger text-sm">Lưu ý: Giá trị hoàn tiền hiển thị ở đây chỉ là tương đối, giá trị hoàn tiền thật sẽ được thông tin cụ thể lúc ghi nhận</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
    <script type="text/javascript">
        const itemInp = $("#in_main_keyword");
        const goTo = '<?php echo e(url('api.goto')); ?>';
        const shareLink = $("#share_link");
        $(function (){
            itemInp.on('keydown', function (event) {
                if (event.key === "Enter" || event.keyCode === 13) {
                    event.preventDefault();
                    checkItem();
                }
            });
            itemInp.on('paste', function() {
                let allowDomains = ["shopee.vn", "shopee.com", "shp.ee", "s.shopee.vn", "shope.ee", "www.shopee.vn", "vn.shp.ee", "u.shopee.vn"];
                let url = itemInp.val();
                if(url.length < 7) return 0;
                try {
                    let parsedURL = new URL(url);
                    let domain = parsedURL.hostname;
                    if(allowDomains.includes(domain)) {
                        checkItem();
                    }
                } catch (e) {
                    return 0;
                }

            });
            function checkItem(){
                let allowDomains = ["shopee.vn", "shopee.com", "shp.ee", "s.shopee.vn", "shope.ee", "www.shopee.vn", "vn.shp.ee", "u.shopee.vn"];
                let url = itemInp.val();
                try {
                    let parsedURL = new URL(url);
                    let domain = parsedURL.hostname;
                    if(url.length < 7 || !allowDomains.includes(domain)) {
                        alert("Vui lòng nhập link sản phẩm từ Shopee");
                        return 0;
                    }
                    let hash = md5(url);
                    if(itemInp.data('hash') === hash) return 0;
                    itemInp.data('hash', hash);
                    $.post(
                        '<?php echo e(url('api.check')); ?>',
                        {
                            url: url
                        },
                        function (e){
                            if(e.status){
                                $(".product-image-preview img").attr('src', e.data.image);
                                $(".p-name").text(e.data.name);
                                $("#sell_amount").text(e.data.sales);
                                $(".product-preview").show();
                                $(".p-price").text(e.data.price + " VNĐ");
                                $(".p-cashback-total").text("đến " + e.data.commission + " VNĐ");
                                $(".p-cashback-mxh").text("đến " + e.data.hh + " VNĐ");
                                $(".p-cashback-xtra").text("đến " + e.data.hh_extra + " VNĐ");
                                $("#buy_link").attr('href', goTo + '?url=' + e.data.link);
                                shareLink.data('hash', e.data.link);
                                shareLink.data('link', '');
                                if(e.data.has_extra === false || e.data.hh_extra - 0 === 0){
                                    $("#extra_cashback")[0].style.setProperty('display', 'none', 'important');
                                    $("#xtra_msg")[0].style.setProperty('display', 'none', 'important');
                                } else {
                                    $("#extra_cashback")[0].style.setProperty('display', 'flex', 'important');
                                    $("#xtra_msg")[0].style.setProperty('display', 'flex', 'important');
                                }
                            } else {
                                alert(e.message);
                                $(".product-preview").hide();
                            }
                        }, 'json'
                    )
                } catch (e) {
                    alert("Vui lòng nhập link sản phẩm từ Shopee");
                    return 0;
                }
            }
            shareLink.on("click", function (e){
                if(shareLink.data('hash') === '') return 0;
                if(shareLink.data('link') === ''){
                    $.post(
                        '<?php echo e(url('api.create_link')); ?>',
                        {
                            hash: shareLink.data('hash')
                        },
                        function (e){
                            if(e.status){
                                shareLink.data('link', e.link);
                                let copyText = document.createElement("input");
                                copyText.value = e.link;
                                document.body.appendChild(copyText);
                                copyText.select();
                                document.execCommand("copy");
                                document.body.removeChild(copyText);
                                alert("Đã sao chép liên kết chia sẻ");
                            } else {
                                alert("Có lỗi xảy ra, vui lòng thử lại sau");
                            }
                        }, 'json'
                    )
                } else {
                    // Copy to clipboard
                    let copyText = document.createElement("input");
                    copyText.value = shareLink.data('link');
                    document.body.appendChild(copyText);
                    copyText.select();
                    document.execCommand("copy");
                    document.body.removeChild(copyText);
                    alert("Đã sao chép liên kết chia sẻ");
                }
            });
            $("#main_search_deal").on("click", function (){
                checkItem();
            })

            <?php if(strlen($keyword) > 0): ?>
                checkItem();
            <?php endif; ?>
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/shopping.blade.php ENDPATH**/ ?>