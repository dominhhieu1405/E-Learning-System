<?php $__env->startSection('title', __('courses.title')); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/assets/css/pages/courses.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="text-center mb-5 animate-fadeInUp">
        <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-2 rounded-pill mb-3 fw-bold">
            <?php echo e(__('courses.badge')); ?>

        </span>
        <h2 class="fw-800 mb-2"><?php echo e(__('courses.heading')); ?></h2>
        <p class="text-muted"><?php echo e(__('courses.subheading')); ?></p>
    </div>
    
    <?php if($data && count($data) > 0): ?>
    <div class="row g-4">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-md-6 col-lg-3 animate-fadeInUp">
            <div class="ot-card h-100 border-0 shadow-sm course-card overflow-hidden">
                <div class="position-relative">
                    <?php if($course->image): ?>
                        <img src="<?php echo e($course->image); ?>" alt="<?php echo e($course->name); ?>" class="card-img-top" style="height: 180px; object-fit: cover;">
                    <?php else: ?>
                        <div class="card-img-top d-flex align-items-center justify-content-center" style="height: 180px; background:linear-gradient(135deg,var(--ot-primary),var(--ot-secondary));color:#fff;">
                            <i class="fas fa-book fa-3x" style="opacity:0.5;"></i>
                        </div>
                    <?php endif; ?>
                    <div class="course-overlay"></div>
                    <span class="badge bg-white text-primary position-absolute top-0 end-0 m-3 shadow-sm px-2 py-1 rounded-pill small fw-bold">
                        <?php echo e(__('courses.new')); ?>

                    </span>
                </div>
                <div class="card-body p-4">
                    <h5 class="card-title fw-bold mb-2 text-dark-emphasis"><?php echo e($course->name); ?></h5>
                    <p class="card-text small text-muted mb-4 line-clamp-2" style="height: 40px;"><?php echo e($course->description ?? __('courses.no_description')); ?></p>
                    
                    <div class="d-grid">
                        <a href="/course/<?php echo e($course->id); ?>" class="btn btn-ot-primary py-2 rounded-3 fw-bold d-flex align-items-center justify-content-center gap-2">
                            <span><?php echo e(__('courses.view_details')); ?></span>
                            <i class="fas fa-arrow-right fs-12"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <?php if(isset($paginate) && $paginate->total_page > 1): ?>
    <div class="d-flex justify-content-center mt-5">
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-md shadow-sm rounded-pill overflow-hidden">
                <?php for($i = 1; $i <= $paginate->total_page; $i++): ?>
                <li class="page-item <?php echo e($page == $i ? 'active' : ''); ?>">
                    <a class="page-link px-4 border-0" href="/courses/<?php echo e($i); ?>"><?php echo e($i); ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <div class="text-center py-5">
        <div class="mb-4">
            <i class="fas fa-box-open fa-4x text-muted opacity-25"></i>
        </div>
        <h5 class="text-muted"><?php echo e(__('courses.no_courses')); ?></h5>
        <p class="text-muted small"><?php echo e(__('courses.back_later')); ?></p>
    </div>
    <?php endif; ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/courses.blade.php ENDPATH**/ ?>