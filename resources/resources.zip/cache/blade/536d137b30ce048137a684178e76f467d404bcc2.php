<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box"><h4 class="mb-0">Phiên thi</h4></div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="50">#</th>
                                        <th>Thí sinh</th>
                                        <th>Đề thi</th>
                                        <th width="80">Điểm</th>
                                        <th width="100">Trạng thái</th>
                                        <th width="100">Thời gian</th>
                                        <th width="150">Bắt đầu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($sessions && count($sessions) > 0): ?>
                                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($s->id); ?></td>
                                            <td><?php echo e($s->user_display_name ?? $s->username ?? 'N/A'); ?></td>
                                            <td><?php echo e($s->exam_title ?? 'N/A'); ?></td>
                                            <td><strong><?php echo e($s->total_score); ?></strong></td>
                                            <td>
                                                <?php if($s->status === 'completed'): ?>
                                                    <span class="badge bg-success">Hoàn thành</span>
                                                <?php elseif($s->status === 'in_progress'): ?>
                                                    <span class="badge bg-warning">Đang thi</span>
                                                <?php else: ?>
                                                    <span class="badge bg-info"><?php echo e($s->status); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($s->time_spent ? gmdate('H:i:s', $s->time_spent) : '—'); ?></td>
                                            <td><?php echo e($s->started_at); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr><td colspan="7" class="text-center text-muted">Chưa có phiên thi nào</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/sessions.blade.php ENDPATH**/ ?>