<!-- Sidebar Wrapper -->
<div id="sidebar-container" itemscope="itemscope" itemtype="https://schema.org/WPSideBar" role="banner" style="position: relative; overflow: visible; box-sizing: border-box; min-height: 1px;">

    <div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 1px; position: static; transform: none;">
        <div class="sidebar section" id="sidebar">
            <div class="widget">
                <div class="widget-content">
                    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5588133464975020"
                            crossorigin="anonymous"></script>
                    <!-- Vuong-1 -->
                    <ins class="adsbygoogle"
                            style="display:block"
                            data-ad-client="ca-pub-5588133464975020"
                            data-ad-slot="3759424216"
                            data-ad-format="auto"
                            data-full-width-responsive="true"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>

            <div class="widget LinkList">
                <div class="widget-title">
                    <h3 class="title">
                        Theo dõi chúng tôi
                    </h3>
                </div>
                <div class="widget-content">
                    <ul class="socialFilter social-bg-hover social">
                        <li>
                            <a class="facebook" href="https://www.facebook.com/study.with.me.2k6" rel="noopener noreferrer" target="_blank" title="facebook"> Facebook </a>
                        </li>
                        <li>
                            <a class="whatsapp" href="#" rel="noopener noreferrer" target="_blank" title="whatsapp"> Whatsapp </a>
                        </li>
                        <li>
                            <a class="instagram" href="#" rel="noopener noreferrer" target="_blank" title="instagram"> Instagram </a>
                        </li>
                        <li>
                            <a class="youtube" href="#" rel="noopener noreferrer" target="_blank" title="youtube"> Youtube </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="widget PopularPosts">
                <div class="widget-title">
                    <h3 class="title">
                        Khóa học HOT
                    </h3>
                </div>
                <div class="widget-content sidebar-posts">


                    <?php $__currentLoopData = \Models\Web::courses(1, 5, "views"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="popular-post post item<?php echo e($i); ?>">
                            <div class="relatedui-posts-data">
                                <span class="post-author"><?php echo e(\Models\Web::typeData($course->type)->name); ?></span>
                                <span class="label-news-flex"><?php echo e(\Models\Web::subjectData($course->subject)->name); ?></span>
                            </div>
                            <div class="relatedui-posts-box">
                                <div class="relatedui-posts-box-flex">
                                    <h3 class="entry-title vcard">
                                        <a href="<?php echo e(url("course", ["id" => $course->id])); ?>" rel="bookmark" title="<?php echo e($course->name); ?>"><?php echo e($course->name); ?></a>
                                    </h3>
                                    <div class="post-snip flex">
                                        <span class="post-date" style="margin: 0"><?php echo e(date("d/m/y H:i", strtotime($course->time_add))); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <div class="widget HTML">
                <div class="widget-title">
                    <h3 class="title">
                        Tài liệu xem nhiều
                    </h3>
                </div>
                <div class="widget-content">

                    <div class="BiggerSidebarOk">

                        <?php $__currentLoopData = \Models\Web::documents(1, 5, "views"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="sidebarui-posts">
                                <div class="relatedui-posts-box">
                                    <h3 class="entry-title" style="margin: 0.5em 0">
                                        <a href="<?php echo e(url("document", ["id" => $document->id])); ?>" title="<?php echo e($document->name); ?>">
                                            <?php echo e($document->name); ?>

                                        </a>
                                    </h3>
                                    <div class="post-snip">
                                        <span class="post-date" style="margin: 0"><?php echo e(date("d/m/y H:i", strtotime($document->time_add))); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                </div>
            </div>


            <div class="widget HTML" style="display: none">
                <div class="widget-title">
                    <h3 class="title">
                        Comments
                    </h3>
                </div>
                <div class="widget-content">
                    <div class="comment-list">
                        <div class="cmmTool">
                            <a class="engine-link" href="#">
                                            <span class="comment-image">
                                                <img class="snip-thumbnail lazy-img" src="https://1.bp.blogspot.com/-QN2lgvtYZco/YN3mUSryAVI/AAAAAAAAADs/KrR-etCcvUMcPl06jopTs9pzq59IAXhMQCLcBGAsYHQ/w72-h72-p-k-no-nu/avatar.jpg">
                                            </span>
                                <div class="comment-hero">
                                    <h2 class="entry-title cmm-title">Anonymous</h2>
                                    <p class="comment-snippet">This is Third Comment Testing.</p>
                                </div>
                            </a>
                        </div>
                        <div class="cmmTool">
                            <a class="engine-link" href="#">
                                            <span class="comment-image">
                                                <img class="snip-thumbnail lazy-img" src="//blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjNhdeGnAaSnSI_ujAZ8aozZCvN7PEItpN8CpoLgRCJY_c-D6wK-Z6HsWScvs7HVK6zbfxDSh4rzM0GyVMmKnuNUReBBx6hcYq4W-k_uQANspVqU1NVwGW9c7HSYzYC8w/s113/jane-doe-img+%281%29.png=w39-h39-p-k-no-nu">
                                            </span>
                                <div class="comment-hero">
                                    <h2 class="entry-title cmm-title">Jane Doe</h2>
                                    <p class="comment-snippet">This is Second Comment Testing.</p>
                                </div>
                            </a>
                        </div>
                        <div class="cmmTool">
                            <a class="engine-link" href="#">
                                            <span class="comment-image">
                                                <img class="snip-thumbnail lazy-img" src="//blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjNhdeGnAaSnSI_ujAZ8aozZCvN7PEItpN8CpoLgRCJY_c-D6wK-Z6HsWScvs7HVK6zbfxDSh4rzM0GyVMmKnuNUReBBx6hcYq4W-k_uQANspVqU1NVwGW9c7HSYzYC8w/s113/jane-doe-img+%281%29.png=w39-h39-p-k-no-nu">
                                            </span>
                                <div class="comment-hero">
                                    <h2 class="entry-title cmm-title">Jane Doe</h2>
                                    <p class="comment-snippet">This is reply comment test.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>


            <div class="widget Label" data-version="2" id="Label2">
                <div class="widget-title">
                    <h3 class="title">
                        Nhãn
                    </h3>
                </div>
                <div class="widget-content cloud-label">
                    <ul>
                        <?php $__currentLoopData = \Models\Web::allType(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="label-name" href="<?php echo e(url("type", ["id" => $data->id])); ?>">
                                    <?php echo e($data->name); ?>

                                    <span class="label-count">0</span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = \Models\Web::allClass(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="label-name" href="<?php echo e(url("class", ["id" => $data->id])); ?>">
                                    <?php echo e($data->name); ?>

                                    <span class="label-count">0</span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = \Models\Web::allSubject(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="label-name" href="<?php echo e(url("subject", ["id" => $data->id])); ?>">
                                    <?php echo e($data->name); ?>

                                    <span class="label-count">0</span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>


            <div class="widget">
                <div class="widget-content">
                    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5588133464975020"
                            crossorigin="anonymous"></script>
                    <!-- Vuong-2 -->
                    <ins class="adsbygoogle"
                            style="display:block"
                            data-ad-client="ca-pub-5588133464975020"
                            data-ad-slot="8820179206"
                            data-ad-format="auto"
                            data-full-width-responsive="true"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\localhost\DGNL\resources\views/user/components/sidebar.blade.php ENDPATH**/ ?>