
<?php $__env->startSection('title', 'Đổi thưởng'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('user.widget.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.widget.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row mt-3">
        <div class="user_point_pedding col-6">
            <a href="<?php echo e(url("shopping")); ?>">
                <div class="card border-shopee-dashed">
                    <div class="card-body p-2">
                        <div class="row">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-circle">
                                    <div class="icons bg-shopee text-white rounded-circle">
                                        <i class="ti ti-history"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <h6 class="small mb-1">DP hiện tại</h6>
                                <h6 class="fs-6 lh-1 mb-0 fw-bold"><span id="js-rp-pending"><?php echo e(number_format(userget()->point)); ?></span> DP</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-6">
            <a href="">
                <div class="card border-shopee-dashed">
                    <div class="card-body p-2">
                        <div class="row">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-circle">
                                    <div class="icons bg-success text-white rounded-circle">
                                        <i class="ti ti-arrow-down"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <h6 class="small mb-1">DP đã đổi</h6>
                                <h6 class="fs-6 lh-1 mb-0 fw-bold"><span id="js-rp-today"><?php echo e(number_format(userget()->point_used)); ?></span> DP</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <div class="card rounded border-shopee mt-3">
        <div class="card-body theme-form">
            <h3 class="card-title">Đổi thưởng</h3>

            <div class="form-group d-block">
                <label for="bank" class="form-label">Ngân hàng</label>
                <div class="form-input mb-4">
                    <select class="form-control" id="bank">
                        <?php $__currentLoopData = \Models\User::banks(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bank->code); ?>">[<?php echo e($bank->bin); ?>] <?php echo e($bank->short_name); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <i class="ti ti-building-bank"></i>
                </div>
            </div>

            <div class="form-group d-block">
                <label for="stk" class="form-label">Số tài khoản</label>
                <div class="form-input mb-4">
                    <input type="text" class="form-control" id="stk" value="" placeholder="Nhập số tài khoản">
                    <i class="ti ti-numbers"></i>
                </div>
            </div>
            <div class="form-group d-block">
                <label for="name" class="form-label">Tên chủ tài khoản</label>
                <div class="form-input mb-4">
                    <input type="text" class="form-control" id="name" value="" placeholder="Tên chủ tài khoản">
                    <i class="ti ti-user"></i>
                </div>
            </div>
            <div class="form-group d-block">
                <label for="point" class="form-label">Số điểm muốn rút (<b>1 DP = 1 VNĐ</b>)</label>
                <div class="form-input mb-4">
                    <select class="form-control" id="point">
                        <option value="5000">5.000 DP</option>
                        <option value="10000">10.000 DP</option>
                        <option value="20000">20.000 DP</option>
                        <option value="50000">50.000 DP</option>
                        <option value="100000">100.000 DP</option>
                        <option value="200000">200.000 DP</option>
                        <option value="500000">500.000 DP</option>
                        <option value="1000000">1.000.000 DP</option>
                    </select>
                    <i class="ti ti-cash"></i>
                </div>
            </div>


            <button class="btn btn-success w-100 btn-block mt-1" id="withdrawPoint">Đổi ngay</button>

        </div>
    </div>
    <div class="mt-3">
        <h2 class="mb-2">Lịch sử đổi thưởng</h2>
        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-2">
                <div class="card border-0">
                    <div class="card-body p-2">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-circle">
                                    <?php if($data->status == 1): ?>
                                        <div class="icons bg-success text-white rounded-circle">
                                            <i class="ti ti-check"></i>
                                        </div>
                                    <?php elseif($data->status == 2): ?>
                                        <div class="icons bg-danger text-white rounded-circle">
                                            <i class="ti ti-x"></i>
                                        </div>
                                    <?php else: ?>
                                        <div class="icons bg-shopee text-white rounded-circle">
                                            <i class="ti ti-history"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <h6 class="fs-6 mb-1">Đổi <?php echo e(number_format($data->point)); ?> DP sang <?php echo e($data->bank); ?></h6>
                                <?php if($data->status == 1): ?>
                                    <h6 class="lh-1 small mb-0 fw-bold text-success">Thành công</h6>
                                <?php elseif($data->status == 2): ?>
                                    <h6 class="lh-1 small mb-0 fw-bold text-danger">Từ chối - Lý do: <?php echo e($data->note); ?></h6>
                                <?php else: ?>
                                    <h6 class="lh-1 small mb-0 fw-bold text-warning">Đang xử lý</h6>
                                <?php endif; ?>
                                <small class="small text-secondary"><i class="ti ti-clock"></i> <?php echo e(date("H:i d/m/Y", strtotime($data->time))); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
    <script type="text/javascript">
        $(function (){
            $("#withdrawPoint").on("click", function (){
                let bank = $("#bank").val().trim();
                let stk = $("#stk").val().trim();
                let name = $("#name").val().trim();
                let point = $("#point").val().trim();
                if(bank === "" || stk === "" || name === "" || point === ""){
                    alert("Vui lòng nhập đầy đủ thông tin")
                    return false;
                }
                $.post(
                    "<?php echo e(url("api.withdraw")); ?>",
                    {
                        bank: bank,
                        stk: stk,
                        name: name,
                        point: point
                    },
                    function (e){
                        alert(e.message)
                        if(e.status){
                            location.reload()
                        }
                    }
                )
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/withdraw.blade.php ENDPATH**/ ?>