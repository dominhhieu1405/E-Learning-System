<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box"><h4 class="mb-0">Thêm câu hỏi vào Ngân hàng</h4></div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <form id="formQuestionAdd">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Loại câu hỏi</label>
                                    <select name="question_type" class="form-control custom-select" id="qType">
                                        <option value="mc">Trắc nghiệm (MC)</option>
                                        <option value="ms">Nhiều lựa chọn (MS)</option>
                                        <option value="tf">Đúng/Sai (TF)</option>
                                        <option value="short">Trả lời ngắn</option>
                                        <option value="mblanks">Nhiều ô trống</option>
                                        <option value="matching">Ghép cột</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Danh mục HSA</label>
                                    <select name="bank_category" class="form-control custom-select">
                                        <option value="dinh_luong">Định lượng</option>
                                        <option value="dinh_tinh">Định tính</option>
                                        <option value="tu_chon">Tự chọn</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Môn học</label>
                                    <select name="subject_id" class="form-control custom-select">
                                        <option value="">-- Không --</option>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    Nội dung câu hỏi <span class="text-danger">*</span>
                                    <div class="math-toolbar" data-target="#edContent">
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="\frac{a}{b}" title="Phân số">$\frac{a}{b}$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="\sqrt{x}" title="Căn bậc 2">$\sqrt{x}$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="x^{n}" title="Lũy thừa">$x^{n}$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="\alpha" title="Alpha">$\alpha$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-latex="\pi" title="Pi">$\pi$</button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-type="image" title="Chèn ảnh"><i class="ri-image-line"></i></button>
                                        <button type="button" class="btn btn-xs btn-outline-info" data-type="audio" title="Chèn âm thanh"><i class="ri-volume-up-line"></i></button>
                                    </div>
                                </label>
                                <textarea name="content" class="form-control" rows="4" required id="edContent"></textarea>
                                <div class="mt-2 p-2 border rounded bg-light" id="preContent" style="min-height: 40px;">
                                    <small class="text-muted">Xem trước nội dung...</small>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Bài đọc đi kèm (nếu có)</label>
                                <textarea name="passage" class="form-control" rows="3" id="edPassage"></textarea>
                                <div class="mt-2 p-2 border rounded bg-light" id="prePassage" style="min-height: 40px; display:none;">
                                    <small class="text-muted">Xem trước bài đọc...</small>
                                </div>
                            </div>

                             
                             <div id="mcOptions">
                                <label class="form-label">Đáp án trắc nghiệm</label>
                                <div class="mb-2"><div class="input-group"><span class="input-group-text">A</span><input type="text" name="option_a" class="form-control" placeholder="Đáp án A"></div></div>
                                <div class="mb-2"><div class="input-group"><span class="input-group-text">B</span><input type="text" name="option_b" class="form-control" placeholder="Đáp án B"></div></div>
                                <div class="mb-2"><div class="input-group"><span class="input-group-text">C</span><input type="text" name="option_c" class="form-control" placeholder="Đáp án C"></div></div>
                                <div class="mb-2"><div class="input-group"><span class="input-group-text">D</span><input type="text" name="option_d" class="form-control" placeholder="Đáp án D"></div></div>
                                <div class="mb-3" id="mcSingleCorrect">
                                    <label class="form-label">Đáp án đúng</label>
                                    <select name="correct_answer_mc" class="form-control custom-select">
                                        <option value="A">A</option>
                                        <option value="B">B</option>
                                        <option value="C">C</option>
                                        <option value="D">D</option>
                                    </select>
                                </div>
                                <div class="mb-3" id="mcMultiCorrect" style="display:none;">
                                    <label class="form-label d-block">Đáp án đúng (chọn nhiều)</label>
                                    <?php $__currentLoopData = ['A', 'B', 'C', 'D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" name="correct_answer_ms[]" value="<?php echo e($label); ?>" id="ms_<?php echo e($label); ?>">
                                        <label class="form-check-label" for="ms_<?php echo e($label); ?>"><?php echo e($label); ?></label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            
                            <div id="mblanksOptions" style="display:none;">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    Đáp án các ô trống (Theo thứ tự [blank] trong câu hỏi)
                                    <button type="button" class="btn btn-xs btn-soft-success" id="btnAddBlank"><i class="ri-add-line"></i> Thêm ô</button>
                                </label>
                                <div id="mblanksContainer"></div>
                                <small class="text-muted d-block mt-1">Lưu ý: Trong nội dung câu hỏi, hãy đánh dấu vị trí ô trống bằng chuỗi <code>[blank]</code></small>
                            </div>

                            
                            <div id="matchingOptions" style="display:none;">
                                <label class="form-label">Các cặp ghép</label>
                                <?php for($i = 1; $i <= 4; $i++): ?>
                                <div class="row g-2 mb-2">
                                    <div class="col-6"><input type="text" name="matching_left_<?php echo e($i); ?>" class="form-control form-control-sm" placeholder="Vế trái <?php echo e($i); ?>"></div>
                                    <div class="col-6"><input type="text" name="matching_right_<?php echo e($i); ?>" class="form-control form-control-sm" placeholder="Vế phải <?php echo e($i); ?>"></div>
                                </div>
                                <?php endfor; ?>
                            </div>

                            
                            <div id="tfOptions" style="display:none;">
                                <label class="form-label">4 ý con Đúng/Sai</label>
                                <?php for($i = 1; $i <= 4; $i++): ?>
                                <div class="card card-body bg-light mb-2">
                                    <div class="row align-items-center">
                                        <div class="col-md-1"><strong><?php echo e(chr(96+$i)); ?>)</strong></div>
                                        <div class="col-md-8"><input type="text" name="tf_content_<?php echo e($i); ?>" class="form-control" placeholder="Nội dung ý <?php echo e(chr(96+$i)); ?>"></div>
                                        <div class="col-md-3">
                                            <select name="tf_correct_<?php echo e($i); ?>" class="form-control custom-select">
                                                <option value="1">Đúng</option>
                                                <option value="0">Sai</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <?php endfor; ?>
                            </div>

                            
                            <div id="shortOptions" style="display:none;">
                                <div class="mb-3">
                                    <label class="form-label">Đáp án đúng</label>
                                    <input type="text" name="correct_answer_short" class="form-control" placeholder="Nhập đáp án chính xác">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Giải thích</label>
                                <textarea name="explanation" class="form-control" rows="3"></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary"><i class="ri-save-line"></i> Thêm câu hỏi</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript_plugins'); ?>
<script>
$(function(){
    $('#qType').on('change', function(){
        var t = $(this).val();
        $('#mcOptions').toggle(t === 'mc' || t === 'ms');
        $('#mcSingleCorrect').toggle(t === 'mc');
        $('#mcMultiCorrect').toggle(t === 'ms');
        $('#tfOptions').toggle(t === 'tf');
        $('#shortOptions').toggle(t === 'short');
        $('#mblanksOptions').toggle(t === 'mblanks');
        $('#matchingOptions').toggle(t === 'matching');
        
        if(t === 'mblanks' && $('#mblanksContainer').is(':empty')) renderBlankInput('');
    });

    function renderBlankInput(val) {
        const count = $('#mblanksContainer .input-group').length + 1;
        const html = `
        <div class="input-group mb-2">
            <span class="input-group-text">#${count}</span>
            <input type="text" name="mblank_val[]" class="form-control" value="${val}" placeholder="Đáp án ô trống ${count}">
            <button class="btn btn-outline-danger btnRemoveBlank" type="button"><i class="ri-delete-bin-line"></i></button>
        </div>`;
        $('#mblanksContainer').append(html);
    }

    $('#btnAddBlank').on('click', function() { renderBlankInput(''); });
    $(document).on('click', '.btnRemoveBlank', function() { $(this).closest('.input-group').remove(); });

    $('#formQuestionAdd').on('submit', function(e){
        e.preventDefault();
        var fd = new FormData(this);
        var qType = $('#qType').val();

        if(qType === 'mc' || qType === 'ms'){
            fd.append('options', JSON.stringify([
                fd.get('option_a'), fd.get('option_b'), fd.get('option_c'), fd.get('option_d')
            ]));
            if (qType === 'ms') {
                const msChecked = [];
                $('#formQuestionAdd [name="correct_answer_ms[]"]:checked').each(function() {
                    msChecked.push($(this).val());
                });
                fd.append('correct_answer', msChecked.join(','));
            } else {
                fd.append('correct_answer', fd.get('correct_answer_mc'));
            }
        } else if(qType === 'tf'){
            var tfItems = [];
            for(var i=1;i<=4;i++){
                tfItems.push({
                    content: fd.get('tf_content_'+i),
                    is_correct: parseInt(fd.get('tf_correct_'+i))
                });
            }
            fd.append('tf_items', JSON.stringify(tfItems));
        } else if(qType === 'mblanks'){
            const blankVals = [];
            $('#mblanksContainer input[name="mblank_val[]"]').each(function() {
                blankVals.push($(this).val());
            });
            fd.append('correct_answer', blankVals.join('|'));
        } else if(qType === 'matching'){
            const pairs = [];
            for(let i=1; i<=4; i++) {
                const left = fd.get('matching_left_'+i);
                const right = fd.get('matching_right_'+i);
                if(left && right) pairs.push({left, right});
            }
            fd.append('options', JSON.stringify(pairs));
            fd.append('correct_answer', 'matching');
        } else {
            fd.append('correct_answer', fd.get('correct_answer_short'));
        }

        $.ajax({
            url: '/ajax/admin/question/add',
            method: 'POST', data: fd, processData: false, contentType: false,
            success: function(res){
                if(res.status){ toastr.success(res.message); setTimeout(()=>location.href='/admin/questions', 800); }
                else toastr.error(res.message);
            }
        });
    });

    // Live Preview
    let preTimer;
    $('#edContent, #edPassage').on('input', function(){
        const val = $(this).val();
        const target = $(this).attr('id') === 'edContent' ? '#preContent' : '#prePassage';
        if($(this).attr('id') === 'edPassage') $(target).toggle(val.length > 0);
        $(target).html(val || '<small class="text-muted">Chưa có nội dung...</small>');
        clearTimeout(preTimer);
        preTimer = setTimeout(() => {
            if(window.MathJax && window.MathJax.typesetPromise) {
                window.MathJax.typesetPromise([document.querySelector(target)]);
            }
        }, 500);
    });

    // Math Toolbar
    $('.math-toolbar button').on('click', function(e){
        e.preventDefault();
        const latex = $(this).data('latex');
        const type = $(this).data('type');
        const targetId = $(this).closest('.math-toolbar').data('target');
        const $el = $(targetId);
        const start = $el[0].selectionStart, end = $el[0].selectionEnd;
        const text = $el.val();
        
        let insert = '';
        if (type === 'image') {
            const url = prompt('Nhập URL ảnh:');
            if (url) insert = `<img src="${url}" style="max-width:100%; border-radius:8px; margin:10px 0;" />`;
        } else if (type === 'audio') {
            const url = prompt('Nhập URL âm thanh (mp3, wav...):');
            if (url) insert = `<div class="mt-2 text-center"><audio controls style="max-width:100%"><source src="${url}" type="audio/mpeg">Trình duyệt không hỗ trợ nghe.</audio></div>`;
        } else {
            insert = `$${latex}$`;
        }

        if (!insert) return;
        
        $el.val(text.substring(0, start) + insert + text.substring(end));
        $el[0].selectionStart = $el[0].selectionEnd = start + insert.length;
        $el.focus().trigger('input');
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/question-add.blade.php ENDPATH**/ ?>