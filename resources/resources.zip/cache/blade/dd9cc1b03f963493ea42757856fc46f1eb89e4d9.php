<div class="offcanvas sidebar-offcanvas offcanvas-start" tabindex="-1" id="offcanvasLeft">
    <div class="offcanvas-header">
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body pt-0">


        <div class="sidenav-profile">
            <div class="user-profile" style="border-radius: 50%;overflow: hidden;">
                <img class="user-avatar" src="<?php echo e(userget()->avatar_url); ?>" onerror="this.src='/assets/img/avatar/error.png'" alt="Đỗ Minh Hiếu">
            </div>
            <div class="user-info">
                <h5 class="user-name mb-1 c-shopee fs-5"><?php echo e(userget()->name); ?></h5>
                <p class="available-balance text-white"><span class="user-rp"><?php echo e(number_format(userget()->point)); ?></span> DP</p>
            </div>
        </div>

        <div class="sidebar-content">
            <ul class="link-section">
                <li>
                    <div class="pages">
                        <h4>Chế độ tối</h4>
                        <div class="switch-btn">
                            <input id="dark-switch" type="checkbox" aria-label=""/>
                        </div>
                    </div>
                </li>

                <li>
                    <a href="<?php echo e(url('profile')); ?>" class="pages">
                        <h4>Thông tin tài khoản</h4>
                        <i class="ti ti-user"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('shopping')); ?>" class="pages">
                        <h4>Mua sắm hoàn tiền</h4>
                        <i class="ti ti-shopping-cart"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('orders')); ?>" class="pages">
                        <h4>Đơn hàng đã đặt</h4>
                        <i class="ti ti-history"></i>
                    </a>
                </li>
                <!--<li>
                    <a href="#" class="pages">
                        <h4>Nhận điểm DP</h4>
                        <i class="ti ti-plus"></i>
                    </a>
                </li>-->
                <li>
                    <a href="<?php echo e(url("withdraw")); ?>" class="pages">
                        <h4>Đổi thưởng</h4>
                        <i class="ti ti-cash-banknote"></i>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/OnThi.io.vn" class="pages">
                        <h4>Theo dõi trang Facebook</h4>
                        <i class="ti ti-brand-facebook"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('faqs')); ?>" class="pages">
                        <h4>Câu hỏi thường gặp</h4>
                        <i class="ti ti-info-circle"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('terms')); ?>" class="pages">
                        <h4>Điều khoản sử dụng</h4>
                        <i class="ti ti-book"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('logout')); ?>" class="pages">
                        <h4>Đăng xuất</h4>
                        <i class="ti ti-arrow-right"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\localhost\dealhot.com\resources\views/user/widget/sidebar.blade.php ENDPATH**/ ?>