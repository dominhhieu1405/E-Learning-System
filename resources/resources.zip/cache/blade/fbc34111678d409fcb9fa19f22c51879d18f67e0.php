
<?php $__env->startSection('title', 'Câu hỏi thường gặp'); ?>

<?php $__env->startSection('content'); ?>
    <div class="help-center">
        <h2>Câu hỏi thường gặp</h2>
        <p>Dưới đây là câu trả câu trả lời cho những câu hỏi thường gặp</p>

        <h3>Về OnThi.io.vn.com</h3>
        <div class="accordion accordion-flush help-accordion" id="faq1">

            <div class="accordion-item">
                <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1_1" aria-expanded="false">LụmDeals.com là gì</button>
                </h3>
                <div id="faq1_1" class="accordion-collapse collapse" data-bs-parent="#faq1" style="">
                    <div class="accordion-body">
                        OnThi.io.vn.com là một website uy tín chuyên tổng hợp các deals giảm giá trên Shopee, Ngoài ra bạn có thể được hoàn tiền trên mỗi đơn hàng khi tham gia OnThi.io.vn.com
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1_2" aria-expanded="false">Lợi ích khi sử dụng OnThi.io.vn.com</button>
                </h3>
                <div id="faq1_2" class="accordion-collapse collapse" data-bs-parent="#faq1" style="">
                    <div class="accordion-body">
                        Khi thực hiện mua sắm qua OnThi.io.vn.com, bạn sẽ được:
                        <ul>
                            <li>Tất cả các mã giảm giá có thể áp dụng trên đơn hàng đó</li>
                            <li>Hoàn tiền lên đến 50% giá trị mọi đơn hàng</li>
                            <li>Nhận sớm voucher độc quyền vào các ngày sự kiện lớn: Sale ngày đôi, giữa tháng hoặc cuối tháng</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1_3" aria-expanded="false">Cài đặt app OnThi.io.vn.com</button>
                </h3>
                <div id="faq1_3" class="accordion-collapse collapse" data-bs-parent="#faq1" style="">
                    <div class="accordion-body">
                        Hiện tại OnThi.io.vn.com chưa có app chính thức. Tuy nhiên, bạn có thể cài đặt trang này vào màn hình chính và sử dụng tương tự như app trên cả hệ điều hành IOS và Android
                    </div>
                </div>
            </div>
        </div>

        <h3>Tài khoản OnThi.io.vn.com</h3>
        <div class="accordion accordion-flush help-accordion" id="faq2"></div>

        <h3>Mua sắm hoàn tiền</h3>
        <div class="accordion accordion-flush help-accordion" id="faq3"></div>

        <h3>Đổi thưởng</h3>
        <div class="accordion accordion-flush help-accordion" id="faq4"></div>

        <h3>Khác</h3>
        <div class="accordion accordion-flush help-accordion" id="faq5"></div>
        <!-- .page-content-wrapper end -->

        <!-- swiper js -->
        <script src="assets/js/swiper-bundle.min.js"></script>
        <script src="assets/js/custom-swiper.js"></script>

        <!-- range-slider js -->
        <script src="assets/js/range-slider.js"></script>

        <!-- iconsax js -->
        <!--<script src="assets/js/iconsax.js"></script>-->

        <!-- bootstrap js -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>

        <!-- script js -->
        <script src="assets/js/script.js"></script>




    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/faqs.blade.php ENDPATH**/ ?>