<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0">Quản lý Đề thi</h4>
                    <a href="<?php echo e(path_url('admin.exam.add')); ?>" class="btn btn-primary">
                        <i class="ri-add-line"></i> Tạo đề mới
                    </a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="50">#</th>
                                        <th>Tên đề thi</th>
                                        <th width="100">Loại</th>
                                        <th width="100">Hình thức</th>
                                        <th width="80">Trạng thái</th>
                                        <th width="150">Ngày tạo</th>
                                        <th width="180">Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($exams && count($exams) > 0): ?>
                                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($exam->id); ?></td>
                                            <td>
                                                <a href="<?php echo e(path_url('admin.exam.edit', ['id' => $exam->id])); ?>">
                                                    <?php echo e($exam->title); ?>

                                                </a>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php echo e($exam->exam_type === 'thpt' ? 'primary' : 'success'); ?>">
                                                    <?php echo e(strtoupper($exam->exam_type)); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <?php if($exam->is_random): ?>
                                                    <span class="badge bg-warning">Ngẫu nhiên</span>
                                                <?php else: ?>
                                                    <span class="badge bg-info">Cố định</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($exam->status): ?>
                                                    <span class="badge bg-success">Hiển thị</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Ẩn</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($exam->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(path_url('admin.exam.questions', ['id' => $exam->id])); ?>" class="btn btn-sm btn-info">
                                                    <i class="ri-list-check"></i> Câu hỏi
                                                </a>
                                                <a href="<?php echo e(path_url('admin.exam.edit', ['id' => $exam->id])); ?>" class="btn btn-sm btn-warning">
                                                    <i class="ri-edit-line"></i>
                                                </a>
                                                <button class="btn btn-sm btn-danger btn-delete" data-id="<?php echo e($exam->id); ?>">
                                                    <i class="ri-delete-bin-line"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr><td colspan="7" class="text-center text-muted">Chưa có đề thi nào</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript_plugins'); ?>
<script>
$(function(){
    $('.btn-delete').on('click', function(){
        if(!confirm('Xóa đề thi này? Tất cả câu hỏi sẽ bị xóa theo!')) return;
        var id = $(this).data('id');
        $.post('/ajax/admin/exam/delete', {id: id}, function(res){
            if(res.status){
                toastr.success(res.message);
                setTimeout(()=> location.reload(), 800);
            } else {
                toastr.error(res.message);
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/exams.blade.php ENDPATH**/ ?>