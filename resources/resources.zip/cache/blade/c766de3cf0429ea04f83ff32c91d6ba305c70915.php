

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Bảng điều khiển</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Bảng điều khiển</li>
                            </ol>
                        </div>


                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-lg-4 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Số khóa học</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["course"])); ?></h4>
                                </div>
                                <div class="text-primary">
                                    <i class="mdi mdi-bag-personal-outline mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="#" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Số bài học</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["lesson"])); ?></h4>
                                </div>
                                <div class="text-primary">
                                    <i class="mdi mdi-book-open-outline mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="#" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Số tài liệu</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["document"])); ?></h4>
                                </div>
                                <div class="text-primary">
                                    <i class="mdi mdi-file-document-outline mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="#" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>

                
                <div class="col-lg-4 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Số đề thi</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["exams"])); ?></h4>
                                </div>
                                <div class="text-warning">
                                    <i class="mdi mdi-clipboard-list-outline mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="<?php echo e(url('admin.exams')); ?>" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Ngân hàng câu hỏi</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["questions"])); ?></h4>
                                </div>
                                <div class="text-warning">
                                    <i class="mdi mdi-database mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="<?php echo e(url('admin.questions')); ?>" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Phiên thi</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["sessions"])); ?></h4>
                                </div>
                                <div class="text-warning">
                                    <i class="mdi mdi-history mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="<?php echo e(url('admin.sessions')); ?>" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Tổng lượt xem bài học</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["course_views"])); ?></h4>
                                </div>
                                <div class="text-primary">
                                    <i class="mdi mdi-eye-minus-outline mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="#" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Lượt xem bài học hôm nay</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["course_views_day"])); ?></h4>
                                </div>
                                <div class="text-primary">
                                    <i class="mdi mdi-eye-plus-outline mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="#" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Tổng lượt xem tài liệu</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["document_views"])); ?></h4>
                                </div>
                                <div class="text-primary">
                                    <i class="mdi mdi-eye-check-outline mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="#" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="media">
                                <div class="media-body overflow-hidden">
                                    <p class="text-truncate font-size-14 mb-2">Tổng lượt xem bài học</p>
                                    <h4 class="mb-0"><?php echo e(number_format($count["document_views_day"])); ?></h4>
                                </div>
                                <div class="text-primary">
                                    <i class="mdi mdi-eye-outline mdi-36px"></i>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-top py-3 text-center align-items-center">
                            <a href="#" class="small-box-footer"> Xem thêm <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/dashboard.blade.php ENDPATH**/ ?>