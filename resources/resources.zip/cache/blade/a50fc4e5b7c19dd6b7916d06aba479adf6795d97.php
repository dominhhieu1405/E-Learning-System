
<?php $__env->startSection('content'); ?>
    <div class="card rounded-top border-shopee-dashed">
        <div class="card-body p-2">
            <p class="mb-0 text-dark">
                <i class="ti ti-circle-check text-success pe-1"></i>
                <span class="text-primary">Những điều bạn cần biết về OnThi.io.vn</span>
            </p>
        </div>
        <a class="btn btn-sm btn-shopee mt-0" href="<?php echo e(url("faqs")); ?>">Đọc Ngay</a>
    </div>

    <div class="card rounded-top mt-3">
        <div class="card-body p-2 wallet-card">
            <div class="balance">
                <div class="left">
                    <h6 class="title">Điểm đang có</h6>
                    <h2 class="total"><span id="js-rp-available"><?php echo e(number_format(userget()->point)); ?></span> DP</h2>
                </div>
                <div class="right">
                    <h6 class="title">Điểm đang chờ</h6>
                    <h2 class="total"><span id="js-rp-total"><?php echo e(number_format(userget()->point + userget()->point_pending)); ?></span> DP</h2>
                </div>
            </div>
            <div class="wallet-footer mt-2">
                <div class="item">
                    <a href="<?php echo e(url('shopping')); ?>">
                        <div class="icon-wrapper bg-warning">
                            <i class="ti ti-arrow-down"></i>
                        </div>
                        <h6 class="mb-0">Nhận tích điểm</h6>
                    </a>
                </div>
                <div class="item">
                    <a href="<?php echo e(url('orders')); ?>">
                        <div class="icon-wrapper bg-warning">
                            <i class="ti ti-shopping-cart"></i>
                        </div>
                        <h6 class="mb-0">Mua sắm hoàn tiền</h6>
                    </a>
                </div>
                <div class="item">
                    <a href="<?php echo e(url("withdraw")); ?>">
                        <div class="icon-wrapper bg-success">
                            <i class="ti ti-cash-banknote"></i>
                        </div>
                        <h6 class="mb-0">Rút tiền</h6>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="card rounded border-shopee mt-3">
        <div class="card-body p-2">
            <div class="d-flex align-items-center mb-3">
                <h6 class="fw-bold mb-0 c-shopee">Mua sắm hoàn tiền đến 50%</h6>
            </div>
            <div class="search-form justify-content-between">
                <form id="form-main-search-deal" action="<?php echo e(url('shopping')); ?>">
                    <input type="text" id="in_main_keyword" name="keyword" class="form-control bg-light" placeholder="Gửi link hoặc tên sản phẩm" autocomplete="off" aria-label="">
                    <button type="submit"><i class="ti ti-link"></i></button>
                </form>
                <button name="submit" class="btn btn-danger m-0" id="main_search_deal" style="height: 40px;background: #EE4D2D;"><i class="ti ti-chevron-right"></i></button>
            </div>
            <div class="d-flex mt-2 d-none" id="js-main-search-deal" style="white-space: nowrap;">
                <a class="btn btn-danger mt-1 w-100 me-1 px-1 bg-shopee" id="js-main-search-deal-go">Mua Ngay</a>
                <a class="btn btn-light mt-1 me-1 px-1" id="js-main-search-deal-rp"><i class="ti ti-viewfinder"></i> Check hoàn tiền</a>
                <div class="btn btn-light mt-1 px-1" id="js-main-search-deal-link"><i class="ti ti-share"></i> Chia sẻ</div>
            </div>
            <div class="d-flex align-items-center justify-content-between mt-2 p-1 lh-1" style="background: #ffb4a3;border-radius: 3px;font-size: 12px;">
                <div class="d-flex me-1">
                    <div class="icon pe-1"><i class="ti ti-time-duration-15"></i></div><span>Ghi nhận 36 giờ</span>
                </div>
                <div class="d-flex me-1">
                    <div class="icon pe-1"><i class="ti ti-calendar"></i></div><span>Hoàn tiền trong 14 ngày</span>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-6 pe-0">
            <a href="#">
                <div class="card">
                    <div class="card-body p-2">
                        <div class="row">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-circle">
                                    <div class="icons bg-success text-white rounded-circle">
                                        <i class="ti ti-arrow-down"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <h6 class="small mb-1">DP đã đổi</h6>
                                <h6 class="fs-6 lh-1 mb-0 fw-bold"><span id="js-rp-today"><?php echo e(number_format(userget()->point_used)); ?></span> DP</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="user_point_pedding col-6">
            <a href="#">
                <div class="card">
                    <div class="card-body p-2">
                        <div class="row">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-circle">
                                    <div class="icons bg-warning text-white rounded-circle">
                                        <i class="ti ti-history"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <h6 class="small mb-1">DP chờ</h6>
                                <h6 class="fs-6 lh-1 mb-0 fw-bold"><span id="js-rp-pending"><?php echo e(number_format(userget()->point_pending)); ?></span> DP</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="card rounded mt-3 d-none">
        <div class="card-header bg-shopee">
            <h6 class="text-white">⚡ Lụm LIVE</h6>
        </div>
        <div class="card-body p-2">

            <div id="rio-live-action" class="bc-webkit bg-white" style="max-height: 325px;overflow: auto;">
                <div class="d-live-show">
                    <div class="d-flex align-items-center p-1 border-bottom bg-white">
                        <div class="d-live-img">
                            <div class="me-2 position-relative">
                                <img onerror="this.src='./assets/img/avatar/error.png'" class="rounded-circle" src="" alt="User 1">
                            </div>
                        </div>
                        <div class="position-relative d-live-text">
                            <h6 class="mb-0">User 1 - <span>vừa thao tác <b>Mua sắm</b></span>
                            </h6>
                            <div><i class="ti ti-clock me-1"></i>07:05:41</div>
                        </div>
                    </div>
                </div>

                <div class="rio-live-show">
                    <div class="d-flex align-items-center p-1 border-bottom bg-white">
                        <div class="d-live-img">
                            <div class="me-2 position-relative">
                                <img onerror="this.src='./assets/img/avatar/error.png'" class="rounded-circle" src="" alt="User 2">
                            </div>
                        </div>
                        <div class="position-relative d-live-text">
                            <h6 class="mb-0">User 2 - Vừa
                                <span><b><a href="#">Checkin</a></b> được <b>+113 DP</b></span>
                            </h6>
                            <div><i class="ti ti-clock me-1"></i>07:05:41</div>
                        </div>
                    </div>


                </div>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
    <script type="text/javascript">
        $(function() {
            $('#main_search_deal').click(function() {
                var keyword = $('#in_main_keyword').val().trim();
                if (keyword === '') {
                    alert('Vui lòng nhập link sản phẩm');
                    return false;
                }
                $('#form-main-search-deal').submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/home.blade.php ENDPATH**/ ?>