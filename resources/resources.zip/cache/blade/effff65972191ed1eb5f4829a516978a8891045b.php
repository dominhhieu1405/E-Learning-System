
<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div class="card rounded border-0 mt-1">
        <div class="card-body profile-header">
            <div class="d-flex align-items-center gap-2 mt-2">
                <div class="profile-pic m-0">
                    <img class="img-fluid img" src="<?php echo e(userget()->avatar_url); ?>" alt="profile">
                </div>
                <div class="profile-name d-flex align-items-center justify-content-between w-100">
                    <h4 class="theme-color">
                        <span class="badge bg-primary">VIP</span> <?php echo e(userget()->name); ?>

                        <br>
                        <small class="time-join">Tham gia từ <?php echo e(date('d/m/Y', strtotime(userget()->time_join))); ?></small>
                    </h4>
                    <span class="c-shopee p-1 fw-bold"><?php echo e(number_format(userget()->point)); ?> DP</span>
                </div>
            </div>
        </div>
    </div>

    <div class="card rounded border-0 mt-1">
        <div class="card-body" style="min-height: 200px">

            <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <i class="ti ti-at"></i> <span>Tên tài khoản</span>
                </div>
                <div class="data-content">
                    <?php echo e(userget()->username); ?>

                </div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <i class="ti ti-user"></i> <span>Họ và tên</span>
                </div>
                <div class="data-content">
                    <?php echo e(userget()->name); ?>

                </div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <i class="ti ti-coin"></i> <span>Điểm thưởng</span>
                </div>
                <div class="data-content">
                    <?php echo e(number_format(userget()->point)); ?> DP
                </div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <i class="ti ti-phone"></i> <span>Số điện thoại</span>
                </div>
                <div class="data-content">
                    <?php echo e(userget()->phone ?? 'Chưa cập nhật'); ?>

                </div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <i class="ti ti-brand-facebook"></i> <span>Facebook</span>
                </div>
                <div class="data-content">
                    <?php echo e(userget()->facebook ?? 'Chưa cập nhật'); ?>

                </div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <i class="ti ti-mail"></i> <span>Email</span>
                </div>
                <div class="data-content">
                    <?php echo e(userget()->email ?? 'Chưa cập nhật'); ?>

                </div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <i class="ti ti-calendar"></i> <span>Ngày sinh</span>
                </div>
                <div class="data-content">
                    <?php echo e(date('d/m/Y', strtotime(userget()->birthday))); ?>

                </div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <i class="ti ti-map-pin-filled"></i> <span>Tỉnh thành</span>
                </div>
                <div class="data-content">
                    <?php echo e(\Models\User::provinceName(userget()->province)); ?>

                </div>
            </div>
            <a class="btn btn-info w-100" type="button" href="<?php echo e(url('profile.info.edit')); ?>">Thay đổi thông tin</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/profile-info.blade.php ENDPATH**/ ?>