<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Quản lý ngôn ngữ</h4>
                        <button class="btn btn-primary" id="btnAdd">Thêm ngôn ngữ</button>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ID</th>
                                            <th>Tên ngôn ngữ</th>
                                            <th>Mã ngôn ngữ</th>
                                            <th>Trạng thái</th>
                                            <th>Hành động</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>#<?php echo e($lang['id']); ?></td>
                                                <td><?php echo e($lang['name']); ?></td>
                                                <td><code><?php echo e($lang['code']); ?></code></td>
                                                <td>
                                                    <?php if($lang['status'] == 1): ?> <span
                                                        class="badge bg-soft-success text-success">Hiện</span>
                                                    <?php else: ?> <span class="badge bg-soft-danger text-danger">Ẩn</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="/admin/language/<?php echo e($lang['code']); ?>"
                                                        class="btn btn-sm btn-soft-info">Dịch</a>
                                                    <button class="btn btn-sm btn-soft-primary btnEdit"
                                                        data-lang='<?php echo json_encode($lang, 15, 512) ?>'>Sửa</button>
                                                    <button class="btn btn-sm btn-soft-danger btnDelete"
                                                        data-id="<?php echo e($lang['id']); ?>">Xóa</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Ngôn ngữ -->
    <div class="modal fade" id="modalLang" tabindex="-1">
        <div class="modal-dialog">
            <form class="modal-content" id="formLang">
                <div class="modal-header">
                    <h5 class="modal-title">Ngôn ngữ</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="langId">
                    <div class="mb-3">
                        <label class="form-label">Tên ngôn ngữ</label>
                        <input type="text" name="name" id="langName" class="form-control" placeholder="Ví dụ: Tiếng Việt"
                            required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Mã ngôn ngữ</label>
                        <input type="text" name="code" id="langCode" class="form-control" placeholder="Ví dụ: vi" required>
                        <small class="text-muted">Mã này phải trùng với tên thư mục trong
                            <code>/resources/lang/</code></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Trạng thái</label>
                        <select name="status" id="langStatus" class="form-control custom-select">
                            <option value="1">Hiện</option>
                            <option value="0">Ẩn</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    <button type="submit" class="btn btn-primary">Lưu lại</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
    <script>
        $(function () {
            const modal = new bootstrap.Modal('#modalLang');
            let isEdit = false;

            $('#btnAdd').on('click', function () {
                isEdit = false;
                $('#formLang')[0].reset();
                $('#langId').val('');
                $('.modal-title').text('Thêm ngôn ngữ mới');
                modal.show();
            });

            $('.btnEdit').on('click', function () {
                isEdit = true;
                const lang = $(this).data('lang');
                $('#langId').val(lang.id);
                $('#langName').val(lang.name);
                $('#langCode').val(lang.code);
                $('#langStatus').val(lang.status);
                $('.modal-title').text('Sửa ngôn ngữ');
                modal.show();
            });

            $('#formLang').on('submit', function (e) {
                e.preventDefault();
                const id = $('#langId').val();
                const url = isEdit ? '/ajax/admin/language/edit/' + id : '/ajax/admin/language/add';

                $.ajax({
                    url: url,
                    method: 'POST',
                    data: $(this).serialize(),
                    success: function (res) {
                        res.status ? (toastr.success(res.message), setTimeout(() => location.reload(), 800)) : toastr.error(res.message);
                    }
                });
            });

            $('.btnDelete').on('click', function () {
                const id = $(this).data('id');
                if (!confirm('Xác nhận xóa ngôn ngữ này? Thư mục ngôn ngữ trong tài nguyên sẽ KHÔNG bị xóa.')) return;
                $.ajax({
                    url: '/ajax/admin/language/delete',
                    method: 'POST',
                    data: { id },
                    success: function (res) {
                        res.status ? location.reload() : toastr.error(res.message);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/languages.blade.php ENDPATH**/ ?>