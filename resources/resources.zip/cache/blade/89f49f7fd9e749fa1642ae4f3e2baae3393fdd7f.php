<?php $__env->startSection('title', 'Trang cá nhân'); ?>
<?php $__env->startSection('content'); ?>

<div class="container py-5">
    <div class="row g-4">
        
        <div class="col-lg-4">
            <div class="ot-card p-4 text-center">
                <div class="mb-3 position-relative d-inline-block avatar-upload-container">
                    <img src="<?php echo e($user->avatar ?: 'https://ui-avatars.com/api/?name='.urlencode($user->display_name).'&background=6366f1&color=fff'); ?>" 
                         alt="Avatar" class="rounded-circle border" style="width:120px; height:120px; object-fit:cover;" id="profileAvatarPreview">
                    <label for="avatar_file" class="btn btn-sm btn-primary rounded-circle position-absolute bottom-0 end-0 p-2 shadow-sm" style="cursor:pointer;">
                        <i class="fas fa-camera"></i>
                    </label>
                    <input type="file" id="avatar_file" class="d-none" accept="image/*">
                </div>
                <h5 class="fw-bold mb-1" id="sidebarDisplayName"><?php echo e($user->display_name); ?></h5>
                <p class="text-muted small mb-4">@<span><?php echo e($user->username); ?></span></p>
                
                <div class="list-group list-group-flush text-start border-top pt-3">
                    <a href="#tab-info" class="list-group-item list-group-item-action border-0 active rounded-3 mb-1" data-bs-toggle="pill">
                        <i class="fas fa-user-edit me-2"></i> Thông tin cá nhân
                    </a>
                    <a href="#tab-history" class="list-group-item list-group-item-action border-0 rounded-3 mb-1" data-bs-toggle="pill">
                        <i class="fas fa-history me-2"></i> Lịch sử thi
                    </a>
                    <a href="#tab-password" class="list-group-item list-group-item-action border-0 rounded-3 mb-1" data-bs-toggle="pill">
                        <i class="fas fa-key me-2"></i> Đổi mật khẩu
                    </a>
                </div>
            </div>
        </div>

        
        <div class="col-lg-8">
            <div class="tab-content">
                
                <div class="tab-pane fade show active" id="tab-info">
                    <div class="ot-card p-4">
                        <h5 class="fw-bold mb-4">Cập nhật thông tin</h5>
                        <form id="formUpdateProfile">
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <label class="form-label small fw-bold">Tên tài khoản (Username)</label>
                                    <input type="text" class="form-control bg-light" value="<?php echo e($user->username); ?>" readonly disabled>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small fw-bold">Họ</label>
                                    <input type="text" name="last_name" class="form-control" value="<?php echo e($user->last_name); ?>" placeholder="Ví dụ: Nguyễn">
                                </div>
                                <div class="col-md-8">
                                    <label class="form-label small fw-bold">Tên đệm và Tên</label>
                                    <input type="text" name="middle_first_name" class="form-control" value="<?php echo e($user->middle_first_name); ?>" placeholder="Ví dụ: Văn A" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Email</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" placeholder="example@gmail.com">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Số điện thoại</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>" placeholder="09xxxx">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Ngày sinh</label>
                                    <input type="date" name="birthday" class="form-control" value="<?php echo e($user->birthday); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Giới tính</label>
                                    <select name="gender" class="form-select">
                                        <option value="0" <?php echo e($user->gender == 0 ? 'selected' : ''); ?>>Nam</option>
                                        <option value="1" <?php echo e($user->gender == 1 ? 'selected' : ''); ?>>Nữ</option>
                                        <option value="2" <?php echo e($user->gender == 2 ? 'selected' : ''); ?>>Khác</option>
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <label class="form-label small fw-bold">Khu vực (Tỉnh/Thành phố)</label>
                                    <select name="province_id" class="form-select">
                                        <option value="">-- Chọn Tỉnh/Thành phố --</option>
                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($id); ?>" <?php echo e($user->province_id == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-12 mt-4 text-end">
                                    <button type="submit" class="btn btn-ot-primary">
                                        <i class="fas fa-save me-1"></i> Lưu thay đổi
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                
                <div class="tab-pane fade" id="tab-history">
                    <div class="ot-card p-4">
                        <h5 class="fw-bold mb-4">Lịch sử làm bài</h5>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Đề thi</th>
                                        <th>Thời gian nộp</th>
                                        <th class="text-center">Điểm</th>
                                        <th class="text-center">Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?php echo e($s->exam_title); ?></div>
                                            <small class="text-muted"><?php echo e(strtoupper($s->exam_type)); ?></small>
                                        </td>
                                        <td><?php echo e(date('H:i d/m/Y', strtotime($s->submitted_at))); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-success py-2 px-3 fs-6"><?php echo e($s->total_score); ?></span>
                                        </td>
                                        <td class="text-center">
                                            <a href="/exam/result/<?php echo e($s->id); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                                Xem chi tiết
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-4 text-muted">
                                            Bạn chưa thực hiện bài thi nào.
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                
                <div class="tab-pane fade" id="tab-password">
                    <div class="ot-card p-4">
                        <h5 class="fw-bold mb-4">Đổi mật khẩu</h5>
                        <form id="formChangePassword">
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Mật khẩu hiện tại</label>
                                <input type="password" name="old_password" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Mật khẩu mới</label>
                                <input type="password" name="new_password" class="form-control" required>
                            </div>
                            <div class="mb-4">
                                <label class="form-label small fw-bold">Xác nhận mật khẩu mới</label>
                                <input type="password" name="confirm_password" class="form-control" required>
                            </div>
                            <div class="text-end">
                                <button type="submit" class="btn btn-ot-primary">
                                    <i class="fas fa-lock me-1"></i> Đổi mật khẩu
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    // Cập nhật thông tin
    $('#formUpdateProfile').on('submit', function(e) {
        e.preventDefault();
        const data = $(this).serialize();
        $.post('/api/user/update-profile', data, function(res) {
            if (res.status) {
                toastr.success(res.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                toastr.error(res.message);
            }
        }, 'json');
    });

    // Upload Avatar
    $('#avatar_file').on('change', function() {
        const file = this.files[0];
        if (file) {
            const formData = new FormData();
            formData.append('avatar_file', file);
            
            $.ajax({
                url: '/api/user/upload-avatar',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    if (res.status) {
                        $('#profileAvatarPreview').attr('src', res.url);
                        toastr.success('Cập nhật ảnh đại diện thành công!');
                    } else {
                        toastr.error(res.message);
                    }
                }
            });
        }
    });

    // Đổi mật khẩu
    $('#formChangePassword').on('submit', function(e) {
        e.preventDefault();
        const data = $(this).serialize();
        $.post('/api/user/change-password', data, function(res) {
            if (res.status) {
                toastr.success(res.message);
                $('#formChangePassword')[0].reset();
            } else {
                toastr.error(res.message);
            }
        }, 'json');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/profile.blade.php ENDPATH**/ ?>