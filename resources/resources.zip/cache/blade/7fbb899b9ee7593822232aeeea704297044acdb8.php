<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="mb-0">Bình luận mới nhất</h4>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-centered mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Thời gian</th>
                                        <th>Thành viên</th>
                                        <th>Nội dung</th>
                                        <th>Chuyên mục</th>
                                        <th>Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(timeago($c->created_at)); ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo e($c->avatar ?: '/assets/images/users/avatar-1.jpg'); ?>" class="avatar-xs rounded-circle me-2" alt="">
                                                <span><?php echo e($c->display_name); ?></span>
                                            </div>
                                        </td>
                                        <td style="max-width: 400px; white-space: normal;">
                                            <?php if($c->parent_id): ?> <small class="text-muted d-block">Trả lời #<?php echo e($c->parent_id); ?>:</small> <?php endif; ?>
                                            <?php echo e($c->content); ?>

                                        </td>
                                        <td>
                                            <span class="badge bg-soft-info text-info text-uppercase"><?php echo e($c->type); ?></span>
                                            <div class="small text-muted">ID: <?php echo e($c->target_id); ?></div>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url($c->type, ['id' => $c->target_id])); ?>" target="_blank" class="btn btn-sm btn-soft-primary">Xem</a>
                                            <button class="btn btn-sm btn-soft-danger btnDelete" data-id="<?php echo e($c->id); ?>">Xóa</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
<script>
$(function(){
    $('.btnDelete').on('click', function(){
        if(!confirm('Xóa bình luận này?')) return;
        // Implement delete API if needed, for now just UI
        toastr.info('Tính năng đang được cập nhật');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/comments.blade.php ENDPATH**/ ?>