<!-- panel-space start -->
<section class="panel-space"></section>
<!-- panel-space end -->

<!-- bottom navbar start -->
<div class="navbar-menu">
    <ul>
        <li class="<?php if($navbar != 'shopping' && $navbar != 'profile'): ?> active <?php endif; ?>">
            <a href="<?php echo e(url('home')); ?>">
                <div class="icon">
                    <img class="unactive" src="/assets/img/svg/home.svg" alt="Trang chủ"/>
                    <img class="active" src="/assets/img/svg/home-fill.svg" alt="Trang chủ"/>
                </div>
            </a>
        </li>
        <li class="<?php if($navbar == 'shopping'): ?> active <?php endif; ?>">
            <a href="<?php echo e(url('shopping')); ?>">
                <div class="icon">
                    <img class="unactive" src="/assets/img/svg/bag.svg" alt="Mua sắm"/>
                    <img class="active" src="/assets/img/svg/bag-fill.svg" alt="Mua sắm"/>
                </div>
            </a>
        </li>
        <li class="<?php if($navbar == 'profile'): ?> active <?php endif; ?>">
            <a href="<?php echo e(url('profile')); ?>">
                <div class="icon">
                    <img class="unactive" src="/assets/img/svg/profile.svg" alt="Tài khoản"/>
                    <img class="active" src="/assets/img/svg/profile-fill.svg" alt="Tài khoản"/>
                </div>
            </a>
        </li>
    </ul>
</div>
<!-- bottom navbar end --><?php /**PATH D:\localhost\dealhot.com\resources\views/user/widget/bottom-navbar.blade.php ENDPATH**/ ?>