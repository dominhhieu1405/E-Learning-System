<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="" name="description" />
    <meta content="" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="/assets/admin/images/favicon.ico">

    <?php echo $__env->yieldContent('css_plugins'); ?>
    <!-- Bootstrap Css -->
    <link href="/assets/admin/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="/assets/admin/libs/toastr/build/toastr.min.css"/>
    <!-- Icons Css -->
    <link href="/assets/admin/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="/assets/admin/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <link href="/assets/admin/css/custom-admin.css" rel="stylesheet" type="text/css" />

    <!-- jquery -->
    <script src="/assets/admin/libs/jquery/jquery.min.js"></script>
    <script>
        function errorImage(e) {
            e.onerror = "";
            e.src = "/assets/img/no-image.png";
            return true;
        }
    </script>
    <script>
        window.MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\(', '\\)']],
                displayMath: [['$$', '$$'], ['\\[', '\\]']],
                processEscapes: true
            }
        };
    </script>
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" async></script>
</head>

<body data-sidebar="dark">

<div id="layout-wrapper">

    <?php echo $__env->make('admin.components.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<!-- JAVASCRIPT -->
<script src="/assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/assets/admin/libs/metismenu/metisMenu.min.js"></script>
<script src="/assets/admin/libs/simplebar/simplebar.min.js"></script>
<script src="/assets/admin/libs/node-waves/waves.min.js"></script>
<!-- toastr plugin -->
<script src="/assets/admin/libs/toastr/build/toastr.min.js"></script>
<?php echo $__env->yieldContent('javascript_plugins'); ?>

<script src="/assets/admin/js/app.js"></script>
<script>
    $(function () {

    })
</script>

</body>
</html>
<?php /**PATH D:\localhost\DGNL\resources\views/admin/layout.blade.php ENDPATH**/ ?>