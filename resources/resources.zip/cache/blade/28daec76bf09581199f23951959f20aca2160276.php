<?php $__env->startSection('title', 'Kết quả - ' . $exam->title); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/assets/css/exam.css?v=3">
<style>
.score-card {
    background: linear-gradient(135deg, #1e1b4b, #312e81);
    color: #fff;
    border-radius: var(--ot-radius);
    padding: 2rem;
    text-align: center;
    margin-bottom: 2rem;
}
.score-card .score-main { font-size: 3rem; font-weight: 800; }
.score-card .score-parts { display: flex; justify-content: center; gap: 2rem; margin-top: 1rem; }
.score-card .score-part { text-align: center; }
.score-card .score-part .label { font-size: 0.8rem; opacity: 0.7; }
.score-card .score-part .value { font-size: 1.3rem; font-weight: 700; }

.review-question { margin-bottom: 1.5rem; padding: 1.25rem; border-radius: var(--ot-radius); background: var(--ot-bg-card); border: 1px solid var(--ot-border); }
.review-question .q-header { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.75rem; }
.review-question .q-header .q-num { font-weight: 700; color: var(--ot-primary); }
.review-question .q-header .q-result { font-size: 0.8rem; padding: 2px 8px; border-radius: 4px; }
.review-question .q-header .q-result.correct { background: rgba(16,185,129,0.15); color: var(--ot-success); }
.review-question .q-header .q-result.wrong { background: rgba(239,68,68,0.15); color: var(--ot-danger); }
.review-question .q-header .q-result.unanswered { background: rgba(100,116,139,0.15); color: var(--ot-text-muted); }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            
            <div class="score-card">
                <div class="mb-2"><i class="fas fa-trophy fa-2x" style="color:#f59e0b;"></i></div>
                <h5>Kết quả thi: <?php echo e($exam->title); ?></h5>
                <div class="score-main"><?php echo e($session->total_score); ?></div>
                <div class="score-parts">
                    <div class="score-part">
                        <div class="label">Phần 1</div>
                        <div class="value"><?php echo e($session->score_p1); ?></div>
                    </div>
                    <div class="score-part">
                        <div class="label">Phần 2</div>
                        <div class="value"><?php echo e($session->score_p2); ?></div>
                    </div>
                    <div class="score-part">
                        <div class="label">Phần 3</div>
                        <div class="value"><?php echo e($session->score_p3); ?></div>
                    </div>
                </div>
                <div class="mt-2" style="font-size:0.85rem;opacity:0.7;">
                    Thời gian: <?php echo e(gmdate('H:i:s', $session->time_spent ?: 0)); ?>

                </div>
            </div>

            <div class="d-flex gap-2 mb-4">
                <a href="/exams" class="btn btn-ot-outline"><i class="fas fa-arrow-left"></i> Về danh sách</a>
                <a href="/leaderboard/<?php echo e($exam->id); ?>" class="btn btn-ot-primary"><i class="fas fa-trophy"></i> Bảng xếp hạng</a>
            </div>

            
            <h5 class="fw-bold mb-3">Xem lại bài làm</h5>
            
            <?php if(!$exam->show_answers): ?>
                <div class="alert alert-info border-0 shadow-sm p-4">
                    <div class="d-flex align-items-center gap-3">
                        <i class="fas fa-lock fa-2x text-primary"></i>
                        <div>
                            <h6 class="fw-bold mb-1">Đáp án và lời giải đã được ẩn</h6>
                            <p class="mb-0 small text-muted">Admin đã cấu hình ẩn chi tiết câu hỏi cho đề thi này. Bạn chỉ có thể xem điểm số tổng quát.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $qId = (string)$q->id;
                $userAnswer = $answers[$qId] ?? null;
                $isCorrect = false;
                if($q->question_type === 'mc') {
                    $isCorrect = $userAnswer && strtoupper(trim($userAnswer)) === strtoupper(trim($q->correct_answer));
                } elseif($q->question_type === 'short') {
                    $isCorrect = $userAnswer && trim(mb_strtolower($userAnswer)) === trim(mb_strtolower($q->correct_answer));
                }
            ?>
            <div class="review-question">
                <div class="q-header">
                    <span class="q-num">Câu <?php echo e($i+1); ?></span>
                    <?php if($q->question_type === 'mc' || $q->question_type === 'short'): ?>
                        <?php if($userAnswer === null): ?>
                            <span class="q-result unanswered">Chưa trả lời</span>
                        <?php elseif($isCorrect): ?>
                            <span class="q-result correct"><i class="fas fa-check"></i> Đúng</span>
                        <?php else: ?>
                            <span class="q-result wrong"><i class="fas fa-times"></i> Sai</span>
                        <?php endif; ?>
                    <?php elseif($q->question_type === 'tf'): ?>
                        <span class="badge bg-warning text-dark">Đúng/Sai</span>
                    <?php endif; ?>
                </div>
                <div class="mb-2"><?php echo $q->content; ?></div>

                <?php if($q->question_type === 'mc'): ?>
                    <?php $opts = is_string($q->options) ? json_decode($q->options, true) : ($q->options ?? []) ?>
                    <?php $__currentLoopData = ['A','B','C','D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li => $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($opts[$li])): ?>
                        <div class="option-item <?php echo e($userAnswer === $letter ? 'selected' : ''); ?> <?php echo e($q->correct_answer === $letter ? 'correct' : ''); ?> <?php echo e(($userAnswer === $letter && $q->correct_answer !== $letter) ? 'incorrect' : ''); ?>" style="cursor:default">
                            <span class="option-label"><?php echo e($letter); ?>.</span>
                            <span class="option-text"><?php echo e($opts[$li]); ?></span>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($q->question_type === 'tf'): ?>
                    <?php $tfItems_q = $tfItems[$q->id] ?? []; $tfAnswer = $userAnswer ?? []; ?>
                    <table class="tf-table" style="width:100%;">
                        <thead><tr><th></th><th>Bạn chọn</th><th>Đáp án</th></tr></thead>
                        <tbody>
                        <?php $__currentLoopData = $tfItems_q; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $k = (string)$item->order;
                                $userVal = isset($tfAnswer[$k]) ? ($tfAnswer[$k] ? 'Đ' : 'S') : '—';
                                $correctVal = $item->is_correct ? 'Đ' : 'S';
                                $match = isset($tfAnswer[$k]) && ((bool)$tfAnswer[$k] === (bool)$item->is_correct);
                            ?>
                            <tr>
                                <td><?php echo e(chr(96+$item->order)); ?>) <?php echo e($item->content); ?></td>
                                <td class="text-center"><span class="<?php echo e($match ? 'text-success' : 'text-danger'); ?> fw-bold"><?php echo e($userVal); ?></span></td>
                                <td class="text-center fw-bold"><?php echo e($correctVal); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php elseif($q->question_type === 'short'): ?>
                    <div class="d-flex gap-3 align-items-center flex-wrap mt-2">
                        <div>Bạn: <strong class="<?php echo e($isCorrect ? 'text-success' : 'text-danger'); ?>"><?php echo e($userAnswer ?: '(trống)'); ?></strong></div>
                        <div>Đáp án: <strong class="text-success"><?php echo e($q->correct_answer); ?></strong></div>
                    </div>
                <?php endif; ?>

                <?php if($q->explanation): ?>
                <div class="mt-2 p-2 bg-light rounded" style="font-size:0.875rem;">
                    <strong><i class="fas fa-lightbulb text-warning"></i> Giải thích:</strong> <?php echo $q->explanation; ?>

                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
<script>
    $(document).ready(function() {
        if(window.MathJax && window.MathJax.typesetPromise) {
            window.MathJax.typesetPromise();
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/result.blade.php ENDPATH**/ ?>