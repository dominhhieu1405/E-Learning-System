<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0"><i class="ri-robot-line me-2 text-primary"></i>Import Đề Thi Bằng AI</h4>
                    <a href="/admin/exams" class="btn btn-sm btn-outline-secondary">
                        <i class="ri-arrow-left-line"></i> Quay lại danh sách đề
                    </a>
                </div>
            </div>
        </div>

        <?php $hasKey = !empty($aiConfig['ai_key']); ?>

        <?php if(!$hasKey): ?>
        <div class="alert alert-warning d-flex align-items-center gap-2">
            <i class="ri-alert-line fs-4"></i>
            <div>
                <strong>Chưa cấu hình AI.</strong>
                Vào <a href="/admin/settings">Cài đặt → Cấu hình AI</a> để nhập API Key trước khi sử dụng tính năng này.
            </div>
        </div>
        <?php endif; ?>

        <div class="row">
            <!-- Form -->
            <div class="col-lg-5">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-4">
                            <i class="ri-upload-cloud-2-line me-1"></i> Tải lên file đề thi
                        </h5>

                        <form id="formAiImport" enctype="multipart/form-data">

                            
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Loại đề thi <span class="text-danger">*</span></label>
                                <select name="exam_type" id="examType" class="form-control custom-select">
                                    <option value="thpt">THPT Quốc gia 2025</option>
                                    <option value="hsa">HSA - Đánh giá năng lực (ĐHQG)</option>
                                    <option value="tsa">TSA - Tư duy (ĐHBK)</option>
                                </select>
                                <div class="form-text text-muted mt-1">
                                    <span id="examTypeHint">
                                        Gồm: Phần 1 (MC trắc nghiệm), Phần 2 (Đúng/Sai 4 ý), Phần 3 (Trả lời ngắn)
                                    </span>
                                </div>
                            </div>

                            
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Gắn vào đề thi</label>
                                <select name="exam_id" class="form-control custom-select">
                                    <option value="">— Tạo đề thi mới tự động —</option>
                                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($exam->id); ?>">
                                        [<?php echo e(strtoupper($exam->exam_type)); ?>] <?php echo e($exam->title); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="form-text text-muted">Để trống = AI tự tạo đề mới với tên trích từ file PDF.</div>
                            </div>

                            
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Môn học (tuỳ chọn)</label>
                                <select name="subject_id" class="form-control custom-select">
                                    <option value="">-- Không gắn môn --</option>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                            <div class="mb-4">
                                <label class="form-label fw-semibold">File PDF đề thi <span class="text-danger">*</span></label>
                                <div id="dropZone" class="border-2 border-dashed rounded-3 p-4 text-center"
                                    style="border: 2px dashed #6c757d; cursor: pointer; transition: all .2s;"
                                    onclick="document.getElementById('pdfFile').click()">
                                    <i class="ri-file-pdf-line fs-1 text-danger"></i>
                                    <p class="mb-1 mt-2 fw-semibold" id="dropText">Kéo thả hoặc click để chọn file PDF</p>
                                    <p class="text-muted small mb-0">Tối đa 30MB</p>
                                </div>
                                <input type="file" name="pdf_file" id="pdfFile" accept=".pdf" class="d-none">
                            </div>

                            
                            <button type="submit" class="btn btn-primary w-100 btn-lg" id="btnSubmit" <?php echo e(!$hasKey ? 'disabled' : ''); ?>>
                                <i class="ri-robot-line me-1"></i> Phân tích bằng AI
                            </button>
                        </form>

                        
                        <div class="mt-3 text-center">
                            <span class="badge bg-light text-dark border">
                                <i class="ri-cpu-line me-1"></i>
                                Provider: <strong><?php echo e(strtoupper($aiConfig['ai_provider'] ?? 'gemini')); ?></strong>
                                &nbsp;|&nbsp; Model: <strong><?php echo e($aiConfig['ai_model'] ?? 'gemini-1.5-pro'); ?></strong>
                            </span>
                            <a href="/admin/settings" class="ms-2 small text-muted">Thay đổi →</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Result -->
            <div class="col-lg-7">

                
                <div id="loadingCard" class="card d-none">
                    <div class="card-body text-center py-5">
                        <div class="spinner-border text-primary mb-3" style="width:3rem;height:3rem;" role="status"></div>
                        <h5 class="mb-1">Đang xử lý...</h5>
                        <p class="text-muted mb-0">AI đang phân tích file PDF. Vui lòng không đóng tab này.</p>
                        <div class="progress mt-3" style="height:6px;">
                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary w-100"></div>
                        </div>
                    </div>
                </div>

                
                <div id="resultCard" class="card d-none">
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-4">
                            <div class="avatar-sm bg-success-subtle rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                <i class="ri-check-line fs-4 text-success"></i>
                            </div>
                            <div>
                                <h5 class="mb-0" id="resultTitle">Import thành công!</h5>
                                <p class="text-muted mb-0" id="resultSubtitle"></p>
                            </div>
                        </div>

                        <div class="row g-3 mb-4">
                            <div class="col-6">
                                <div class="p-3 rounded-3 text-center" style="background:#f0fdf4;">
                                    <div class="fs-2 fw-bold text-success" id="importedCount">0</div>
                                    <div class="small text-muted">Câu hỏi đã import</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="p-3 rounded-3 text-center" style="background:#fff7ed;">
                                    <div class="fs-2 fw-bold text-warning" id="imageCount">0</div>
                                    <div class="small text-muted">Câu cần thêm ảnh</div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex gap-2 mb-4">
                            <a href="#" id="btnViewExam" class="btn btn-primary flex-grow-1" target="_blank">
                                <i class="ri-file-list-3-line me-1"></i> Xem & kiểm tra câu hỏi
                            </a>
                            <a href="#" id="btnEditExam" class="btn btn-outline-secondary" target="_blank">
                                <i class="ri-edit-line me-1"></i> Chỉnh sửa đề
                            </a>
                        </div>

                        
                        <div id="imageNotesSection" class="d-none">
                            <div class="alert alert-warning mb-0">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="ri-image-line me-2 fs-5"></i>
                                    <strong>Câu hỏi cần thêm ảnh thủ công:</strong>
                                </div>
                                <ul class="mb-0 ps-3" id="imageNotesList"></ul>
                            </div>
                        </div>

                        
                        <div id="warningsSection" class="d-none mt-3">
                            <div class="alert alert-soft-secondary mb-0">
                                <strong><i class="ri-error-warning-line me-1"></i>Cảnh báo từ AI:</strong>
                                <ul class="mb-0 ps-3 mt-1" id="warningsList"></ul>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div id="errorCard" class="card d-none border-danger">
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div class="avatar-sm bg-danger-subtle rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                                <i class="ri-close-line fs-4 text-danger"></i>
                            </div>
                            <div>
                                <h5 class="mb-0 text-danger">Xử lý thất bại</h5>
                                <p class="text-muted mb-0">AI không thể phân tích file này</p>
                            </div>
                        </div>
                        <div class="alert alert-danger mb-0">
                            <i class="ri-error-warning-line me-1"></i>
                            <span id="errorMessage"></span>
                        </div>
                    </div>
                </div>

                
                <div id="defaultCard" class="card border-0" style="background: linear-gradient(135deg,#667eea15,#764ba215);">
                    <div class="card-body py-5 text-center">
                        <i class="ri-robot-2-line" style="font-size:4rem;color:#667eea;opacity:.5;"></i>
                        <h5 class="mt-3 text-muted">Kết quả import sẽ hiển thị ở đây</h5>
                        <p class="text-muted small">
                            AI sẽ phân tích file PDF, trích xuất toàn bộ câu hỏi (mc, đúng/sai, trả lời ngắn),
                            hỗ trợ LaTeX và ghi chú vị trí ảnh.
                        </p>
                        <div class="row g-2 mt-3 justify-content-center">
                            <div class="col-auto"><span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-2"><i class="ri-check-line me-1"></i>Trắc nghiệm (mc)</span></div>
                            <div class="col-auto"><span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2"><i class="ri-check-line me-1"></i>Đúng/Sai (tf)</span></div>
                            <div class="col-auto"><span class="badge bg-warning-subtle text-warning border border-warning-subtle px-3 py-2"><i class="ri-check-line me-1"></i>Trả lời ngắn (short)</span></div>
                            <div class="col-auto"><span class="badge bg-info-subtle text-info border border-info-subtle px-3 py-2"><i class="ri-check-line me-1"></i>LaTeX</span></div>
                            <div class="col-auto"><span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-3 py-2"><i class="ri-check-line me-1"></i>Đoạn văn chung</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
<script>
$(function () {

    // Drag & drop zone
    var $dropZone = $('#dropZone');
    var $fileInput = $('#pdfFile');

    $dropZone.on('dragover', function (e) {
        e.preventDefault();
        $dropZone.css({ borderColor: '#667eea', background: '#667eea11' });
    }).on('dragleave', function () {
        $dropZone.css({ borderColor: '#6c757d', background: '' });
    }).on('drop', function (e) {
        e.preventDefault();
        $dropZone.css({ borderColor: '#6c757d', background: '' });
        var files = e.originalEvent.dataTransfer.files;
        if (files.length) {
            $fileInput[0].files = files;
            updateDropZone(files[0]);
        }
    });

    $fileInput.on('change', function () {
        if (this.files.length) updateDropZone(this.files[0]);
    });

    function updateDropZone(file) {
        if (file.type !== 'application/pdf') {
            toastr.error('Chỉ chấp nhận file PDF!');
            return;
        }
        var sizeMB = (file.size / 1024 / 1024).toFixed(1);
        $dropZone.css({ borderColor: '#198754', background: '#19875411' });
        $('#dropText').html('<i class="ri-file-pdf-line text-danger me-1"></i><strong>' + file.name + '</strong> (' + sizeMB + ' MB)');
    }

    // Exam type hints
    var hints = {
        thpt: 'Phần 1: Trắc nghiệm (mc) · Phần 2: Đúng/Sai 4 ý (tf) · Phần 3: Trả lời ngắn (short)',
        hsa:  'Phần 1: Trắc nghiệm (mc) · Phần 2: Đúng/Sai 4 ý (tf) · Phần 3: Trả lời ngắn (short)',
        tsa:  'Phần 1: Trắc nghiệm (mc) · Phần 2: Đúng/Sai 4 ý (tf) · Phần 3: Trả lời ngắn (short)',
    };
    $('#examType').on('change', function () {
        $('#examTypeHint').text(hints[$(this).val()] || '');
    });

    // Form submit
    $('#formAiImport').on('submit', function (e) {
        e.preventDefault();

        if (!$fileInput[0].files.length) {
            toastr.error('Vui lòng chọn file PDF trước!');
            return;
        }

        var formData = new FormData(this);

        // Show loading
        $('#defaultCard, #resultCard, #errorCard').addClass('d-none');
        $('#loadingCard').removeClass('d-none');
        $('#btnSubmit').prop('disabled', true).html('<i class="ri-loader-4-line me-1"></i> Đang xử lý...');

        $.ajax({
            url: '/ajax/admin/exam/ai-import',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            timeout: 310000, // 5 phút + buffer
            success: function (res) {
                $('#loadingCard').addClass('d-none');
                $('#btnSubmit').prop('disabled', false).html('<i class="ri-robot-line me-1"></i> Phân tích bằng AI');

                if (res.status) {
                    // Success
                    $('#resultTitle').text('Import thành công!');
                    $('#resultSubtitle').text(res.message);
                    $('#importedCount').text(res.imported_count);
                    $('#imageCount').text(res.image_notes ? res.image_notes.length : 0);

                    var examId = res.exam_id;
                    $('#btnViewExam').attr('href', '/admin/' + examId + '/questions');
                    $('#btnEditExam').attr('href', '/admin/exam/edit/' + examId);

                    // Image notes
                    if (res.image_notes && res.image_notes.length > 0) {
                        var $list = $('#imageNotesList').empty();
                        $.each(res.image_notes, function (i, note) {
                            $list.append('<li class="mb-1">' + $('<span>').text(note).html() + '</li>');
                        });
                        $('#imageNotesSection').removeClass('d-none');
                    } else {
                        $('#imageNotesSection').addClass('d-none');
                    }

                    // Other warnings (skip image_notes already shown)
                    var otherWarnings = [];
                    if (res.warnings) {
                        $.each(res.warnings, function (i, w) {
                            var isImageNote = res.image_notes && res.image_notes.indexOf(w) !== -1;
                            if (!isImageNote) otherWarnings.push(w);
                        });
                    }
                    if (otherWarnings.length > 0) {
                        var $wList = $('#warningsList').empty();
                        $.each(otherWarnings, function (i, w) {
                            $wList.append('<li class="small mb-1">' + $('<span>').text(w).html() + '</li>');
                        });
                        $('#warningsSection').removeClass('d-none');
                    } else {
                        $('#warningsSection').addClass('d-none');
                    }

                    $('#resultCard').removeClass('d-none');
                } else {
                    // Error
                    $('#errorMessage').text(res.message || 'Có lỗi xảy ra.');
                    $('#errorCard').removeClass('d-none');
                }
            },
            error: function (xhr, status) {
                $('#loadingCard').addClass('d-none');
                $('#btnSubmit').prop('disabled', false).html('<i class="ri-robot-line me-1"></i> Phân tích bằng AI');
                var msg = status === 'timeout'
                    ? 'Timeout: AI xử lý quá lâu, thử lại với file nhỏ hơn hoặc kiểm tra API key.'
                    : 'Lỗi kết nối máy chủ. Vui lòng thử lại.';
                $('#errorMessage').text(msg);
                $('#errorCard').removeClass('d-none');
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/exam-ai-import.blade.php ENDPATH**/ ?>