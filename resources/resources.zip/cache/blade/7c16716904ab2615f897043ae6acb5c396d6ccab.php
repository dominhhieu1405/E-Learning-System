
<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div class="card rounded mt-4 border-0">
        <div class="card-body theme-form profile-setting">
            <!--<div class="form-group d-block">
                <label for="username" class="form-label">Tên tài khoản</label>
                <div class="form-input mb-4">
                    <input type="text" class="form-control" id="username" value="<?php echo e(userget()->username); ?>" disabled placeholder="Không thể sửa">
                    <i class="ti ti-at"></i>
                </div>
            </div>-->
            <div class="form-group d-block">
                <label for="fullName" class="form-label">Họ và tên</label>
                <div class="form-input mb-4">
                    <input type="text" class="form-control" id="fullName" value="<?php echo e(userget()->name); ?>" placeholder="Nhập họ và tên">
                    <i class="ti ti-user"></i>
                </div>
            </div>
            <div class="form-group d-block">
                <label for="phone" class="form-label">Số điện thoại</label>
                <div class="form-input mb-4">
                    <input type="text" class="form-control" id="phone" pattern="(03|05|07|08|09)[0-9]{8}" minlength="10" maxlength="10" value="<?php echo e(userget()->phone); ?>" placeholder="Nhập số điện thoại (10 số)">
                    <i class="ti ti-user"></i>
                </div>
            </div>
            <div class="form-group d-block">
                <label for="email" class="form-label">Email</label>
                <div class="form-input mb-4">
                    <input type="email" class="form-control" id="email" value="<?php echo e(userget()->email); ?>" placeholder="Nhập email">
                    <i class="ti ti-user"></i>
                </div>
            </div>
            <div class="form-group d-block">
                <label for="birthday" class="form-label">Sinh nhật</label>
                <div class="form-input mb-4">
                    <input type="date" class="form-control" id="birthday" value="<?php echo e(userget()->birthday); ?>" placeholder="Chọn ngày tháng năm sinh" min="1900-01-01">
                    <i class="ti ti-user"></i>
                </div>
            </div>
            <div class="form-group d-block">
                <label for="gender" class="form-label">Giới tính</label>
                <div class="form-input mb-4">
                    <select class="form-control" id="gender">
                        <option value="0" <?php if(userget()->gender ===0): ?> selected <?php endif; ?>>Nam</option>
                        <option value="1" <?php if(userget()->gender ===1): ?> selected <?php endif; ?>>Nữ</option>
                        <option value="2" <?php if(userget()->gender ===2): ?> selected <?php endif; ?>>Khác</option>
                    </select> <i class="ti ti-gender-transgender"></i>
                </div>
            </div>
            <div class="form-group d-block">
                <label for="province" class="form-label">Tỉnh/Thành phố</label>
                <div class="form-input mb-4">
                    <select class="form-control" id="province">
                        <?php $__currentLoopData = \Models\User::provinces(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($province->code); ?>" <?php if(userget()->province === $province->code): ?> selected <?php endif; ?>><?php echo e($province->name); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> <i class="ti ti-map-pin"></i>
                </div>
            </div>
            <button class="btn btn-success w-100 btn-block mt-1" id="updateProfile">Cập nhật thông tin</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript_plugins'); ?>
    <script type="text/javascript">
        $(function () {
            $("#updateProfile").on("click", function () {
                let data = {
                    name: $("#fullName").val(),
                    phone: $("#phone").val(),
                    email: $("#email").val(),
                    birthday: $("#birthday").val(),
                    gender: $("#gender").val(),
                    province: $("#province").val()
                };
                // Check phone valid
                $.post(
                    '<?php echo e(url('profile.info.edit')); ?>',
                    data,
                    function (e) {
                        alert(e.message)
                    }
                )
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/profile-info-edit.blade.php ENDPATH**/ ?>