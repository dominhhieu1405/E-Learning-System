<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Dịch ngôn ngữ: <?php echo e($language['name']); ?> (<code><?php echo e($language['code']); ?></code>)</h4>
                        <a href="/admin/languages" class="btn btn-secondary">Quay lại</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="translationTable" class="table table-bordered table-striped align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th style="min-width: 150px;">Từ khóa (Key)</th>
                                            <th style="min-width: 300px;">Bản gốc (Tiếng Việt)</th>
                                            <th style="min-width: 300px;">Bản dịch (<?php echo e($language['name']); ?>)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filename => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $fileKey = basename($filename, '.php'); ?>
                                            <?php $__currentLoopData = $data['vi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $viValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(is_array($viValue)): ?>
                                                    <tr>
                                                        <td colspan="3" class="text-danger">Mảng đa chiều chưa được hỗ trợ trên
                                                            UI: <?php echo e($fileKey); ?>.<?php echo e($key); ?></td>
                                                    </tr>
                                                <?php else: ?>
                                                    <tr>
                                                        <td><code><?php echo e($fileKey); ?>.<?php echo e($key); ?></code></td>
                                                        <td><?php echo e($viValue); ?></td>
                                                        <td>
                                                            <textarea class="form-control translation-input" rows="2"
                                                                data-file="<?php echo e($filename); ?>" data-key="<?php echo e($key); ?>"
                                                                data-code="<?php echo e($language['code']); ?>"><?php echo e($data['target'][$key] ?? ''); ?></textarea>
                                                            <div class="text-success small mt-1 save-status d-none"><i
                                                                    class="fas fa-check"></i> Đã lưu</div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
    <script>
        $(function () {
            if ($.fn.DataTable) {
                $('#translationTable').DataTable({
                    language: {
                        url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/vi.json',
                    },
                    pageLength: 20,
                    lengthMenu: [[10, 20, 50, 100, -1], [10, 20, 50, 100, "Tất cả"]],
                    ordering: false
                });
            }

            let timeoutId;

            $('.translation-input').on('input', function () {
                const $input = $(this);
                const $status = $input.next('.save-status');
                $status.addClass('d-none');

                clearTimeout(timeoutId);

                // Auto save after typing stops for 1 second
                timeoutId = setTimeout(() => {
                    saveTranslation($input);
                }, 1000);
            });

            $('.translation-input').on('blur', function () {
                clearTimeout(timeoutId);
                saveTranslation($(this));
            });

            function saveTranslation($input) {
                const value = $input.val();
                const file = $input.data('file');
                const key = $input.data('key');
                const code = $input.data('code');
                const $status = $input.next('.save-status');

                $.ajax({
                    url: '/ajax/admin/language/update-key',
                    method: 'POST',
                    data: { file: file, key: key, value: value, code: code },
                    success: function (res) {
                        if (res.status) {
                            $status.removeClass('d-none').hide().fadeIn(200);
                            setTimeout(() => $status.fadeOut(500), 2000);
                        } else {
                            toastr.error(res.message);
                        }
                    },
                    error: function () {
                        toastr.error('Lỗi kết nối. Vui lòng thử lại.');
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/language-edit.blade.php ENDPATH**/ ?>