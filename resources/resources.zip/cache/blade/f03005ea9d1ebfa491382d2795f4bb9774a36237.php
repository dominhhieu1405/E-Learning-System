<?php $__env->startSection('title', $data->name); ?>
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/" class="text-decoration-none"><?php echo e(__('common.home')); ?></a></li>
            <li class="breadcrumb-item"><a href="/documents" class="text-decoration-none"><?php echo e(__('common.documents')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($data->name); ?></li>
        </ol>
    </nav>
    <div class="row g-4">
        <div class="col-lg-8 mx-auto">
            <div class="ot-card p-4">
                <h2 class="fw-bold mb-3"><?php echo e($data->name); ?></h2>
                <div class="mb-4 text-muted">
                    <span class="me-3"><i class="fas fa-eye me-1"></i> <?php echo e(number_format($data->views ?? 0)); ?> <?php echo e(__('documents.views')); ?></span>
                </div>
                
                <?php if($data->image): ?>
                <img src="<?php echo e($data->image); ?>" alt="<?php echo e($data->name); ?>" class="img-fluid rounded mb-4" style="width: 100%; max-height: 400px; object-fit: cover;">
                <?php endif; ?>
                
                <?php if(!empty($data->file)): ?>
                <div class="bg-light p-3 rounded mb-4 d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-file-pdf text-danger fs-3 me-2"></i>
                        <span class="fw-semibold"><?php echo e(__('documents.attachment')); ?></span>
                    </div>
                    <a href="<?php echo e($data->file); ?>" target="_blank" class="btn btn-ot-primary btn-sm">
                        <i class="fas fa-download me-1"></i> <?php echo e(__('documents.download')); ?>

                    </a>
                </div>
                <?php endif; ?>
                
                <h5 class="fw-bold border-bottom pb-2 mb-3"><?php echo e(__('documents.content_title')); ?></h5>
                <div class="document-content content-body">
                    <?php echo $__env->make('user.components.content-blocks', ['content' => $data->content ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                
                <div class="mt-4 pt-3 border-top">
                    <a href="/documents" class="btn btn-ot-outline"><i class="fas fa-arrow-left"></i> <?php echo e(__('documents.back_to_list')); ?></a>
                </div>
            </div>

            <div class="mt-4">
                <?php echo $__env->make('user.components.comment-box', ['type' => 'document', 'target_id' => $data->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/document.blade.php ENDPATH**/ ?>