<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0">Quản lý thành viên</h4>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Thành viên</th>
                                        <th>Email</th>
                                        <th>Vai trò</th>
                                        <th>Gói VIP</th>
                                        <th>Trạng thái</th>
                                        <th>Ngày tham gia</th>
                                        <th>Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($u->id); ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo e($u->avatar ?: '/assets/images/users/avatar-1.jpg'); ?>" class="avatar-xs rounded-circle me-2" alt="">
                                                <span><?php echo e($u->display_name ?: $u->username); ?></span>
                                            </div>
                                        </td>
                                        <td><?php echo e($u->email); ?></td>
                                        <td>
                                            <?php if($u->role >= 9): ?> <span class="badge bg-danger">Admin</span>
                                            <?php elseif($u->role >= 5): ?> <span class="badge bg-info">Manager</span>
                                            <?php else: ?> <span class="badge bg-secondary">User</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($u->vip_level == 2): ?> <span class="badge bg-primary">PRO</span>
                                            <?php elseif($u->vip_level == 1): ?> <span class="badge bg-success">PLUS</span>
                                            <?php else: ?> <span class="badge bg-light text-dark">Free</span>
                                            <?php endif; ?>
                                            <?php if($u->vip_expiry): ?> <div class="small text-muted"><?php echo e(date('d/m/Y', strtotime($u->vip_expiry))); ?></div> <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($u->status == 1): ?> <span class="badge bg-soft-success text-success">Hoạt động</span>
                                            <?php else: ?> <span class="badge bg-soft-danger text-danger">Đã khóa</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e(date('d/m/Y', strtotime($u->time_join))); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-soft-primary btnEdit" data-user='<?php echo json_encode($u, 15, 512) ?>'>Sửa</button>
                                            <?php if($u->status == 1): ?>
                                            <button class="btn btn-sm btn-soft-danger btnBan" data-id="<?php echo e($u->id); ?>" data-status="2">Khóa</button>
                                            <?php else: ?>
                                            <button class="btn btn-sm btn-soft-success btnBan" data-id="<?php echo e($u->id); ?>" data-status="1">Mở khóa</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Sửa User -->
<div class="modal fade" id="modalUser" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" id="formUserEdit">
            <div class="modal-header">
                <h5 class="modal-title">Sửa thông tin thành viên</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="id" id="userId">
                <div class="mb-3">
                    <label class="form-label">Tên hiển thị</label>
                    <input type="text" name="display_name" id="userName" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" id="userEmail" class="form-control">
                </div>
                <div class="row">
                    <div class="col-6 mb-3">
                        <label class="form-label">Vai trò</label>
                        <select name="role" id="userRole" class="form-control custom-select">
                            <option value="0">User</option>
                            <option value="5">Manager (Exam)</option>
                            <option value="7">Manager (Course)</option>
                            <option value="9">Admin</option>
                        </select>
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">Gói VIP</label>
                        <select name="vip_level" id="userVip" class="form-control custom-select">
                            <option value="0">Free</option>
                            <option value="1">Plus</option>
                            <option value="2">Pro</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Hết hạn VIP</label>
                    <input type="date" name="vip_expiry" id="userVipExpiry" class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
<script>
$(function(){
    const modal = new bootstrap.Modal('#modalUser');
    
    $('.btnEdit').on('click', function(){
        const user = $(this).data('user');
        $('#userId').val(user.id);
        $('#userName').val(user.display_name);
        $('#userEmail').val(user.email);
        $('#userRole').val(user.role);
        $('#userVip').val(user.vip_level);
        $('#userVipExpiry').val(user.vip_expiry ? user.vip_expiry.split(' ')[0] : '');
        modal.show();
    });

    $('#formUserEdit').on('submit', function(e){
        e.preventDefault();
        const id = $('#userId').val();
        $.ajax({
            url: '/ajax/admin/user/edit/' + id,
            method: 'POST',
            data: $(this).serialize(),
            success: function(res){
                res.status ? (toastr.success(res.message), setTimeout(()=>location.reload(), 800)) : toastr.error(res.message);
            }
        });
    });

    $('.btnBan').on('click', function(){
        const id = $(this).data('id');
        const status = $(this).data('status');
        if(!confirm('Xác nhận thực hiện?')) return;
        $.ajax({
            url: '/ajax/admin/user/ban',
            method: 'POST',
            data: {id, status},
            success: function(res){
                res.status ? location.reload() : toastr.error(res.message);
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/users.blade.php ENDPATH**/ ?>