<?php $__env->startSection('title', __('documents.title')); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="section-header mb-4">
        <h2 class="mb-0"><?php echo e(__('documents.heading')); ?></h2>
    </div>
    
    <?php if($data && count($data) > 0): ?>
    <div class="row g-4">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-md-6 col-lg-3">
            <div class="ot-card h-100">
                <?php if($doc->image): ?>
                    <img src="<?php echo e($doc->image); ?>" alt="<?php echo e($doc->name); ?>" class="card-img-top" style="height: 180px; object-fit: cover;">
                <?php else: ?>
                    <div class="card-img-top d-flex align-items-center justify-content-center" style="height: 180px; background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;">
                        <i class="fas fa-file-alt fa-3x" style="opacity:0.5;"></i>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <h6 class="card-title fw-bold"><?php echo e($doc->name); ?></h6>
                    <p class="card-text small text-muted text-truncate"><?php echo e($doc->description ?? ''); ?></p>
                    <a href="/document/<?php echo e($doc->id); ?>" class="stretched-link"></a>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0 pb-3">
                    <div class="btn btn-sm btn-outline-primary w-100 rounded-pill fw-bold">
                        <?php echo e(__('documents.view_details')); ?> <i class="fas fa-arrow-right ms-1 fs-12"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <?php if(isset($paginate) && $paginate->total_page > 1): ?>
    <div class="d-flex justify-content-center mt-5">
        <nav aria-label="Page navigation">
            <ul class="pagination pagination-sm">
                <?php for($i = 1; $i <= $paginate->total_page; $i++): ?>
                <li class="page-item <?php echo e($page == $i ? 'active' : ''); ?>">
                    <a class="page-link" href="/documents/<?php echo e($i); ?>"><?php echo e($i); ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <div class="text-center py-5 text-muted">
        <i class="fas fa-box-open fa-3x mb-3 opacity-50"></i>
        <p><?php echo e(__('documents.no_documents')); ?></p>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/documents.blade.php ENDPATH**/ ?>