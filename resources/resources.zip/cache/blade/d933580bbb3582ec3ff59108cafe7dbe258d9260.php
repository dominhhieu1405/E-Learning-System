
<?php $__env->startSection('title', 'Đăng nhập'); ?>
<?php $__env->startSection('content'); ?>
    <!-- login section start -->
    <form class="auth-form" target="_blank">
        <div class="custom-container">
            <div class="form-group">
                <label for="inputUsername" class="form-label">Tên tài khoản</label>
                <div class="form-input mb-4">
                    <input type="text" class="form-control" id="inputUsername" minlength="4" placeholder="Nhập tên tài khoản"/>
                    <i class="ti ti-user text-white-50"></i>
                </div>
            </div>

            <div class="form-group">
                <label for="inputPassword" class="form-label">Mật khẩu</label>
                <div class="form-input">
                    <input type="password" class="form-control" id="inputPassword" placeholder="Nhập mật khẩu"/>
                    <i class="ti ti-key text-white-50"></i>
                </div>
            </div>
            <div class="option mt-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"/>
                    <label class="form-check-label" for="flexCheckDefault">Giữ đăng nhập?</label>
                </div>
            </div>

            <div class="submit-btn">
                <button type="button" class="btn auth-btn w-100">Đăng nhập</button>
            </div>
            <div class="division">
                <span>HOẶC</span>
            </div>

            <ul class="social-media">
                <!--<li>
                    <a href="<?php echo e(url("api.login.facebook")); ?>" target="_blank">
                        <img class="img-fluid icons" src="/assets/img/svg/facebook.svg" alt="Đăng nhập bằng facebook"/>
                    </a>
                </li>-->
                <li>
                    <a href="<?php echo e(url("api.login.google")); ?>" target="_blank">
                        <img class="img-fluid icons" src="/assets/img/svg/google.svg" alt="Đăng nhập bằng google"/>
                        <span class="text-white">Đăng nhập bằng Google</span>
                    </a>
                </li>
            </ul>

        </div>
    </form>
    <!-- login section end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_plugins'); ?>
    <script type="text/javascript">
        $(function (){
            $('.auth-btn').click(function (){
                let username = $('#inputUsername').val();
                let password = $('#inputPassword').val();
                let remember = $('#flexCheckDefault').is(':checked');
                if(username.length < 4 || username.length > 32){
                    alert('Tên tài khoản phải từ 4 đến 32 ký tự');
                    return;
                }
                if(password.length < 8 || password.length > 32){
                    alert('Mật khẩu phải lớn hơn 8 và đến 32 ký tự');
                    return;
                }
                $.ajax({
                    url: '<?php echo e(url('login')); ?>',
                    method: 'POST',
                    data: {
                        username: username,
                        password: password,
                        remember: remember
                    },
                    success: function (response){
                        alert(response.message);
                        if(response.status){
                            window.location.href = '/';
                        }else{
                        }
                    }
                })
            })
            $(".social-media li").on("click", function() {
                const link = $(this).find('a').attr('href');
                if (link) {
                    window.open(link, '_self'); // Hoặc '_blank' nếu muốn mở trong tab mới
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/login.blade.php ENDPATH**/ ?>