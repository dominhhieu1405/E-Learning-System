


<?php $__env->startSection('css_plugins'); ?>
    <!-- DataTables -->
    <link href="/assets/admin/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/admin/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/fontawesome.min.css" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Quản lý Tài liệu</h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Quản lý Tài liệu</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Main content -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">
                                Danh sách Tài liệu
                                <a class="btn btn-sm btn-success float-right" href="<?php echo e(url("admin.document.add")); ?>">
                                    <i class="fas fa-plus"></i>
                                    Thêm
                                </a>
                            </h4>

                            <div class="table-responsive">
                                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead>
                                    <tr class="text-center">
                                        <th>#</th>
                                        <th style="width: 100px">Ảnh</th>
                                        <th>Tên</th>
                                        <th style="width: 80px">Lượt xem</th>
                                        <th>Cập nhật</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody class="text-center">
                                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($document->id); ?></td>
                                            <td><img src="<?php echo e($document->image); ?>" onerror="errorImage(this)" style="width: 90px" alt="<?php echo e($document->name); ?>"></td>
                                            <td><?php echo e($document->name); ?></td>
                                            <td class="text-center"><?php echo e(number_format($document->views)); ?></td>
                                            <td class="text-center"><?php echo e(date("d/m/Y H:i", strtotime($document->time_update))); ?></td>
                                            <td>
                                                <a href="<?php echo e(url("admin.document.edit", ['id' => $document->id])); ?>" class="btn btn-success btn-sm">Sửa</a>
                                                <a href="javascript:void(0)" class="btn btn-danger btn-sm delete-document" data-id="<?php echo e($document->id); ?>">Xóa</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>

    <!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
    <!-- Required datatable js -->
    <script src="/assets/admin/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="/assets/admin/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(function (){
            $(".delete-document").on("click", function (){
                var id = $(this).data("id");
                if(confirm("Bạn có chắc chắn muốn xóa tài liệu này không?")){
                    $.post(
                        "<?php echo e(url("ajax.admin.document.delete")); ?>",
                        {
                            id: id
                        },
                        function (e){
                            if(e.status){
                                alert("Xóa tài liệu thành công");
                                location.reload();
                            }else{
                                alert("Xóa tài liệu thất bại");
                            }
                        }, 'json'
                    )
                }
            })

            var table = $("#datatable").DataTable({
                "autoWidth": true,
                'columnDefs': [ {
                    'targets': [0,1,5], /* column index */
                    'orderable': false, /* true or false */
                },
                    {
                        "targets": 0,
                        "width": "29px"
                    },
                    {
                        "targets": 1,
                        "width": "100px"
                    },
                    {
                        "targets": 3,
                        "width": "80px"
                    },
                    {
                        "targets": 4,
                        "width": "160px"
                    },
                    {
                        "targets": 5,
                        "width": "100px"
                    }
                ],
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function () {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                }
            });

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/documents.blade.php ENDPATH**/ ?>