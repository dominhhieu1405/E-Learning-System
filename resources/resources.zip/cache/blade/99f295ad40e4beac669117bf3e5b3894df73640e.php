<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">

                <li class="menu-title">Bảng điều khiển</li>
                <li>
                    <a href="<?php echo e(path_url('admin')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span>Bảng điều khiển</span>
                    </a>
                </li>
                <?php if(\Models\User::isAdmin()): ?>
                <li>
                    <a href="<?php echo e(path_url('admin.statistic')); ?>" class="waves-effect">
                        <i class="ri-bar-chart-line"></i>
                        <span>Thống kê</span>
                    </a>
                </li>
                <?php endif; ?>

                
                <?php if(\Models\User::isExamManager()): ?>
                <li class="menu-title">BÀI KIỂM TRA</li>
                <li>
                    <a href="<?php echo e(path_url('admin.exams')); ?>" class="waves-effect">
                        <i class="ri-file-list-3-line"></i>
                        <span>Đề thi</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.exam.add')); ?>" class="waves-effect">
                        <i class="ri-file-add-line"></i>
                        <span>Tạo đề mới</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.exam.ai-import')); ?>" class="waves-effect">
                        <i class="ri-robot-line"></i>
                        <span>Import đề bằng AI</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.exam.json-import')); ?>" class="waves-effect">
                        <i class="ri-code-line"></i>
                        <span>Import đề bằng json</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.questions')); ?>" class="waves-effect">
                        <i class="ri-question-line"></i>
                        <span>Ngân hàng câu hỏi</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.sessions')); ?>" class="waves-effect">
                        <i class="ri-user-follow-line"></i>
                        <span>Phiên thi</span>
                    </a>
                </li>
                <?php endif; ?>

                
                <?php if(\Models\User::isCourseManager()): ?>
                <li class="menu-title">TÀI NGUYÊN</li>
                <li>
                    <a href="<?php echo e(path_url('admin.courses')); ?>" class="waves-effect">
                        <i class="ri-list-check"></i>
                        <span>Các khóa học</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.course.add')); ?>" class="waves-effect">
                        <i class="ri-add-box-line"></i>
                        <span>Thêm khóa học</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.documents')); ?>" class="waves-effect">
                        <i class="ri-file-text-line"></i>
                        <span>Các tài liệu</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.document.add')); ?>" class="waves-effect">
                        <i class="ri-file-add-line"></i>
                        <span>Thêm tài liệu</span>
                    </a>
                </li>
                <?php endif; ?>

                
                <?php if(\Models\User::isAdmin()): ?>
                <li class="menu-title">HỆ THỐNG</li>
                <li>
                    <a href="<?php echo e(path_url('admin.users')); ?>" class="waves-effect">
                        <i class="ri-user-settings-line"></i>
                        <span>Thành viên</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.comments')); ?>" class="waves-effect">
                        <i class="ri-chat-1-line"></i>
                        <span>Bình luận</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.languages')); ?>" class="waves-effect">
                        <i class="ri-translate-2"></i>
                        <span>Ngôn Ngữ</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(path_url('admin.settings')); ?>" class="waves-effect">
                        <i class="ri-settings-2-line"></i>
                        <span>Cài đặt Web</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div><?php /**PATH D:\localhost\DGNL\resources\views/admin/components/sidebar.blade.php ENDPATH**/ ?>