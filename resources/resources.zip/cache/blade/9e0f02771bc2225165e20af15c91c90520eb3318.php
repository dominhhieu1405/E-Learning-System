
<?php $__env->startSection('title', 'Điều khoản & chính sách'); ?>

<?php $__env->startSection('content'); ?>
    <div class="terms-Conditions mt-1 pb-4">
        <h2>Điều khoản & chính sách</h2>

        <p>Chào mừng bạn đến với OnThi.io.vn.com (Lụm Deals)! </p>

        <p>Chúng tôi cam kết mang đến cho bạn những thông tin hữu ích nhất về mã giảm giá, chương trình hoàn tiền, và các ưu đãi mua sắm. Khi truy cập và sử dụng trang web của chúng tôi, bạn đồng ý tuân thủ các điều khoản và chính sách dưới đây.</p>

        <p>Các thuật ngữ sau đây được áp dụng cho Điều Khoản và Điều Kiện, Chính Sách Bảo Mật, Tuyên Bố Miễn Trừ Trách Nhiệm, và tất cả các Thỏa Thuận khác trên trang web của chúng tôi:</p>

        <ul>
            <li><b>"Khách hàng", "Bạn", và "Của bạn"</b>: Đề cập đến bạn, cá nhân truy cập và sử dụng trang web này, đồng thời tuân thủ các điều khoản và điều kiện được công ty chúng tôi quy định.</li>
            <li><b>"Chúng tôi", "Của chúng tôi"</b>: Đề cập đến tổ chức sở hữu và vận hành trang web OnThi.io.vn.com (Lụm Deals).</li>
            <li><b>"Bên", "Các bên", hoặc "Chúng ta"</b>: Đề cập đến cả bạn và chúng tôi, hoặc chỉ riêng bạn hoặc riêng chúng tôi, tùy theo ngữ cảnh.</li>
        </ul>

        <p>Các thuật ngữ trên được sử dụng để đảm bảo tính minh bạch, rõ ràng và nhất quán trong mọi tài liệu và thỏa thuận liên quan đến trang web này.</p>

        <p>Chúng tôi mong muốn rằng mọi điều khoản, chính sách và thông tin được trình bày đều dễ hiểu, giúp bạn cảm thấy an tâm và tự tin khi sử dụng dịch vụ của chúng tôi. Trong trường hợp có sự khác biệt về cách hiểu, nội dung trong tài liệu này sẽ được giải thích theo tinh thần hợp lý, bảo vệ quyền lợi của cả hai bên.</p>

        <h4>1. Quyền Sử Dụng Trang Web</h4>
        <p>Bạn được cấp quyền sử dụng trang web OnThi.io.vn.com theo các điều kiện và hạn chế sau:</p>
        <ul>
            <li>Bạn chỉ được phép sử dụng trang web này cho mục đích cá nhân, không phục vụ cho mục đích thương mại hoặc hành vi vi phạm pháp luật.</li>
            <li>Bạn không được phép sao chép, phân phối lại, sửa đổi hoặc phát tán bất kỳ phần nào của trang web mà không có sự đồng ý của chúng tôi.</li>
        </ul>

        <h4>2. Quyền Sở Hữu Trí Tuệ</h4>
        <p>Tất cả nội dung trên trang web, bao gồm nhưng không giới hạn ở văn bản, hình ảnh, biểu đồ, logo, và phần mềm, đều thuộc quyền sở hữu của <b>OnThi.io.vn.com</b> hoặc các bên cấp phép. Bạn không có quyền sử dụng nội dung này mà không có sự cho phép của chúng tôi, trừ khi được quy định rõ ràng trong các điều khoản này.</p>

        <h4>3. Điều Kiện Được Cấp Quyền Sử Dụng</h4>
        <p>Khi bạn sử dụng trang web, bạn cam kết:</p>
        <ul>
            <li>Cung cấp thông tin chính xác và đầy đủ khi đăng ký tài khoản hoặc giao dịch trên trang web.</li>
            <li>Không xâm phạm quyền lợi của người khác, bao gồm việc gửi spam, quảng cáo không mong muốn hoặc vi phạm các điều khoản của trang web.</li>
        </ul>

        <h4>4. Chính Sách Bảo Mật</h4>
        <p>Chúng tôi cam kết bảo vệ thông tin cá nhân của bạn theo Chính Sách Bảo Mật đã được công bố. Khi bạn sử dụng trang web, bạn đồng ý với cách thức thu thập, sử dụng và lưu trữ thông tin cá nhân của bạn theo chính sách bảo mật này.</p>

        <h4>5. Hạn Chế Trách Nhiệm</h4>
        <p><b>OnThi.io.vn.com</b> không chịu trách nhiệm đối với bất kỳ thiệt hại, tổn thất hoặc chi phí phát sinh từ việc sử dụng hoặc không thể sử dụng trang web, bao gồm nhưng không giới hạn ở lỗi phần mềm, gián đoạn dịch vụ hoặc mất dữ liệu. Chúng tôi cũng không chịu trách nhiệm về bất kỳ tổn thất nào do bên thứ ba gây ra.</p>

        <h4>6. Liên Kết Đến Các Trang Web Khác</h4>
        <p>Trang web có thể chứa các liên kết đến các trang web bên ngoài. Chúng tôi không chịu trách nhiệm về nội dung hoặc chính sách bảo mật của các trang web này. Việc sử dụng các liên kết này hoàn toàn phụ thuộc vào sự chấp thuận của bạn và bạn tự chịu trách nhiệm khi truy cập các trang web này.</p>

        <h4>7. Quyền Thay Đổi Điều Khoản</h4>
        <p>Chúng tôi bảo lưu quyền thay đổi, chỉnh sửa hoặc cập nhật các điều khoản và chính sách sử dụng mà không cần thông báo trước. Mọi thay đổi sẽ có hiệu lực ngay khi được đăng tải trên trang web. Bạn có trách nhiệm kiểm tra thường xuyên để cập nhật các thay đổi.</p>

        <h4>8. Nghiêm Cấm</h4>
        <p>Bạn đồng ý không thực hiện bất kỳ hành vi nào sau đây khi sử dụng trang web của chúng tôi:</p>
        <ul>
            <li><b>Vi phạm pháp luật</b>: Sử dụng trang web để thực hiện các hành vi trái pháp luật, bao gồm nhưng không giới hạn ở hành vi lừa đảo, gian lận, phát tán phần mềm độc hại hoặc tham gia vào các hoạt động phạm tội.</li>
            <li><b>Xâm phạm quyền lợi của người khác</b>: Xâm phạm quyền sở hữu trí tuệ, quyền riêng tư hoặc quyền lợi hợp pháp của người khác, bao gồm sao chép hoặc phân phối trái phép các tài liệu hoặc nội dung từ trang web.</li>
            <li><b>Gửi spam hoặc quảng cáo không mong muốn</b>: Gửi các thông điệp không mong muốn, quảng cáo, thư rác, hoặc bất kỳ hình thức marketing không hợp pháp hoặc không được phép mà không có sự đồng ý rõ ràng của chúng tôi.</li>
            <li><b>Lạm dụng hệ thống hoặc dịch vụ</b>: Cố gắng xâm nhập hoặc tấn công hệ thống của chúng tôi, gây rối loạn các dịch vụ, hoặc sử dụng bất kỳ phương tiện nào để phá hoại tính toàn vẹn của dữ liệu hoặc dịch vụ của trang web.</li>
            <li><b>Gây hại cho người dùng khác</b>: Lợi dụng, lừa đảo, hoặc gây tổn hại về tinh thần, tài chính đối với các thành viên hoặc người dùng khác của trang web.</li>
        </ul>
        <p>Việc vi phạm các điều khoản này có thể dẫn đến việc tài khoản của bạn bị đình chỉ hoặc hủy bỏ, và có thể chịu trách nhiệm pháp lý theo quy định của pháp luật.</p>

        <h3>Chính sách bảo mật</h3>

        <p>Tại OnThi.io.vn.com (Lụm Deals), chúng tôi cam kết bảo vệ quyền riêng tư và thông tin cá nhân của bạn. Chính sách bảo mật này giải thích cách chúng tôi thu thập, sử dụng, lưu trữ, và bảo vệ thông tin của bạn khi sử dụng trang web của chúng tôi.</p>

        <h4>1. Thông Tin Chúng Tôi Thu Thập</h4>
        <p>Chúng tôi có thể thu thập các loại thông tin sau đây:</p>
        <ul>
            <li><b>Thông tin cá nhân</b>: Bao gồm tên, địa chỉ email, số điện thoại, hoặc thông tin khác mà bạn cung cấp khi đăng ký tài khoản hoặc liên hệ với chúng tôi.</li>
            <li><b>Thông tin phi cá nhân:</b> Bao gồm địa chỉ IP, loại trình duyệt, trang web tham chiếu, thời gian truy cập, và hành vi duyệt web trên trang của chúng tôi.</li>
            <li><b>Cookie và Công nghệ Theo dõi</b>: Chúng tôi sử dụng cookie để cải thiện trải nghiệm người dùng và thu thập dữ liệu về cách bạn sử dụng trang web.
            </li>
        </ul>


        <h4>2. Cách Chúng Tôi Sử Dụng Thông Tin</h4>
        <p>Thông tin của bạn được sử dụng để:</p>
        <ul>
            <li><b>Cải thiện dịch vụ</b>: Tối ưu hóa nội dung và trải nghiệm duyệt web dựa trên sở thích của bạn.</li>
            <li><b>Gửi thông báo</b>: Cung cấp thông tin về mã giảm giá, chương trình khuyến mãi, hoặc cập nhật mới (nếu bạn đồng ý).</li>
            <li><b>Phân tích dữ liệu</b>: Đo lường hiệu quả của các chiến dịch quảng cáo hoặc phân tích hành vi người dùng để cải thiện trang web.</li>
        </ul>

        <h4>3. Chia Sẻ Thông Tin</h4>
        <p>Chúng tôi không bán, cho thuê hoặc chia sẻ thông tin cá nhân của bạn với bên thứ ba trừ khi:</p>
        <ul>
            <li>Có sự đồng ý của bạn.</li>
            <li>Theo yêu cầu của pháp luật hoặc cơ quan chức năng.</li>
            <li>Để bảo vệ quyền lợi và tài sản của OnThi.io.vn.com.</li>
        </ul>

        <h4>4. Cookie và Theo Dõi</h4>
        <p>Chúng tôi sử dụng cookie để:</p>
        <ul>
            <li>Ghi nhớ thông tin đăng nhập hoặc tùy chọn của bạn.</li>
            <li>Phân tích lưu lượng truy cập để cải thiện dịch vụ.</li>
        </ul>
        <p>Bạn có thể tắt cookie qua cài đặt trình duyệt, nhưng điều này có thể ảnh hưởng đến trải nghiệm của bạn trên trang web.</p>

        <h4>5. Bảo Vệ Thông Tin Của Bạn</h4>
        <p>Chúng tôi áp dụng các biện pháp bảo mật kỹ thuật và tổ chức để bảo vệ thông tin cá nhân của bạn khỏi mất mát, truy cập trái phép, hoặc lạm dụng, bao gồm:</p>
        <ul>
            <li>Sử dụng mã hóa dữ liệu.</li>
            <li>Hạn chế quyền truy cập vào thông tin cá nhân.</li>
            <li>Kiểm tra định kỳ các biện pháp bảo mật của chúng tôi.</li>
        </ul>

        <h4>6. Quyền Của Bạn</h4>
        <p>Bạn có các quyền sau:</p>
        <ul>
            <li><b>Quyền truy cập</b>: Yêu cầu xem thông tin cá nhân mà chúng tôi đang lưu trữ.</li>
            <li><b>Quyền chỉnh sửa</b>: Đề nghị cập nhật hoặc chỉnh sửa thông tin không chính xác.</li>
            <li><b>Quyền xóa</b>: Yêu cầu xóa thông tin cá nhân (tuân theo quy định pháp luật).</li>
            <li><b>Quyền từ chối</b>: Ngừng nhận thông báo tiếp thị hoặc tắt cookie.</li>
        </ul>

        <h4>7. Thay Đổi Chính Sách Bảo Mật</h4>
        <p>Chúng tôi có quyền cập nhật chính sách bảo mật này bất kỳ lúc nào. Mọi thay đổi sẽ được thông báo trên trang web và có hiệu lực ngay khi đăng tải. Bạn nên kiểm tra định kỳ để cập nhật các thay đổi mới nhất.</p>

        <!-- <h3>Disclaimer</h3> -->
        <h3>Từ chối trách nhiệm</h3>

        <p>Trang web của chúng tôi là một nền tảng chia sẻ thông tin về hoàn tiền khi mua sắm trên Shopee, nhằm mục đích cung cấp thông tin hữu ích để người dùng tối ưu hóa chi phí mua sắm của mình. Tuy nhiên, chúng tôi muốn nhấn mạnh các điểm sau:</p>

        <ul>
            <li>
                <b>Không liên kết chính thức với Shopee:</b>
                Trang web này không thuộc sở hữu, điều hành hoặc có bất kỳ sự liên kết chính thức nào với Shopee. Mọi thông tin về chương trình hoàn tiền được tổng hợp từ các nguồn đáng tin cậy hoặc do người dùng chia sẻ, nhưng không được đảm bảo chính xác tuyệt đối.
            </li>
            <li>
                <b>Không chịu trách nhiệm pháp lý:</b>
                Chúng tôi không chịu trách nhiệm đối với bất kỳ tổn thất hoặc thiệt hại nào phát sinh từ việc sử dụng thông tin trên trang web này. Người dùng cần kiểm tra lại thông tin trên trang Shopee hoặc các nguồn chính thức trước khi thực hiện giao dịch.
            </li>
            <li>
                <b>Không bảo đảm hoàn tiền:</b>
                Việc hoàn tiền phụ thuộc vào chính sách và điều kiện từ Shopee hoặc các đối tác liên quan. Chúng tôi không cam kết rằng người dùng sẽ nhận được hoàn tiền từ tất cả các giao dịch.
            </li>
            <li>
                <b>Thay đổi thông tin và chính sách:</b>
                Các chương trình hoàn tiền có thể thay đổi hoặc bị hủy bỏ mà không thông báo trước. Chúng tôi không thể cập nhật thông tin ngay lập tức khi có thay đổi từ phía các đối tác có liên quan
            </li>
            <li>
                <b>Quyền riêng tư:</b>
                Chúng tôi cam kết bảo vệ quyền riêng tư của người dùng và không thu thập thông tin cá nhân ngoài những gì cần thiết để cung cấp dịch vụ.
            </li>
        </ul>

        <p>
            Các hạn chế và miễn trừ trách nhiệm được quy định trong phần này và các phần khác của tuyên bố từ chối trách nhiệm:
            (a) tuân theo các quy định đã nêu trong đoạn trước; và
            (b) áp dụng cho mọi trách nhiệm pháp lý phát sinh theo tuyên bố từ chối trách nhiệm này, bao gồm cả trách nhiệm phát sinh từ hợp đồng, hành vi vi phạm và vi phạm nghĩa vụ theo luật định.
        </p>

        <p>Khi trang web và các thông tin, dịch vụ trên trang web được cung cấp hoàn toàn miễn phí, chúng tôi không chịu trách nhiệm pháp lý đối với bất kỳ mất mát hoặc thiệt hại nào, bất kể bản chất nào.</p>


        <h3>Quyền Thay Đổi Nội Dung</h3>

        <p>Chúng tôi bảo lưu quyền thay đổi, cập nhật hoặc chỉnh sửa bất kỳ nội dung, thông tin, hoặc chính sách nào trên trang web mà không cần thông báo trước. Những thay đổi này có thể được áp dụng ngay khi được đăng tải trên trang web.</p>

        <p>Người dùng được khuyến khích kiểm tra thường xuyên để cập nhật các thông tin và điều khoản mới nhất. Việc tiếp tục sử dụng trang web sau khi có thay đổi đồng nghĩa với việc bạn chấp nhận các thay đổi đó.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/terms.blade.php ENDPATH**/ ?>