<?php if($orders): ?>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card rounded mt-3 orderCard">
            <div class="card-body p-2">
                <div class="position-relative d-flex align-items-center p-2">
                    <div style="flex: 0 0 60px;width: 60px;max-width: 60px;">
                        <div class="me-2">
                            <a href="#">
                                <img class="rounded-circle" src="/assets/img/logo/shopee.png" alt="shopee" style="max-width: 60px; max-height: 60px">
                            </a>
                        </div>
                    </div>
                    <div class="position-absolute text-center" style="top: 5px;right: 5px;z-index: 1;">
                        <?php if($order->order_status === 2): ?>
                            <span class="badge bg-success">+ <?php echo e(number_format($order->commission_user + $order->brand_commission_user)); ?> DP</span>
                        <?php elseif($order->order_status === 3): ?>
                            <span class="badge bg-secondary">Đã hủy</span>
                        <?php else: ?>
                            <span class="badge bg-shopee"><?php echo e(number_format($order->commission_user + $order->brand_commission_user)); ?> DP</span>
                        <?php endif; ?>
                    </div>
                    <div class="position-relative" style="flex: 0 0 calc(100% - 69px);width: calc(100% - 69px);max-width: calc(100% - 69px);padding-right:80px">
                        <h6 class="mb-1">
                            <a class="text-primary" href="#"><?php echo e($order->name ?? "Đơn hàng shopee"); ?></a>
                        </h6>
                        <p class="mb-0" style="font-size: 12px;">Mã đơn ***<?php echo e(substr($order->order_sn, 6)); ?></p>
                        <p class="mb-0" style="font-size: 12px;"><?php echo e(date("H:i d/m/Y", strtotime($order->complete_time) > 999999999 ? strtotime($order->complete_time) : strtotime($order->purchase_time))); ?></p>
                    </div>
                </div>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/components/orders.blade.php ENDPATH**/ ?>