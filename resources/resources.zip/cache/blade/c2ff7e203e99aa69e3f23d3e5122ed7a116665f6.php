<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0">Ngân hàng Câu hỏi</h4>
                    <a href="<?php echo e(path_url('admin.question.add')); ?>" class="btn btn-primary">
                        <i class="ri-add-line"></i> Thêm câu hỏi
                    </a>
                </div>
            </div>
        </div>

        <div class="row mb-3 g-2">
            <div class="col-md-3">
                <div class="form-group">
                    <select id="filterSubject" class="form-control custom-select">
                        <option value="">Tất cả môn học</option>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php echo e(($filterSubject == $s->id) ? 'selected' : ''); ?>><?php echo e($s->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <select id="filterType" class="form-control custom-select">
                        <option value="">Tất cả loại câu hỏi</option>
                        <option value="mc" <?php echo e(($filterType == 'mc') ? 'selected' : ''); ?>>Trắc nghiệm</option>
                        <option value="ms" <?php echo e(($filterType == 'ms') ? 'selected' : ''); ?>>Nhiều lựa chọn</option>
                        <option value="tf" <?php echo e(($filterType == 'tf') ? 'selected' : ''); ?>>Đúng/Sai</option>
                        <option value="short" <?php echo e(($filterType == 'short') ? 'selected' : ''); ?>>Trả lời ngắn</option>
                        <option value="mblanks" <?php echo e(($filterType == 'mblanks') ? 'selected' : ''); ?>>Nhiều ô trống</option>
                        <option value="matching" <?php echo e(($filterType == 'matching') ? 'selected' : ''); ?>>Ghép cột</option>
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <button id="btnFilter" class="btn btn-primary w-100"><i class="ri-filter-line"></i> Lọc</button>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <p class="text-muted">Tổng: <strong><?php echo e($totalCount ?? 0); ?></strong> câu hỏi trong ngân hàng</p>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="50">#</th>
                                        <th>Nội dung (rút gọn)</th>
                                        <th width="100">Loại</th>
                                        <th width="120">Môn học</th>
                                        <th width="140">Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($questions && count($questions) > 0): ?>
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($q->id); ?></td>
                                            <td><?php echo e(\Illuminate\Support\Str::limit(strip_tags($q->content), 80)); ?></td>
                                            <td>
                                                <?php if($q->question_type === 'mc'): ?>
                                                    <span class="badge bg-primary">Trắc nghiệm</span>
                                                <?php elseif($q->question_type === 'ms'): ?>
                                                    <span class="badge bg-purple">Nhiều lựa chọn</span>
                                                <?php elseif($q->question_type === 'tf'): ?>
                                                    <span class="badge bg-warning">Đúng/Sai</span>
                                                <?php elseif($q->question_type === 'mblanks'): ?>
                                                    <span class="badge bg-danger">Nhiều ô trống</span>
                                                <?php elseif($q->question_type === 'matching'): ?>
                                                    <span class="badge bg-secondary">Ghép cột</span>
                                                <?php else: ?>
                                                    <span class="badge bg-info">Trả lời ngắn</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($q->subject_name ?? '—'); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(path_url('admin.question.edit', ['id' => $q->id])); ?>" class="btn btn-sm btn-icon btn-soft-primary">
                                                    <i class="ri-edit-line"></i>
                                                </a>
                                                <button class="btn btn-sm btn-icon btn-soft-danger btn-delete" data-id="<?php echo e($q->id); ?>">
                                                    <i class="ri-delete-bin-line"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr><td colspan="5" class="text-center text-muted">Chưa có câu hỏi nào</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript_plugins'); ?>
<script>
$(function(){
    $('#btnFilter').on('click', function(){
        const subject = $('#filterSubject').val();
        const type = $('#filterType').val();
        location.href = `?subject_id=${subject}&question_type=${type}`;
    });

    $('.btn-delete').on('click', function(){
        if(!confirm('Xóa câu hỏi này?')) return;
        $.post('/ajax/admin/question/delete', {id: $(this).data('id')}, function(res){
            if(res.status){ toastr.success(res.message); setTimeout(()=>location.reload(), 500); }
            else toastr.error(res.message);
        });
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/questions.blade.php ENDPATH**/ ?>