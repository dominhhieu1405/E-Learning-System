<?php $__env->startSection('title', $data->name); ?>
<?php $__env->startSection('content'); ?>
<?php
    $units = \Models\Web::courseUnit($course->id) ?? [];
?>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="/courses" class="text-decoration-none">Khóa học</a></li>
            <li class="breadcrumb-item"><a href="/course/<?php echo e($course->id); ?>" class="text-decoration-none"><?php echo e($course->name); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($data->name); ?></li>
        </ol>
    </nav>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="ot-card p-4">
                <h3 class="fw-bold mb-3"><?php echo e($data->name); ?></h3>
                
                <?php 
                    $allParts = [];
                    // Add legacy single video if present
                    if (!empty($data->video)) {
                        $allParts[] = [
                            'text' => 'Phần 1',
                            'url' => $data->video
                        ];
                    }
                    
                    // Add additional videos from JSON
                    $extraVideos = json_decode($data->videos ?? '[]', true);
                    foreach($extraVideos as $vid) {
                        // Avoid duplication if the URL is already in the list
                        $exists = false;
                        foreach($allParts as $part) {
                            if ($part['url'] === $vid['url']) $exists = true;
                        }
                        if (!$exists) {
                            $allParts[] = [
                                'text' => $vid['text'] ?? ('Phần ' . (count($allParts) + 1)),
                                'url' => $vid['url']
                            ];
                        }
                    }
                    
                    $firstPart = $allParts[0] ?? null;
                ?>

                <div class="video-player-section mb-4">
                    <?php if($firstPart): ?>
                        <div class="ratio ratio-16x9 mb-3 bg-black rounded overflow-hidden shadow">
                            <iframe id="mainVideoPlayer" src="" title="Video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>

                        
                        <?php if(count($allParts) > 1): ?>
                            <div class="video-parts-nav d-flex flex-wrap gap-2 mb-3">
                                <?php $__currentLoopData = $allParts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button class="btn btn-sm btn-ot-outline video-part-btn <?php echo e($index == 0 ? 'active' : ''); ?>" 
                                            data-url="<?php echo e($part['url']); ?>" 
                                            onclick="changeVideo(this)">
                                        <i class="fas fa-play-circle me-1"></i> <?php echo e($part['text']); ?>

                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            
                            <div class="video-part-btn d-none" data-url="<?php echo e($firstPart['url']); ?>"></div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <div class="lesson-content content-body mb-4">
                    <?php echo $data->description ?? ''; ?>

                </div>

                <?php 
                    $files = json_decode($data->files ?? '[]', true);
                ?>

                <?php if(!empty($files)): ?>
                <h5 class="fw-bold border-bottom pb-2 mb-3 mt-4">Tài liệu đính kèm</h5>
                <div class="list-group">
                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($f['url']); ?>" target="_blank" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-3">
                            <span><i class="fas fa-file-download text-primary me-2"></i> <?php echo e($f['text'] ?: 'Tải tài liệu'); ?></span>
                            <span class="badge bg-primary rounded-pill"><i class="fas fa-download"></i></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="d-flex justify-content-between mt-4 p-3 bg-light rounded shadow-sm">
                <?php if($prev): ?>
                    <a href="/lesson/<?php echo e($prev->id); ?>" class="btn btn-ot-outline btn-sm">
                        <i class="fas fa-chevron-left me-1"></i> Bài trước
                    </a>
                <?php else: ?>
                    <div></div>
                <?php endif; ?>
                
                <a href="/course/<?php echo e($course->id); ?>" class="btn btn-link text-decoration-none text-muted small px-0">
                    <i class="fas fa-list me-1"></i> Mục lục
                </a>

                <?php if($next): ?>
                    <a href="/lesson/<?php echo e($next->id); ?>" class="btn btn-ot-primary btn-sm">
                        Bài tiếp theo <i class="fas fa-chevron-right ms-1"></i>
                    </a>
                <?php else: ?>
                    <button class="btn btn-success btn-sm disabled"><i class="fas fa-check-circle me-1"></i> Hoàn thành khóa học</button>
                <?php endif; ?>
            </div>
        </div>
        
        
        <div class="col-lg-4">
            <div class="ot-card p-0">
                <div class="p-3 bg-light border-bottom border-top-0 border-end-0 border-start-0 rounded-top">
                    <h5 class="fw-bold mb-0">Nội dung khóa học</h5>
                </div>
                <div class="accordion accordion-flush" id="courseAccordion">
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $lessons = \Models\Web::courseUnitLesson($unit->id) ?? [];
                            $isActiveUnit = false;
                            foreach($lessons as $l) {
                                if($l->id == $data->id) $isActiveUnit = true;
                            }
                        ?>
                        <div class="accordion-item <?php echo e($index == 0 ? 'rounded-top' : ''); ?>">
                            <h2 class="accordion-header" id="heading<?php echo e($unit->id); ?>">
                                <button class="accordion-button <?php echo e($isActiveUnit ? '' : 'collapsed'); ?> bg-white fw-bold py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($unit->id); ?>" aria-expanded="<?php echo e($isActiveUnit ? 'true' : 'false'); ?>">
                                    <?php echo e($unit->name); ?>

                                </button>
                            </h2>
                            <div id="collapse<?php echo e($unit->id); ?>" class="accordion-collapse collapse <?php echo e($isActiveUnit ? 'show' : ''); ?>" data-bs-parent="#courseAccordion">
                                <div class="accordion-body p-0">
                                    <div class="list-group list-group-flush">
                                        <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="/lesson/<?php echo e($lesson->id); ?>" class="list-group-item list-group-item-action py-2 px-4 <?php echo e($lesson->id == $data->id ? 'active bg-primary text-white' : ''); ?>">
                                            <div class="d-flex align-items-center">
                                                <i class="fas fa-play<?php echo e($lesson->id == $data->id ? '' : '-circle'); ?> me-2 <?php echo e($lesson->id == $data->id ? 'text-white' : 'text-primary'); ?>"></i>
                                                <span class="small"><?php echo e($lesson->name); ?></span>
                                            </div>
                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    /**
     * Converts various YouTube URL formats to an embed URL
     */
    function formatVideoUrl(url) {
        if (!url) return '';
        let videoId = '';
        if (url.includes('youtube.com/watch?v=')) {
            videoId = url.split('v=')[1].split('&')[0];
        } else if (url.includes('youtu.be/')) {
            videoId = url.split('youtu.be/')[1].split('?')[0];
        } else if (url.includes('youtube.com/embed/')) {
            return url;
        }
        
        if (videoId) {
            return `https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1`;
        }
        
        // Handle Google Drive
        if (url.includes('drive.google.com')) {
            return url.replace('/view', '/preview');
        }
        
        return url;
    }

    /**
     * Changes the iframe source and updates button states
     */
    function changeVideo(btn, autoPlay = true) {
        const url = btn.getAttribute('data-url');
        const iframe = document.getElementById('mainVideoPlayer');
        if (!iframe) return;

        // Update active class on buttons
        document.querySelectorAll('.video-part-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        // Set iframe source
        let finalUrl = formatVideoUrl(url);
        if (autoPlay && !finalUrl.includes('autoplay=1')) {
            finalUrl += (finalUrl.includes('?') ? '&' : '?') + 'autoplay=1';
        }
        iframe.src = finalUrl;
        
        // Scroll slightly to player if it's a manual click
        if (autoPlay) {
            iframe.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    // Initialize the first video on page load
    window.addEventListener('DOMContentLoaded', () => {
        const firstBtn = document.querySelector('.video-part-btn');
        if (firstBtn) {
            changeVideo(firstBtn, false);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/lesson.blade.php ENDPATH**/ ?>