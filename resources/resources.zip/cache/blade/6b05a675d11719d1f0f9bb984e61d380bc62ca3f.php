<?php $__env->startSection('title', $data->name); ?>
<?php $__env->startSection('content'); ?>
<?php
    $units = \Models\Web::courseUnit($data->id) ?? [];
?>

<div class="container py-4">
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="ot-card p-4 mb-4">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/" class="text-decoration-none"><?php echo e(__('common.home')); ?></a></li>
                        <li class="breadcrumb-item"><a href="/courses" class="text-decoration-none"><?php echo e(__('common.courses')); ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($data->name); ?></li>
                    </ol>
                </nav>
                <h2 class="fw-bold fs-3 mb-3"><?php echo e($data->name); ?></h2>
                <div class="mb-4 text-muted">
                    <span class="me-3"><i class="fas fa-eye me-1"></i> <?php echo e(number_format($data->views ?? 0)); ?> <?php echo e(__('course.views')); ?></span>
                </div>
                
                <?php if($data->image): ?>
                <img src="<?php echo e($data->image); ?>" alt="<?php echo e($data->name); ?>" class="img-fluid rounded mb-4 w-100" style="max-height: 400px; object-fit: cover;">
                <?php endif; ?>
                
                <h5 class="fw-bold border-bottom pb-2 mb-3"><?php echo e(__('course.intro')); ?></h5>
                <div class="mb-4 content-body">
                    <?php echo $data->description ?? ''; ?>

                </div>
                
                <h5 class="fw-bold border-bottom pb-2 mb-3"><?php echo e(__('course.content_title')); ?></h5>
                <?php if(count($units) > 0): ?>
                <div class="accordion" id="courseAccordion">
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $lessons = \Models\Web::courseUnitLesson($unit->id) ?? [];
                        ?>
                        <div class="accordion-item mb-2 border rounded">
                            <h2 class="accordion-header" id="heading<?php echo e($unit->id); ?>">
                                <button class="accordion-button <?php echo e($index == 0 ? '' : 'collapsed'); ?> fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($unit->id); ?>" aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($unit->id); ?>">
                                    <?php echo e(__('course.part')); ?> <?php echo e($index + 1); ?>: <?php echo e($unit->name); ?> 
                                    <span class="badge bg-secondary ms-2"><?php echo e(count($lessons)); ?> <?php echo e(__('course.lessons_count')); ?></span>
                                </button>
                            </h2>
                            <div id="collapse<?php echo e($unit->id); ?>" class="accordion-collapse collapse <?php echo e($index == 0 ? 'show' : ''); ?>" aria-labelledby="heading<?php echo e($unit->id); ?>" data-bs-parent="#courseAccordion">
                                <div class="accordion-body p-0">
                                    <div class="list-group list-group-flush">
                                        <?php $__empty_1 = true; $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <a href="/lesson/<?php echo e($lesson->id); ?>" class="list-group-item list-group-item-action py-3">
                                            <div class="d-flex align-items-center">
                                                <i class="fas fa-play-circle text-primary fs-5 me-3"></i>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-0 fw-semibold"><?php echo e($lesson->name); ?></h6>
                                                    <?php if($lesson->description): ?>
                                                    <small class="text-muted"><?php echo e($lesson->description); ?></small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="p-3 text-muted text-center small"><?php echo e(__('course.no_lessons')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <div class="alert alert-info py-2"><?php echo e(__('course.updating')); ?></div>
                <?php endif; ?>
                
                <div class="mt-5">
                    <?php echo $__env->make('user.components.comment-box', ['type' => 'course', 'target_id' => $data->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="position-sticky" style="top: 80px;">
                <div class="ot-card p-4">
                    <h5 class="fw-bold mb-4 border-bottom pb-2"><?php echo e(__('course.info_title')); ?></h5>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-3 d-flex align-items-center">
                            <i class="fas fa-layer-group text-primary me-3 fs-5" style="width:24px;"></i>
                            <div>
                                <div class="small text-muted"><?php echo e(__('course.level')); ?></div>
                                <div class="fw-bold"><?php echo e($data->class_name ?? 'Lớp 12'); ?></div>
                            </div>
                        </li>
                        <li class="mb-3 d-flex align-items-center">
                            <i class="fas fa-book-open text-success me-3 fs-5" style="width:24px;"></i>
                            <div>
                                <div class="small text-muted"><?php echo e(__('course.subject')); ?></div>
                                <div class="fw-bold"><?php echo e($data->subject_name ?? 'Toán học'); ?></div>
                            </div>
                        </li>
                        <li class="mb-3 d-flex align-items-center">
                            <i class="fas fa-clock text-warning me-3 fs-5" style="width:24px;"></i>
                            <div>
                                <div class="small text-muted"><?php echo e(__('course.duration')); ?></div>
                                <div class="fw-bold"><?php echo e(__('course.lifetime')); ?></div>
                            </div>
                        </li>
                        <li class="mb-3 d-flex align-items-center">
                            <i class="fas fa-certificate text-danger me-3 fs-5" style="width:24px;"></i>
                            <div>
                                <div class="small text-muted"><?php echo e(__('course.certificate')); ?></div>
                                <div class="fw-bold"><?php echo e(__('course.has_certificate')); ?></div>
                            </div>
                        </li>
                    </ul>
                    
                    <div class="d-grid gap-2">
                        <?php if(count($units) > 0): ?>
                            <?php 
                                $firstUnit = $units[0];
                                $lessons = \Models\Web::courseUnitLesson($firstUnit->id) ?? [];
                                $firstLesson = $lessons[0] ?? null; 
                            ?>
                            <?php if($firstLesson): ?>
                                <a href="/lesson/<?php echo e($firstLesson->id); ?>" class="btn btn-ot-primary btn-lg shadow-sm">
                                    <?php echo e(__('course.start_study')); ?>

                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <button class="btn btn-secondary disabled btn-lg"><?php echo e(__('course.coming_soon')); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/course.blade.php ENDPATH**/ ?>