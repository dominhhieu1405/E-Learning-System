<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/assets/css/pages/exam-detail.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/" class="text-decoration-none"><?php echo e(__('common.home')); ?></a></li>
            <li class="breadcrumb-item"><a href="/exams" class="text-decoration-none"><?php echo e(__('common.exams')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($exam->title); ?></li>
        </ol>
    </nav>

    <div class="row g-4">
        
        <div class="col-lg-8">
            <div class="ot-card p-4 mb-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle mb-2"><?php echo e(strtoupper($exam->exam_type)); ?></span>
                        <h2 class="fw-bold mb-0 text-gradient-primary"><?php echo e($exam->title); ?></h2>
                    </div>
                    <?php if($exam->is_random): ?>
                        <span class="badge bg-warning text-white rounded-pill px-3 py-2 shadow-sm">
                            <i class="fas fa-random me-1"></i> <?php echo e(__('exams.random_exam')); ?>

                        </span>
                    <?php endif; ?>
                </div>

                <?php if(isset($_GET['error'])): ?>
                    <div class="alert alert-danger border-0 shadow-sm mb-4 d-flex align-items-center">
                        <i class="fas fa-exclamation-triangle me-3 fa-lg"></i>
                        <div><?php echo e(urldecode($_GET['error'])); ?></div>
                    </div>
                <?php endif; ?>

                <div class="row g-3 mb-4">
                    <div class="col-6 col-md-3">
                        <div class="p-3 bg-light rounded text-center h-100">
                            <div class="text-muted small mb-1"><?php echo e(__('exams.duration_label')); ?></div>
                            <div class="fw-bold fs-5">
                                <?php if($exam->exam_type === 'thpt'): ?>
                                    <?php echo e($exam->duration); ?>'
                                <?php else: ?>
                                    <?php echo e($exam->duration_p1 + $exam->duration_p2 + $exam->duration_p3); ?>'
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="p-3 bg-light rounded text-center h-100">
                            <div class="text-muted small mb-1"><?php echo e(__('exams.questions_count')); ?></div>
                            <div class="fw-bold fs-5"><?php echo e($question_count); ?></div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="p-3 bg-light rounded text-center h-100">
                            <div class="text-muted small mb-1"><?php echo e(__('exams.attempts_count')); ?></div>
                            <div class="fw-bold fs-5"><?php echo e($exam->attempt_limit > 0 ? $exam->attempt_limit : '∞'); ?></div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="p-3 bg-light rounded text-center h-100">
                            <div class="text-muted small mb-1"><?php echo e(__('exams.format_label')); ?></div>
                            <div class="fw-bold fs-5">Online</div>
                        </div>
                    </div>
                </div>

                <div class="exam-description content-body mb-4">
                    <h5 class="fw-bold mb-3 border-start border-4 border-primary ps-3"><?php echo e(__('exams.instruction_title')); ?></h5>
                    <?php echo $exam->description ?: '<p class="text-muted italic">'.__('exams.no_description').'</p>'; ?>

                    <ul class="mt-3 text-muted small">
                        <li><?php echo e(__('exams.tip_1')); ?></li>
                        <li><?php echo e(__('exams.tip_2')); ?></li>
                        <li><?php echo e(__('exams.tip_3')); ?></li>
                    </ul>
                </div>

                <div class="d-grid gap-2 d-md-flex">
                    <a href="/exam/<?php echo e($exam->id); ?>/start" class="btn btn-ot-primary btn-lg px-5 shadow-lg">
                        <i class="fas fa-play me-2"></i> <?php echo e(__('exams.start_exam_now')); ?>

                    </a>
                    <a href="/leaderboard/<?php echo e($exam->id); ?>" class="btn btn-ot-outline btn-lg px-4">
                        <i class="fas fa-medal me-2"></i> <?php echo e(__('exams.leaderboard')); ?>

                    </a>
                </div>
            </div>

            
            <div id="commentSection" class="mt-4">
                 <?php echo $__env->make('user.components.comment-box', ['type' => 'exam', 'target_id' => $exam->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        
        <div class="col-lg-4">
            
            <div class="ot-card p-4 mb-4">
                <h5 class="fw-bold mb-3 d-flex align-items-center">
                    <i class="fas fa-trophy text-warning me-2"></i> <?php echo e(__('exams.honor')); ?>

                </h5>
                <?php if(count($leaderboard) > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $leaderboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item px-0 border-0 d-flex justify-content-between align-items-center bg-transparent">
                                <div class="d-flex align-items-center">
                                    <span class="badge <?php echo e($index == 0 ? 'bg-warning' : ($index == 1 ? 'bg-secondary' : ($index == 2 ? 'bg-bronze' : 'bg-light text-dark'))); ?> rounded-circle me-3" style="width: 24px; height: 24px; line-height: 14px;"><?php echo e($index + 1); ?></span>
                                    <span class="small fw-600"><?php echo e($top->display_name); ?></span>
                                </div>
                                <span class="text-primary fw-bold"><?php echo e(round($top->total_score, 2)); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3 border-top pt-3 text-center">
                        <a href="/leaderboard/<?php echo e($exam->id); ?>" class="text-decoration-none small"><?php echo e(__('exams.view_all')); ?> <i class="fas fa-external-link-alt ms-1"></i></a>
                    </div>
                <?php else: ?>
                    <div class="text-center py-3 text-muted small italic"><?php echo e(__('exams.no_ranking')); ?></div>
                <?php endif; ?>
            </div>

            
            <div class="ot-card p-4 bg-primary text-white border-0 shadow-lg">
                <h5 class="fw-bold mb-3"><i class="fas fa-lightbulb me-2"></i> <?php echo e(__('exams.tips_title')); ?></h5>
                <p class="small opacity-75 mb-0"><?php echo e(__('exams.tips_desc')); ?></p>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/exam-detail.blade.php ENDPATH**/ ?>