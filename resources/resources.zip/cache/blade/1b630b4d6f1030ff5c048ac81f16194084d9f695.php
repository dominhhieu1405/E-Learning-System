

<?php $__env->startSection('content'); ?>
    <div class="card rounded border-0 mt-1 mb-2">
        <div class="card-body profile-header">
            <div class="d-flex align-items-center gap-2 mt-2">
                <div class="profile-pic m-0">
                    <img class="img-fluid img" src="<?php echo e(userget()->avatar_url); ?>" alt="profile">
                </div>
                <div class="profile-name d-flex align-items-center justify-content-between w-100">
                    <h4 class="theme-color">
                        <span class="badge bg-primary">VIP</span> <?php echo e(userget()->name); ?>

                        <br>
                        <small class="time-join">Tham gia từ <?php echo e(date('d/m/Y', strtotime(userget()->time_join))); ?></small>
                    </h4>
                    <span class="c-shopee p-1 fw-bold"><?php echo e(number_format(userget()->point)); ?> DP</span>
                </div>
            </div>
        </div>
    </div>

    <ul class="profile-list">
        <li>
            <a href="<?php echo e(url('profile.info')); ?>" class="profile-box">
                <div class="profile-details">
                    <h4>Thông tin tài khoản</h4>
                </div>
                <i class="ti ti-edit"></i>
            </a>
        </li>

        <li>
            <a href="<?php echo e(url("orders")); ?>" class="profile-box">
                <div class="profile-details">
                    <h4>Đơn hàng đã đặt</h4>
                </div>
                <i class="ti ti-shopping-cart"></i>
            </a>
        </li>

        <!--<li>
            <a href="<?php echo e(url("orders")); ?>" class="profile-box">
                <div class="profile-details">
                    <h4>Điểm đã nhận</h4>
                </div>
                <i class="ti ti-coin"></i>
            </a>
        </li>-->

        <li>
            <a href="<?php echo e(url("withdraw")); ?>" class="profile-box">
                <div class="profile-details">
                    <h4>Đổi thưởng</h4>
                </div>
                <i class="ti ti-building-bank"></i>
            </a>
        </li>
        <li>
            <a href="https://www.facebook.com/OnThi.io.vn" class="profile-box">
                <div class="profile-details">
                    <h4>Theo dõi trang facebook</h4>
                </div>
                <i class="ti ti-brand-facebook-filled"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('terms')); ?>" class="profile-box">
                <div class="profile-details">
                    <h4>Điều khoản &amp; chính sách</h4>
                </div>
                <i class="ti ti-alert-circle-filled"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('faqs')); ?>" class="profile-box">
                <div class="profile-details">
                    <h4>Câu hỏi thường gặp</h4>
                </div>
                <i class="ti ti-info-circle"></i>
            </a>
        </li>

        <li>
            <a href="<?php echo e(url('logout')); ?>" class="profile-box">
                <div class="profile-details">
                    <h4>Đăng xuất</h4>
                </div>
                <i class="ti ti-logout"></i>
            </a>
        </li>

    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\dealhot.com\resources\views/user/pages/profile.blade.php ENDPATH**/ ?>