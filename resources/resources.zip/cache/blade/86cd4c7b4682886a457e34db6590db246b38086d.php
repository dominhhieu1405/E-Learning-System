<?php $__env->startSection('title', __('terms.title')); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/assets/css/pages/terms.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="terms-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="terms-card">
                    <h1 class="text-center mb-4 fw-bold"><?php echo e(__('terms.heading')); ?></h1>
                    <div class="terms-content">
                        <p class="lead"><?php echo e(__('terms.welcome')); ?></p>
                        
                        <h2><?php echo e(__('terms.sections.s1_title')); ?></h2>
                        <p><?php echo e(__('terms.sections.s1_content')); ?></p>

                        <h2><?php echo e(__('terms.sections.s2_title')); ?></h2>
                        <p><?php echo e(__('terms.sections.s2_content')); ?></p>

                        <h2><?php echo e(__('terms.sections.s3_title')); ?></h2>
                        <ul>
                            <li><?php echo e(__('terms.sections.s3_list.l1')); ?></li>
                            <li><?php echo e(__('terms.sections.s3_list.l2')); ?></li>
                            <li><?php echo e(__('terms.sections.s3_list.l3')); ?></li>
                        </ul>

                        <h2><?php echo e(__('terms.sections.s4_title')); ?></h2>
                        <p><?php echo e(__('terms.sections.s4_content')); ?></p>

                        <h2><?php echo e(__('terms.sections.s5_title')); ?></h2>
                        <p><?php echo e(__('terms.sections.s5_content')); ?></p>

                        <h2><?php echo e(__('terms.sections.s6_title')); ?></h2>
                        <p><?php echo e(__('terms.sections.s6_content')); ?></p>

                        <div class="mt-5 text-center text-muted small">
                            <?php echo e(__('terms.last_updated')); ?><?php echo e(date('d/m/Y')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/terms.blade.php ENDPATH**/ ?>