

<?php $__env->startSection('css_plugins'); ?>
    <style>
        td img {
            max-width: 72px;
            max-height: 72px;
            margin: 2px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0"><?php echo e($course->name); ?></h4>

                        <div class="page-title-right d-none d-lg-block">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a>
                                </li>
                                <li class="breadcrumb-item active">Khóa học</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Main content -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">
                                Danh sách bài học
                                <div class="float-right btn-group">
                                    <a class="btn btn-sm btn-success float-right" href="#" data-toggle="modal" data-target="#addUnitModal">
                                        <i class="fas fa-plus"></i>
                                        Chương
                                    </a>
                                    <a href="<?php echo e(url("admin.course.lesson.add", ["id" => $course->id])); ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-plus"></i>
                                        Bài học
                                    </a>
                                    <?php if(\Models\User::isAdmin()): ?>
                                        <a href="<?php echo e(url("admin.course.lesson.bulk-add", ["id" => $course->id])); ?>" class="btn btn-sm btn-dark">
                                            <i class="fas fa-plus"></i>
                                            Thêm nhiều bài học
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </h4>

                            <form class="mb-2" type="POST" action="">
                                <div class="input-group">
                                    <!-- /btn-group -->
                                    <input type="text" class="form-control" name="search" id="search-course" value="" placeholder="Tìm kiếm bài học..." aria-label="">
                                    <span class="input-group-append">
                                        <button type="submit" class="btn btn-info btn-flat">Reset</button>
                                    </span>
                                </div>
                            </form>

                            <div id="table_wrapper">
                                <div class="row">
                                    <div class="col-sm-12 table-responsive">
                                        <table id="table" style=" min-width: 700px; " class="table table-bordered table-hover dataTable dtr-inline" role="grid" aria-describedby="table">
                                            <thead>
                                            <tr>
                                                <th style="width: 60px;">#</th>
                                                <th>Tên</th>
                                                <th style="width: 80px;">Lượt xem</th>
                                                <th style="width: 150px;">Cập nhật</th>
                                                <th style="width: 123px"></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php if($units && count($units) > 0): ?>
                                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr data-id="unit-<?php echo e($unit->id); ?>" class="course-unit">
                                                        <th colspan="4">
                                                            <h5><b><?php echo e(intToRoman(++$i)); ?>. <span id="unit-<?php echo e($unit->id); ?>-name"><?php echo e($unit->name); ?></span></b></h5>
                                                        </th>
                                                        <td class="text-center">
                                                            <div class="pt-1"></div>
                                                            <button type="button" class="btn btn-info btn-sm edit-unit" data-id="<?php echo e($unit->id); ?>">
                                                                Sửa
                                                            </button>
                                                            <button type="button" class="btn btn-danger btn-sm delete-unit" data-id="<?php echo e($unit->id); ?>">
                                                                Xóa
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    <?php $__currentLoopData = \Models\Web::courseUnitLesson($unit->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j => $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr data-id="lesson-<?php echo e($lesson->id); ?>" class="course-lesson course-unit-<?php echo e($unit->id); ?>">
                                                            <td><?php echo e($j+1); ?></td>
                                                            <td class="lesson-name"><?php echo e($lesson->name); ?></td>
                                                            <td><?php echo e(number_format($lesson->views)); ?></td>
                                                            <td><?php echo e(date("d/m/y H:i", strtotime($lesson->time_update))); ?></td>
                                                            <td>
                                                                <a href="<?php echo e(url("admin.course.lesson.edit", ["id" => $lesson->id])); ?>" type="button" class="btn btn-success btn-sm" data-id="<?php echo e($lesson->id); ?>">
                                                                    Sửa
                                                                </a>
                                                                <button type="button" class="btn btn-dark btn-sm delete-lesson" data-id="<?php echo e($lesson->id); ?>">
                                                                    Xóa
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <td colspan="5">
                                                    <div class="d-flex justify-content-center ">
                                                        Chưa có phần nào...
                                                    </div>
                                                </td>
                                            <?php endif; ?>
                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>


    <div class="modal fade" id="addUnitModal" tabindex="-1" aria-labelledby="addUnitModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUnitModalLabel">Thêm chương</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="mb-3" id="inputFields">
                        <label for="addName">Tên chương:</label>
                        <input type="text" id="addName" class="form-control" placeholder="Không cần nhập số thứ tự ở đầu, hệ thống tự thêm">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="addUnit">Lưu</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editUnitModal" tabindex="-1" aria-labelledby="editUnitModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUnitModalLabel">Sửa chương</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="editIndex">
                    <div class="mb-3" id="inputFields">
                        <label for="editName">Tên chương:</label>
                        <input type="text" id="editName" class="form-control" placeholder="Không cần nhập số thứ tự ở đầu, hệ thống tự thêm">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="editUnit">Lưu</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript_plugins'); ?>
    <script>
        $(function (){
            $("#addUnit").on("click", function (){
                let $name = $("#addName").val();
                $.post("<?php echo e(url("ajax.admin.course.unit.add")); ?>", {course: "<?php echo e($course->id); ?>", name: $name}, function (data){
                    if(data.status){
                        $("#addUnitModal").modal("hide");
                        $("#table tbody").append(`
                            <tr data-id="unit-${data.id}" class="course-unit">
                                <th colspan="4">
                                    <h5><b><span id="unit-${data.id}-name">${data.name}</span></b></h5>
                                </th>
                                <td class="text-center">
                                    <div class="pt-1"></div>
                                    <button type="button" class="btn btn-info btn-sm edit-unit" data-id="${data.id}">
                                        Sửa
                                    </button>
                                    <button type="button" class="btn btn-danger btn-sm delete-unit" data-id="${data.id}">
                                        Xóa
                                    </button>
                                </td>
                            </tr>
                        `)
                        toastr["success"]("Đã thêm chương", "Thông báo");
                    }else{
                        toastr["error"]("Có lỗi xảy ra", "Thông báo");
                    }
                })
            });
            $("#editUnit").on("click", function (){
                let $id = $("#editIndex").val();
                let $name = $("#editName").val();
                $.post("<?php echo e(url("ajax.admin.course.unit.edit")); ?>", {id: $id, name: $name}, function (data){
                    if(data.status){
                        $("#editUnitModal").modal("hide");
                        $("#unit-"+$id+"-name").text($name);
                        toastr["success"]("Đã sửa chương", "Thông báo");
                    }else{
                        toastr["error"]("Có lỗi xảy ra", "Thông báo");
                    }
                })
            });

            $(document).on("click", ".edit-unit", function (){
                let $id = $(this).data("id");
                let $name = $("#unit-"+$id+"-name").text();
                $("#editIndex").val($id);
                $("#editName").val($name);
                $("#editUnitModal").modal("show");
            })

            $(document).on("click", ".delete-unit", function (){
                var id = $(this).data("id");
                if(confirm("Bạn có chắc chắn muốn xóa chương này không?")){
                    $.post("<?php echo e(url("ajax.admin.course.unit.delete")); ?>", {id: id}, function (data){
                        if(data.status){
                            $("tr[data-id=unit-"+id+"]").remove();
                            $(".course-unit-"+id).remove();
                            toastr["success"]("Đã xóa chương", "Thông báo");
                        }else{
                            toastr["error"]("Có lỗi xảy ra", "Thông báo");
                        }
                    })
                }
            })
            $(document).on("click", ".delete-lesson", function (){
                var id = $(this).data("id");
                if(confirm("Bạn có chắc chắn muốn xóa bài này không?")){
                    $.post("<?php echo e(url("ajax.admin.course.lesson.delete")); ?>", {id: id}, function (data){
                        if(data.status){
                            $("tr[data-id=lesson-"+id+"]").remove();
                            toastr["success"]("Đã xóa bài", "Thông báo");
                        }else{
                            toastr["error"]("Có lỗi xảy ra", "Thông báo");
                        }
                    })
                }
            })
            $("#search-course").on("keyup", function (){
                var value = $(this).val().toLowerCase();
                $("#table tr.course-lesson").filter(function (){
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/course.blade.php ENDPATH**/ ?>