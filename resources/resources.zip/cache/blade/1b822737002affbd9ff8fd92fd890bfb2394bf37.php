<!DOCTYPE html>
<html lang="vi">
<head>
    <meta http-equiv="Content-Type" content="#; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="OnThi.io.vn"/>
    <meta name="keywords" content="OnThi.io.vn"/>
    <meta name="author" content="OnThi.io.vn"/>
    <link rel="manifest" href="manifest.json"/>
    <link rel="icon" href="/assets/img/logo/favicon.png" type="image/x-icon"/>
    <title><?php echo $__env->yieldContent('title', 'Trang chủ'); ?></title>
    <link rel="apple-touch-icon" href="/assets/img/logo/favicon.png"/>
    <meta name="theme-color" content="#122636"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta name="apple-mobile-web-app-title" content="OnThi.io.vn"/>
    <meta name="msapplication-TileImage" content="/assets/img/logo/favicon.png"/>

    <meta name="msapplication-TileColor" content="#FFFFFF"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>

    <!--Google font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap" rel="stylesheet">

    <!-- tabler icon css -->
    <link rel="stylesheet" type="text/css" href="/assets/css/tabler-icons.min.css">

    <!-- swiper css -->
    <link rel="stylesheet" type="text/css" href="/assets/css/vendors/swiper-bundle.min.css"/>

    <!-- bootstrap css -->
    <link rel="stylesheet" id="rtl-link" type="text/css" href="/assets/css/vendors/bootstrap.min.css"/>
    <!-- Theme css -->
    <link rel="stylesheet" type="text/css" href="/assets/css/style.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/css/custom.css"/>

    <?php echo $__env->yieldContent('css_plugins'); ?>
</head>

<body>

<?php echo $__env->make('user.widget.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('user.widget.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- .page-content-wrapper start -->
<div class="page-content-wrapper">
    <!-- container -->
    <div class="custom-container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- container end -->
</div>
<!-- .page-content-wrapper end -->


<?php if(isset($navbar)): ?>
    <?php echo $__env->make('user.widget.bottom-navbar', ['active' => $navbar], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<!-- swiper js -->
<script src="/assets/js/swiper-bundle.min.js"></script>
<script src="/assets/js/custom-swiper.js"></script>

<!-- bootstrap js -->
<script src="/assets/js/jquery.min.js"></script>
<script src="/assets/js/bootstrap.bundle.min.js"></script>

<!-- script js -->
<script src="/assets/js/script.js"></script>
<script src="/assets/js/md5.js"></script>
<script src="/assets/js/pwa.js"></script>
<?php echo $__env->yieldContent('javascript_plugins'); ?>
</body>
</html>
<?php /**PATH D:\localhost\dealhot.com\resources\views/user/layout/layout.blade.php ENDPATH**/ ?>