<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/assets/css/pages/vip.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="vip-container">
        <div class="container">
            <div class="text-center mb-5">
                <h1 class="display-4 fw-bold"><?php echo e(__('vip.title')); ?></h1>
                <p class="lead text-muted"><?php echo e(__('vip.subtitle')); ?></p>

                <div class="btn-group btn-group-period mt-4" role="group">
                    <button type="button" class="btn btn-outline-primary active" data-period="1"><?php echo e(__('vip.period_1')); ?></button>
                    <button type="button" class="btn btn-outline-primary" data-period="3"><?php echo e(__('vip.period_3')); ?></button>
                    <button type="button" class="btn btn-outline-primary" data-period="6"><?php echo e(__('vip.period_6')); ?></button>
                </div>
            </div>

            <div class="row g-4 align-items-center">
                <!-- Free -->
                <div class="col-lg-4">
                    <div class="pricing-card">
                        <div class="pricing-header">
                            <h4>FREE</h4>
                            <div class="price-value">0đ<small><?php echo e(__('vip.month')); ?></small></div>
                        </div>
                        <div class="pricing-body">
                            <ul class="pricing-features">
                                <li><i class="ri-checkbox-circle-fill text-success"></i> <?php echo e(__('vip.free_plan.public_exams')); ?></li>
                                <li><i class="ri-checkbox-circle-fill text-success"></i> <?php echo e(__('vip.free_plan.results')); ?></li>
                                <li><i class="ri-time-line text-warning"></i> <?php echo e(__('vip.free_plan.history_7')); ?></li>
                                <li><i class="ri-close-circle-fill text-danger"></i> <?php echo e(__('vip.free_plan.no_explanations')); ?></li>
                                <li><i class="ri-close-circle-fill text-danger"></i> <?php echo e(__('vip.free_plan.ads')); ?></li>
                            </ul>
                            <button class="btn btn-outline-secondary btn-upgrade disabled"><?php echo e(__('vip.free_plan.using')); ?></button>
                        </div>
                    </div>
                </div>

                <!-- Plus -->
                <div class="col-lg-4">
                    <div class="pricing-card featured">
                        <div class="pricing-header">
                            <div class="badge bg-white text-primary mb-2 px-3 py-2 rounded-pill"><?php echo e(__('vip.plus_plan.popular')); ?></div>
                            <h4>PLUS</h4>
                            <div class="price-value" id="price-plus">25.000đ<small><?php echo e(__('vip.month')); ?></small></div>
                        </div>
                        <div class="pricing-body">
                            <ul class="pricing-features">
                                <li><i class="ri-checkbox-circle-fill text-success"></i> <?php echo e(__('vip.plus_plan.explanations')); ?></li>
                                <li><i class="ri-checkbox-circle-fill text-success"></i> <?php echo e(__('vip.plus_plan.history_90')); ?></li>
                                <li><i class="ri-checkbox-circle-fill text-success"></i> <?php echo e(__('vip.plus_plan.flashcard')); ?></li>
                                <li><i class="ri-checkbox-circle-fill text-success"></i> <?php echo e(__('vip.plus_plan.basic_stats')); ?></li>
                                <li><i class="ri-robot-2-line text-primary"></i> <strong><?php echo e(__('vip.plus_plan.ai_limited')); ?></strong>
                                </li>
                                <li><i class="ri-star-fill text-warning"></i> <?php echo e(__('vip.plus_plan.no_ads')); ?></li>
                            </ul>
                            <a href="<?php echo e(url('vip.upgrade', ['id' => 'plus_1'])); ?>" class="btn btn-light btn-upgrade"
                                id="btn-plus"><?php echo e(__('vip.plus_plan.register')); ?></a>
                        </div>
                    </div>
                </div>

                <!-- Pro -->
                <div class="col-lg-4">
                    <div class="pricing-card">
                        <div class="pricing-header">
                            <h4>PRO</h4>
                            <div class="price-value" id="price-pro">50.000đ<small><?php echo e(__('vip.month')); ?></small></div>
                        </div>
                        <div class="pricing-body">
                            <ul class="pricing-features">
                                <li><i class="ri-checkbox-circle-fill text-success"></i> <?php echo e(__('vip.pro_plan.history_unlimited')); ?></li>
                                <li><i class="ri-checkbox-circle-fill text-success"></i> <?php echo e(__('vip.pro_plan.deep_analysis')); ?></li>
                                <li><i class="ri-robot-2-line text-primary"></i> <strong><?php echo e(__('vip.pro_plan.ai_unlimited')); ?></strong></li>
                                <li><i class="ri-magic-line text-info"></i> <?php echo e(__('vip.pro_plan.auto_pick')); ?></li>
                                <li><i class="ri-flashlight-fill text-warning"></i> <?php echo e(__('vip.pro_plan.all_resources')); ?></li>
                            </ul>
                            <a href="<?php echo e(url('vip.upgrade', ['id' => 'pro_1'])); ?>" class="btn btn-primary btn-upgrade"
                                id="btn-pro"><?php echo e(__('vip.pro_plan.register')); ?></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Benefit Table -->
            <div class="benefit-table pb-5">
                <h2 class="text-center mb-4"><?php echo e(__('vip.comparison.title')); ?></h2>
                <div class="table-responsive">
                    <table class="table table-bordered table-vip shadow-sm">
                        <thead>
                            <tr>
                                <th width="40%"><?php echo e(__('vip.comparison.feature')); ?></th>
                                <th width="20%">Free</th>
                                <th width="20%">Plus</th>
                                <th width="20%">Pro</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e(__('vip.comparison.take_exam')); ?></td>
                                <td>✅</td>
                                <td>✅</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.view_answers')); ?></td>
                                <td>✅</td>
                                <td>✅</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.view_docs')); ?></td>
                                <td>✅</td>
                                <td>✅</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.view_courses')); ?></td>
                                <td>✅</td>
                                <td>✅</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.unlimited_practice')); ?></td>
                                <td>✅</td>
                                <td>✅</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.random_exam')); ?></td>,StartLine:133,TargetContent:
                                <td>✅</td>
                                <td>✅</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.explanations')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus">✅</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.history')); ?></td>
                                <td><?php echo e(__('vip.comparison.7_days')); ?></td>
                                <td class="highlight-plus"><?php echo e(__('vip.comparison.90_days')); ?></td>
                                <td><?php echo e(__('vip.comparison.unlimited')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.skill_stats')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus">✅</td>
                                <td><?php echo e(__('vip.comparison.advanced')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.weakness_analysis')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus">❌</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.ai_explanation')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus"><?php echo e(__('vip.comparison.limit_turns')); ?></td>
                                <td><?php echo e(__('vip.comparison.unlimited')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.ai_qa')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus"><?php echo e(__('vip.comparison.limit_turns')); ?></td>
                                <td><?php echo e(__('vip.comparison.unlimited')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.ai_topic_gen')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus"><?php echo e(__('vip.comparison.limit_turns')); ?></td>
                                <td><?php echo e(__('vip.comparison.unlimited')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.ai_weakness_gen')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus">❌</td>
                                <td>✅</td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.flashcard_summary')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus"><?php echo e(__('vip.comparison.one_part')); ?></td>
                                <td><?php echo e(__('vip.comparison.full')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('vip.comparison.no_ads')); ?></td>
                                <td>❌</td>
                                <td class="highlight-plus">✅</td>
                                <td>✅</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(function () {
            const prices = {
                plus: { 1: <?php echo e($settings['plus_price_1m']); ?>, 3: <?php echo e($settings['plus_price_3m']); ?>, 6: <?php echo e($settings['plus_price_6m']); ?> },
                pro: { 1: <?php echo e($settings['pro_price_1m']); ?>, 3: <?php echo e($settings['pro_price_3m']); ?>, 6: <?php echo e($settings['pro_price_6m']); ?> }
            };

            $('.btn-group-period .btn').on('click', function (e) {
                e.preventDefault();
                $('.btn-group-period .btn').removeClass('active');
                $(this).addClass('active');
                
                const period = parseInt($(this).data('period'));
                console.log('Switching to period:', period);

                const pPlus = prices.plus[period];
                const pPro = prices.pro[period];

                if (pPlus && pPro) {
                    $('#price-plus').html(pPlus.toLocaleString('vi-VN') + 'đ<small><?php echo e(__('vip.month')); ?></small>');
                    $('#price-pro').html(pPro.toLocaleString('vi-VN') + 'đ<small><?php echo e(__('vip.month')); ?></small>');

                    $('#btn-plus').attr('href', '/vip/upgrade/plus_' + period);
                    $('#btn-pro').attr('href', '/vip/upgrade/pro_' + period);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/vip.blade.php ENDPATH**/ ?>