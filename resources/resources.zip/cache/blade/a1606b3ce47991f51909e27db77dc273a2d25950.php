<?php $__env->startSection('title', __('exams.title')); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="section-header">
        <h2><?php echo e(__('exams.heading')); ?></h2>
    </div>

    
    <div class="d-flex gap-2 mb-4 flex-wrap">
        <a href="/exams" class="btn <?php echo e(!$type ? 'btn-ot-primary' : 'btn-ot-outline'); ?> btn-sm"><?php echo e(__('exams.all')); ?></a>
        <a href="/exams?type=thpt" class="btn <?php echo e($type === 'thpt' ? 'btn-ot-primary' : 'btn-ot-outline'); ?> btn-sm">THPT 2025</a>
        <a href="/exams?type=hsa" class="btn <?php echo e($type === 'hsa' ? 'btn-ot-primary' : 'btn-ot-outline'); ?> btn-sm">HSA</a>
    </div>

    <div class="row g-4">
        <?php if($exams && count($exams) > 0): ?>
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="exam-card <?php echo e($exam->exam_type); ?>">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <span class="exam-type-badge <?php echo e($exam->exam_type); ?>">
                            <?php echo e(strtoupper($exam->exam_type)); ?>

                        </span>
                        <?php if($exam->is_random): ?>
                            <span class="badge bg-warning text-dark"><i class="fas fa-random"></i> <?php echo e(__('exams.random')); ?></span>
                        <?php endif; ?>
                    </div>
                    <h5 class="fw-bold mb-2"><?php echo e($exam->title); ?></h5>
                    <div class="exam-meta">
                        <?php if($exam->exam_type === 'thpt'): ?>
                            <span><i class="fas fa-clock"></i> <?php echo e($exam->duration); ?> <?php echo e(__('exams.minutes')); ?></span>
                        <?php else: ?>
                            <span><i class="fas fa-clock"></i> <?php echo e($exam->duration_p1 + $exam->duration_p2 + $exam->duration_p3); ?> <?php echo e(__('exams.minutes')); ?></span>
                            <span><i class="fas fa-layer-group"></i> 3 <?php echo e(__('exams.parts')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mt-3">
                        <a href="/exam/<?php echo e($exam->id); ?>" class="btn btn-ot-primary btn-sm w-100">
                            <i class="fas fa-play"></i> <?php echo e(__('exams.start_exam')); ?>

                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-12">
                <div class="text-center py-5 text-muted">
                    <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                    <p><?php echo e(__('exams.no_exams')); ?></p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/exams.blade.php ENDPATH**/ ?>