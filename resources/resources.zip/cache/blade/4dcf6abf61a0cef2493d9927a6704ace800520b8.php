<footer class="footer">
    <div class="container-fluid">
        <div class="row text-center">
            <div class="col-12">
                &copy; <?php echo e(date("Y")); ?> Luce
                -
                Made with <i class="mdi mdi-heart text-danger"></i>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\localhost\DGNL\resources\views/admin/components/footer.blade.php ENDPATH**/ ?>