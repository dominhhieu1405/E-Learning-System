<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8"/>
    <title>Đăng nhập hệ thống</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- App favicon -->
    <link rel="shortcut icon" href="/assets/admin/images/favicon.ico">

    <!-- Bootstrap Css -->
    <link href="/assets/admin/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css"/>
    <!-- Icons Css -->
    <link href="/assets/admin/css/icons.min.css" rel="stylesheet" type="text/css"/>
    <!-- App Css-->
    <link href="/assets/admin/css/app.min.css" id="app-style" rel="stylesheet" type="text/css"/>

</head>

<body class="auth-body-bg">
<div>
    <div class="container-fluid p-0">
        <div class="row no-gutters">
            <div class="col-lg-4"></div>
            <div class="col-lg-4">
                <div class="authentication-page-content p-4 d-flex align-items-center min-vh-100">
                    <div class="w-100">
                        <div class="row justify-content-center">
                            <div class="col-lg-9">
                                <div>
                                    <div class="text-center">
                                        <div>
                                            <a href="/" class="logo"><img src="/assets/admin/images/logo-dark.png" height="" style="height: 30px" alt="logo"></a>
                                        </div>

                                        <h4 class="font-size-18 mt-4">Chào mừng !</h4>
                                        <p class="text-muted">Đăng nhập vào hệ thống admin.</p>
                                    </div>

                                    <div class="p-2 mt-5">
                                        <form class="form-horizontal" action="#">

                                            <div class="form-group auth-form-group-custom mb-4">
                                                <i class="ri-user-2-line auti-custom-input-icon"></i>
                                                <label for="username">Tài khoản</label>
                                                <input type="text" class="form-control" id="username" placeholder="Enter username">
                                            </div>

                                            <div class="form-group auth-form-group-custom mb-4">
                                                <i class="ri-lock-2-line auti-custom-input-icon"></i>
                                                <label for="password">Mật khẩu</label>
                                                <input type="password" class="form-control" id="password" placeholder="Enter password">
                                            </div>

                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="remember">
                                                <label class="custom-control-label" for="remember">Giữ đăng nhập?</label>
                                            </div>

                                            <div class="mt-4 text-center">
                                                <button class="btn btn-primary w-md waves-effect waves-light" type="submit" id="loginBtn">Đăng nhập</button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="mt-5 text-center">
                                        <p>© 2025 - <?php echo e(date('Y')); ?> made with <i class="mdi mdi-heart text-danger"></i> by
                                            <b>Luce</b></p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
</div>


<!-- JAVASCRIPT -->
<script src="/assets/admin/libs/jquery/jquery.min.js"></script>
<script src="/assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
    $(function (){
        $("#loginBtn").on("click", function(){
            let username = $("#username").val().trim();
            let password = $("#password").val().trim();
            let remember = $("#remember").checked
            if (username.length < 4) {
                alert("Tên tài khoản tối thiểu 4 ký tự!")
                return;
            }
            if (password.length < 6) {
                alert("Mật khẩu tối thiểu 6 ký tự!")
                return;
            }
            $.post(
                "<?php echo e(url("ajax.login")); ?>",
                {
                    username: username,
                    password: password,
                    remember: remember
                }, function (e){
                    console.log(e);
                    alert(e.message)
                    if (e.status) {
                        window.location.href = "/admin";
                    }
                }, 'json'
            )
        })
    })
</script>
</body>
</html>
<?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/login.blade.php ENDPATH**/ ?>