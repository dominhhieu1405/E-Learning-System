<?php $__env->startSection('title', 'Hỏi đáp (FAQ) - OnThi.io.vn'); ?>

<?php $__env->startSection('css'); ?>
<style>
    .faq-container {
        padding: 60px 0;
        background: var(--ot-bg);
    }
    .faq-card {
        background: var(--ot-bg-card);
        border-radius: var(--ot-radius);
        border: 1px solid var(--ot-border);
        padding: 40px;
        box-shadow: var(--ot-shadow);
    }
    .accordion-item {
        border: 1px solid var(--ot-border);
        margin-bottom: 10px;
        border-radius: var(--ot-radius-sm) !important;
        overflow: hidden;
    }
    .accordion-button:not(.collapsed) {
        background-color: rgba(99, 102, 241, 0.05);
        color: var(--ot-primary);
        box-shadow: none;
    }
    .accordion-button {
        font-weight: 600;
        color: var(--ot-text);
    }
    .accordion-body {
        color: var(--ot-text-muted);
        line-height: 1.7;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="faq-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="faq-card">
                    <h1 class="text-center mb-2 fw-bold">Câu hỏi thường gặp</h1>
                    <p class="text-center text-muted mb-5">Giải đáp những thắc mắc phổ biến nhất khi sử dụng OnThi.io.vn</p>

                    <div class="accordion" id="faqAccordion">
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                    Làm thế nào để đăng ký tài khoản?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Bạn có thể đăng ký tài khoản bằng cách nhấn vào nút "Đăng ký" ở góc trên bên phải màn hình. Chỉ cần nhập tên tài khoản, mật khẩu và email là bạn đã có thể bắt đầu sử dụng hệ thống.
                                </div>
                            </div>
                        </div>

                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                    Gói VIP Plus và Pro có gì khác nhau?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    - <strong>Gói Plus</strong>: Phù hợp cho ôn tập cơ bản, hỗ trợ lời giải chi tiết và giới hạn lượt dùng AI trợ giúp.<br>
                                    - <strong>Gói Pro</strong>: Là gói cao cấp nhất, cung cấp mọi tính năng AI không giới hạn, phân tích điểm yếu chuyên sâu và tự động bốc đề theo lỗ hổng kiến thức.
                                </div>
                            </div>
                        </div>

                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                    Tôi có thể xem lại lịch sử bài làm không?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Có, bạn có thể xem lại toàn bộ lịch sử thi và học tập trong mục "Trang cá nhân". Thời gian lưu trữ phụ thuộc vào gói thành viên của bạn (7 ngày cho Free, 90 ngày cho Plus và Trọn đời cho Pro).
                                </div>
                            </div>
                        </div>

                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                    AI của hệ thống hỗ trợ những gì?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    AI của chúng tôi có thể giải thích chi tiết các câu hỏi khó, tóm tắt nội dung bài đọc, hỗ trợ hỏi đáp kiến thức 24/7 và đặc biệt là phân tích kết quả thi của bạn để chỉ ra những chủ đề bạn đang còn yếu.
                                </div>
                            </div>
                        </div>

                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                                    Nếu gặp lỗi khi thanh toán tôi cần làm gì?
                                </button>
                            </h2>
                            <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Nếu gặp bất kỳ vấn đề gì về thanh toán hoặc kích hoạt tài khoản, bạn vui lòng liên hệ ngay với chúng tôi qua nút "Liên hệ" ở Footer hoặc gửi email trực tiếp đến bộ phận hỗ trợ kỹ thuật.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/faqs.blade.php ENDPATH**/ ?>