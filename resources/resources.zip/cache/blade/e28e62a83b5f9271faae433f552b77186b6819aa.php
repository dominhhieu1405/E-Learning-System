<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="mb-0">Cài đặt Website</h4>
                </div>
            </div>
        </div>
        
        <form id="formSettings">
            <div class="row">
                <!-- General Settings -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-4">Cài đặt Chung</h5>
                            <div class="mb-3">
                                <label class="form-label">Tên Website</label>
                                <input type="text" name="site_name" class="form-control" value="<?php echo e($settings['site_name']); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email liên hệ</label>
                                <input type="email" name="contact_email" class="form-control" value="<?php echo e($settings['contact_email']); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Số điện thoại</label>
                                <input type="text" name="contact_phone" class="form-control" value="<?php echo e($settings['contact_phone']); ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- VIP Pricing -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-4">Cài đặt Gói VIP</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-success fw-bold">Gói PLUS (1 Tháng)</label>
                                    <input type="number" name="plus_price_1m" class="form-control text-success" value="<?php echo e($settings['plus_price_1m']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-primary fw-bold">Gói PRO (1 Tháng)</label>
                                    <input type="number" name="pro_price_1m" class="form-control text-primary" value="<?php echo e($settings['pro_price_1m']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Gói PLUS (3 Tháng/tháng)</label>
                                    <input type="number" name="plus_price_3m" class="form-control" value="<?php echo e($settings['plus_price_3m']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Gói PRO (3 Tháng/tháng)</label>
                                    <input type="number" name="pro_price_3m" class="form-control" value="<?php echo e($settings['pro_price_3m']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Gói PLUS (6+ Tháng/tháng)</label>
                                    <input type="number" name="plus_price_6m" class="form-control" value="<?php echo e($settings['plus_price_6m']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Gói PRO (6+ Tháng/tháng)</label>
                                    <input type="number" name="pro_price_6m" class="form-control" value="<?php echo e($settings['pro_price_6m']); ?>">
                                </div>
                            </div>
                            <div class="alert alert-soft-info mt-2">
                                <i class="ri-information-line me-1"></i> Giá được tính trên mỗi tháng cho người dùng dễ so sánh.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- AI Configuration -->
                <div class="col-12">
                    <div class="card border-0" style="background: linear-gradient(135deg, #667eea11, #764ba211);">
                        <div class="card-body">
                            <h5 class="card-title mb-4">
                                <i class="ri-robot-line text-primary me-2"></i>Cấu hình AI Tạo Đề Tự Động
                            </h5>
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label fw-semibold">Provider</label>
                                    <select name="ai_provider" id="aiProvider" class="form-control custom-select">
                                        <option value="gemini" <?php echo e(($settings['ai_provider'] ?? '') === 'gemini' ? 'selected' : ''); ?>>Google Gemini</option>
                                        <option value="openai" <?php echo e(($settings['ai_provider'] ?? '') === 'openai' ? 'selected' : ''); ?>>OpenAI / ChatGPT</option>
                                        <option value="custom" <?php echo e(($settings['ai_provider'] ?? '') === 'custom' ? 'selected' : ''); ?>>Custom (OpenAI-compatible)</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label fw-semibold">Model</label>
                                    <input type="text" name="ai_model" class="form-control"
                                        value="<?php echo e($settings['ai_model'] ?? 'gemini-1.5-pro'); ?>"
                                        placeholder="vd: gemini-1.5-pro, gpt-4o">
                                </div>
                                <div class="col-md-6 mb-3" id="aiEndpointGroup" style="<?php echo e(($settings['ai_provider'] ?? 'gemini') !== 'custom' ? 'display:none' : ''); ?>">
                                    <label class="form-label fw-semibold">Custom Endpoint URL</label>
                                    <input type="text" name="ai_endpoint" class="form-control"
                                        value="<?php echo e($settings['ai_endpoint'] ?? ''); ?>"
                                        placeholder="https://api.example.com/v1/chat/completions">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">API Key</label>
                                    <div class="input-group">
                                        <input type="password" name="ai_key" id="aiKeyInput" class="form-control"
                                            value="<?php echo e($settings['ai_key'] ?? ''); ?>"
                                            placeholder="Nhập API Key...">
                                        <button type="button" class="btn btn-outline-secondary" id="toggleAiKey">
                                            <i class="ri-eye-line"></i>
                                        </button>
                                    </div>
                                    <div class="form-text text-muted">
                                        <?php if(!empty($settings['ai_key'])): ?>
                                            <span class="text-success"><i class="ri-check-line"></i> Đã cấu hình</span> —
                                        <?php endif; ?>
                                        <a href="/admin/exam/ai-import" target="_blank">Thử import đề →</a>
                                    </div>
                                </div>
                            </div>
                            <div class="alert alert-soft-info py-2 mb-0">
                                <i class="ri-information-line me-1"></i>
                                <strong>Gemini:</strong> Gửi nguyên file PDF (chính xác hơn với hình ảnh, công thức).
                                <strong>OpenAI:</strong> Dùng base64 PDF.
                                Câu hỏi được trích xuất tự động, hỗ trợ LaTeX và ghi chú vị trí ảnh.
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 mt-3">
                    <button type="submit" class="btn btn-primary btn-lg px-5">
                        <i class="ri-save-line me-1"></i> Lưu toàn bộ cài đặt
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>
<script>
$(function(){
    $('#formSettings').on('submit', function(e){
        e.preventDefault();
        $.ajax({
            url: '/ajax/admin/settings/save',
            method: 'POST',
            data: $(this).serialize(),
            success: function(res){
                res.status ? toastr.success(res.message) : toastr.error(res.message);
            }
        });
    });

    // AI: Ẩn/hiện endpoint khi chọn Custom
    $('#aiProvider').on('change', function(){
        $('#aiEndpointGroup').toggle($(this).val() === 'custom');
    });

    // Toggle hiện API key
    $('#toggleAiKey').on('click', function(){
        var inp = $('#aiKeyInput');
        var isPass = inp.attr('type') === 'password';
        inp.attr('type', isPass ? 'text' : 'password');
        $(this).find('i').toggleClass('ri-eye-line ri-eye-off-line');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/admin/pages/settings.blade.php ENDPATH**/ ?>