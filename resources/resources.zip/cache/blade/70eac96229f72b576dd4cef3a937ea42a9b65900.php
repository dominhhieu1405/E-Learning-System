<?php
    $blocks = [];
    $rawContent = null;
    $contentStr = $content ?? '';
    
    if (!empty($contentStr)) {
        $decoded = json_decode($contentStr, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded) && isset($decoded[0]['type'])) {
            $blocks = $decoded;
        } else {
            $rawContent = $contentStr;
        }
    }
?>

<?php if(count($blocks) > 0): ?>
    <div class="d-flex flex-column gap-4">
        <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($block['type'] === 'preview'): ?>
                <?php
                    $url = $block['data'] ?? '';
                    if (($block['storage'] ?? '') === 'googledrive' && str_contains($url, 'drive.google.com')) {
                        $url = str_replace('/view', '/preview', $url);
                        $url = preg_replace('/\?usp=[a-zA-Z0-9_]+/', '', $url);
                    }
                ?>
                <div class="ratio ratio-4x3 border rounded bg-light overflow-hidden shadow-sm">
                    <iframe src="<?php echo e($url); ?>" allow="autoplay" loading="lazy"></iframe>
                </div>
            <?php elseif($block['type'] === 'button'): ?>
                <?php
                    $btnData = $block['data'] ?? [];
                    $icon = $btnData['icon'] ?? 'link';
                    $text = $btnData['text'] ?? 'Mở liên kết';
                    $color = $btnData['color'] ?? 'var(--ot-primary)';
                    $url = $btnData['url'] ?? '#';
                ?>
                <div class="text-center">
                    <a href="<?php echo e($url); ?>" target="_blank" class="btn shadow-sm" style="background-color: <?php echo e($color); ?>; color: #fff; padding: 12px 30px; font-weight: 600; border-radius: 50px; font-size: 1rem;">
                        <i class="fas fa-<?php echo e($icon); ?> me-2"></i> <?php echo e($text); ?>

                    </a>
                </div>
            <?php elseif($block['type'] === 'html' || $block['type'] === 'text'): ?>
                <div class="content-html">
                    <?php echo $block['data'] ?? ''; ?>

                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php elseif($rawContent !== null): ?>
    <?php echo $rawContent; ?>

<?php else: ?>
    <p class="text-muted text-center italic">Chưa có nội dung chi tiết.</p>
<?php endif; ?>
<?php /**PATH D:\localhost\DGNL\resources\views/user/components/content-blocks.blade.php ENDPATH**/ ?>