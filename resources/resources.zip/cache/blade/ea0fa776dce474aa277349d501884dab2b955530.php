
<?php $__env->startSection('content'); ?>
    <div class="theiaStickySidebar" style="padding-top: 0; padding-bottom: 1px; position: static; transform: none;">
        <div class="silo-box section" id="silo-widget">
            <div class="widget Text">
                <div class="widget-title">
                    <h3 class="title">
                        Kết quả tìm kiếm: <?php echo e($search); ?> - Trang <?php echo e($page); ?>

                    </h3>
                </div>
            </div>
        </div>
        <div class="main section" id="main">

            <div class="widget Blog">
                <div class="blog-posts hfeed container post-filter-wrap">
                    <div class="widget-title">
                        <h3 class="title"><span>Khóa học (<?php echo e(number_format($courses_paginate->total)); ?> kết quả)</span></h3>
                    </div>
                    <div class="grid-posts">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="blog-post hentry post-filter post-0" itemscope="itemscope" itemtype="https://schema.org/CreativeWork">
                                <div class="post-filter-inside-wrap">
                                    <div class="post-filter-image" itemprop="image" itemscope="itemscope" itemtype="https://schema.org/ImageObject">
                                        <a class="post-filter-link image-nos" href="<?php echo e(url("course", ["id" => $course->id])); ?>">
                                            <img alt="<?php echo e($course->name); ?>" class="snip-thumbnail lazy-img" src="<?php echo e($course->image); ?>" onerror="errorImage(this)">
                                        </a>
                                    </div>
                                    <div class="featured-meta">
                                        <h2 class="entry-title vcard" itemprop="mainEntityOfPage" style="padding-left: 3px;" itemtype="https://schema.org/mainEntityOfPage">
                                            <a href="<?php echo e(url("course", ["id" => $course->id])); ?>" rel="bookmark" class="reset-before" title="<?php echo e($course->name); ?>">
                                                <span itemprop="name"><?php echo e($course->name); ?></span>
                                            </a>
                                        </h2>
                                        <span class="post-author"><?php echo e(\Models\Web::typeData($course->type)->name); ?></span>
                                        <span class="label-news-flex"><?php echo e(\Models\Web::subjectData($course->subject)->name); ?></span>
                                    </div>
                                </div>
                            </article>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
            <div class="blog-pager container" id="blog-pager" style="text-align: center; <?php if($courses_paginate->total_page < 2): ?> display:none <?php endif; ?>">
                <?php if($page > 2): ?>
                    <a class="page-num " href="<?php echo e(url("search", ["page" => 1], ["q" => $search])); ?>"><i class="fa-solid fa-angles-left"></i></a>
                <?php endif; ?>
                <?php if($page > 2): ?>
                    <a class="page-num" href="<?php echo e(url("search", ["page" => $page - 2], ["q" => $search])); ?>"><?php echo e($page - 2); ?></a>
                <?php endif; ?>
                <?php if($page > 1): ?>
                    <a class="page-num" href="<?php echo e(url("search", ["page" => $page - 1], ["q" => $search])); ?>"><?php echo e($page - 1); ?></a>
                <?php endif; ?>

                <span class="page-num page-active"><?php echo e($page); ?></span>

                <?php if($page < $courses_paginate->total_page): ?>
                    <a class="page-num" href="<?php echo e(url("search", ["page" => $page + 1], ["q" => $search])); ?>"><?php echo e($page + 1); ?></a>
                <?php endif; ?>
                <?php if($page < $courses_paginate->total_page - 1): ?>
                    <a class="page-num" href="<?php echo e(url("search", ["page" => $page + 2], ["q" => $search])); ?>"><?php echo e($page + 2); ?></a>
                <?php endif; ?>
                <?php if($page < $courses_paginate->total_page - 1): ?>
                    <a class="page-num " href="<?php echo e(url("search", ["page" => $courses_paginate->total_page], ["q" => $search])); ?>"><i class="fa-solid fa-angles-right"></i></a>
                <?php endif; ?>
            </div>
        </div>

        <div class="siloiki-box-content">
            <div class="siloiki-box section" id="top-pixy-main-widget1">
                <div class="widget related-runs">
                    <div class="widget-title">
                        <h3 class="title">
                            Tài liệu (<?php echo e(number_format($documents_paginate->total)); ?> kết quả)
                        </h3>
                    </div>
                    <div class="widget-content ixXio-related">
                        <div class="BiggerRelated">
                            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="relatedui-posts">
                                    <div class="relatedui-posts-thumb">
                                        <a class="post-filter-link image-nos" href="<?php echo e(url("document", ["id" => $document->id])); ?>">
                                            <img class="snip-thumbnail lazy-img" alt="<?php echo e($document->name); ?>" data-src="<?php echo e($document->image); ?>" src="<?php echo e($document->image); ?>" onerror="errorImage(this)">
                                        </a>
                                    </div>
                                    <div class="relatedui-posts-box">
                                        <h2 class="entry-title" style="margin: 0; padding: 5px 0 0;">
                                            <a class="reset-before" style="font-size: 14px; line-height: 17px" href="<?php echo e(url("document", ["id" => $document->id])); ?>"><?php echo e($document->name); ?></a>
                                        </h2>
                                        <div class="post-snip">
                                            <span class="post-date"><?php echo e(date("d/m/Y", strtotime($document->time_add))); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="blog-pager container" id="blog-pager2" style="text-align: center; <?php if($documents_paginate->total_page < 2): ?> display:none <?php endif; ?>">
                    <?php if($page > 2): ?>
                        <a class="page-num " href="<?php echo e(url("search", ["page" => 1], ["q" => $search])); ?>"><i class="fa-solid fa-angles-left"></i></a>
                    <?php endif; ?>
                    <?php if($page > 2): ?>
                        <a class="page-num" href="<?php echo e(url("search", ["page" => $page - 2], ["q" => $search])); ?>"><?php echo e($page - 2); ?></a>
                    <?php endif; ?>
                    <?php if($page > 1): ?>
                        <a class="page-num" href="<?php echo e(url("search", ["page" => $page - 1], ["q" => $search])); ?>"><?php echo e($page - 1); ?></a>
                    <?php endif; ?>

                    <span class="page-num page-active"><?php echo e($page); ?></span>

                    <?php if($page < $documents_paginate->total_page): ?>
                        <a class="page-num" href="<?php echo e(url("search", ["page" => $page + 1], ["q" => $search])); ?>"><?php echo e($page + 1); ?></a>
                    <?php endif; ?>
                    <?php if($page < $documents_paginate->total_page - 1): ?>
                        <a class="page-num" href="<?php echo e(url("search", ["page" => $page + 2], ["q" => $search])); ?>"><?php echo e($page + 2); ?></a>
                    <?php endif; ?>
                    <?php if($page < $documents_paginate->total_page - 1): ?>
                        <a class="page-num " href="<?php echo e(url("search", ["page" => $documents_paginate->total_page], ["q" => $search])); ?>"><i class="fa-solid fa-angles-right"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div id="custom-ads-placeholder">
        </div>
        <div class="clearfix"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript_plugins'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\DGNL\resources\views/user/pages/search.blade.php ENDPATH**/ ?>