<nav class="ot-navbar">
    <div class="container">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-4">
                <a href="/" class="navbar-brand me-0">OnThi.io.vn</a>

                
                <div class="d-none d-lg-flex align-items-center gap-1 ms-3">
                    <a href="/" class="nav-link <?php echo e(($navbar ?? '') === 'home' ? 'active' : ''); ?>">
                        <?php echo e(__('common.home')); ?>

                    </a>

                    <div class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle <?php echo e(($navbar ?? '') === 'exams' ? 'active' : ''); ?>"
                            data-bs-toggle="dropdown">
                            <?php echo e(__('common.exams')); ?>

                        </a>
                        <ul class="dropdown-menu shadow-lg border-0 mt-2">
                            <li><a class="dropdown-item fw-bold text-primary py-2" href="/exams"><?php echo e(__('common.all_exams')); ?></a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li class="dropdown-header text-uppercase fs-11 fw-800 opacity-50"><?php echo e(__('common.by_exam')); ?></li>
                            <li><a class="dropdown-item py-2" href="/type/1"><?php echo e(__('common.thpt')); ?></a></li>
                            <li><a class="dropdown-item py-2" href="/type/2"><?php echo e(__('common.hsa')); ?></a></li>
                            <li><a class="dropdown-item py-2" href="/type/3"><?php echo e(__('common.tsa')); ?></a></li>
                        </ul>
                    </div>

                    <div class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle <?php echo e(($navbar ?? '') === 'courses' ? 'active' : ''); ?>"
                            data-bs-toggle="dropdown">
                            <?php echo e(__('common.courses')); ?>

                        </a>
                        <div class="dropdown-menu shadow-lg border-0 mt-2 p-3" style="min-width: 350px;">
                            <div class="row g-2">
                                <div class="col-12">
                                    <h6 class="dropdown-header text-primary px-0 mb-2"><?php echo e(__('common.subjects_title')); ?></h6>
                                </div>
                                <?php $allSubjects = \Models\Web::allSubject(); ?>
                                <?php $__currentLoopData = $allSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <a href="/subject/<?php echo e($subject->id); ?>"
                                            class="dropdown-item rounded py-1 px-2 mb-1 small">
                                            <i class="fas fa-book-open me-2 opacity-50"></i> <?php echo e($subject->name); ?>

                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="border-top mt-2 pt-2 text-center">
                                <a href="/courses" class="btn btn-sm btn-link text-decoration-none"><?php echo e(__('common.view_all_courses')); ?>

                                    <i class="fas fa-arrow-right fs-10"></i></a>
                            </div>
                        </div>
                    </div>

                    <a href="/documents" class="nav-link <?php echo e(($navbar ?? '') === 'documents' ? 'active' : ''); ?>">
                        <?php echo e(__('common.documents')); ?>

                    </a>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2">
                
                <form action="/search" class="d-none d-xl-flex position-relative me-2" style="width: 200px;">
                    <input type="text" name="q"
                        class="form-control form-control-sm rounded-pill ps-3 pe-4 bg-light shadow-none border-0"
                        placeholder="<?php echo e(__('common.search_placeholder')); ?>" style="height: 38px;">
                    <button type="submit" class="btn btn-sm position-absolute end-0 top-0 mt-1 me-1 text-muted"><i
                            class="fas fa-search"></i></button>
                </form>

                <div class="dropdown">
                    <button class="btn btn-sm btn-light border rounded-circle" data-bs-toggle="dropdown"
                        title="<?php echo e(__('common.lang_toggle')); ?>" style="width: 38px; height: 38px;">
                        <i class="fas fa-globe"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-2">
                        <?php $languages = \Models\Language::allActive(); ?>
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="dropdown-item py-2 d-flex align-items-center justify-content-between <?php echo e(($_SESSION['locale'] ?? 'vi') == $lang['code'] ? 'active' : ''); ?>"
                                    href="/change-language/<?php echo e($lang['code']); ?>">
                                    <?php echo e($lang['name']); ?>

                                    <?php if(($_SESSION['locale'] ?? 'vi') == $lang['code']): ?>
                                        <i class="fas fa-check fs-10 ms-2"></i>
                                    <?php endif; ?>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <button class="btn btn-sm btn-light border rounded-circle" id="btnThemeToggle"
                    title="<?php echo e(__('common.theme_toggle')); ?>" style="width: 38px; height: 38px;">
                    <i class="fas fa-moon"></i>
                </button>

                <?php if(is_login()): ?>
                    <div class="dropdown">
                        <button
                            class="btn btn-sm d-flex align-items-center p-1 pe-lg-3 rounded-pill border-0 shadow-none bg-light"
                            data-bs-toggle="dropdown" style="height: 38px;">
                            <img src="<?php echo e(userget(false)->avatar ?? ('https://ui-avatars.com/api/?name=' . urlencode(userget(false)->display_name ?? userget(false)->username) . '&background=6366f1&color=fff')); ?>"
                                class="rounded-circle shadow-sm" width="30" height="30"
                                style="object-fit: cover; border: 2px solid #fff">
                            <span
                                class="d-none d-lg-inline ms-2 text-dark fw-600"><?php echo e(userget(false)->display_name ?? userget(false)->username); ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-2">
                            <li><a class="dropdown-item py-2" href="/user"><i
                                        class="fas fa-user-circle me-2 opacity-50"></i> <?php echo e(__('common.profile')); ?></a></li>
                            <?php if(\Models\User::isManager()): ?>
                                <li><a class="dropdown-item py-2" href="/admin"><i class="fas fa-cog me-2 opacity-50"></i>
                                        <?php echo e(__('common.admin_panel')); ?></a></li>
                            <?php endif; ?>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item py-2 text-danger" href="/logout"><i
                                        class="fas fa-sign-out-alt me-2 opacity-50"></i> <?php echo e(__('common.logout')); ?></a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="/login" class="btn btn-ot-primary px-4 d-none d-md-inline-block"
                        style="height: 38px; line-height: 24px;"><?php echo e(__('common.login')); ?></a>
                    <a href="/login" class="btn btn-sm btn-ot-primary d-md-none"><i class="fas fa-sign-in-alt"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav><?php /**PATH D:\localhost\DGNL\resources\views/user/components/navbar.blade.php ENDPATH**/ ?>