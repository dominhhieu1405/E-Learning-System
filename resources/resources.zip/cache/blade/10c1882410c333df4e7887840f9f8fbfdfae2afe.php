<!DOCTYPE html>
<html lang="vi">
<head>
    <meta http-equiv="Content-Type" content="#; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="OnThi.io.vn"/>
    <meta name="keywords" content="OnThi.io.vn"/>
    <meta name="author" content="OnThi.io.vn"/>
    <link rel="manifest" href="manifest.json"/>
    <link rel="icon" href="/assets/img/logo/favicon.png" type="image/x-icon"/>
    <title><?php echo $__env->yieldContent('title', 'Đăng nhập'); ?></title>
    <link rel="apple-touch-icon" href="/assets/img/logo/favicon.png"/>
    <meta name="theme-color" content="#122636"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta name="apple-mobile-web-app-title" content="OnThi.io.vn"/>
    <meta name="msapplication-TileImage" content="/assets/img/logo/favicon.png"/>

    <!--Google font-->
    <link rel="preconnect" href="https://fonts.googleapis.com/"/>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet"/>

    <!-- iconsax css -->
    <link rel="stylesheet" type="text/css" href="/assets/css/tabler-icons.min.css">
    <!-- bootstrap css -->
    <link rel="stylesheet" id="rtl-link" type="text/css" href="/assets/css/vendors/bootstrap.min.css"/>
    <!-- Theme css -->
    <link rel="stylesheet" id="change-link" type="text/css" href="/assets/css/style.css"/>
    <style>
        input:-webkit-autofill,
        input:-webkit-autofill:hover,
        input:-webkit-autofill:focus,
        input:-webkit-autofill:active {
            transition: background-color 5000s ease-in-out 0s;
            background: #192D3C;
            -webkit-text-fill-color: #fff !important;
        }
    </style>
</head>

<body class="auth-body">
<div class="auth-img">
    <img class="img-fluid auth-bg" src="/assets/img/background/cashback-explained.webp" alt="auth_bg"/>
    <div class="auth-content">
    </div>
</div>

<?php echo $__env->yieldContent('content'); ?>
<!-- bootstrap js -->
<script src="/assets/js/jquery.min.js"></script>
<script src="/assets/js/bootstrap.bundle.min.js"></script>
<!-- script js -->
<script src="/assets/js/script.js"></script>
<?php echo $__env->yieldContent('js_plugins'); ?>
</body>
</html>
<?php /**PATH D:\localhost\dealhot.com\resources\views/user/layout/auth.blade.php ENDPATH**/ ?>